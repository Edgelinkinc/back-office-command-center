/* node build.js [clientId]  ->  dist/index.html (single file) */
var fs = require('fs');
var src = function (f) { return fs.readFileSync(__dirname + '/src/' + f, 'utf8'); };
var js = ['rules.js', 'sp.js', 'core.js', 'views.js', 'views2.js', 'actions.js'].map(src).join('\n');
if (process.argv[2]) { js = js.replace('__CLIENT_ID__', process.argv[2]); }
var html = src('shell.html').replace('/*CSS*/', function () { return src('app.css'); }).replace('/*JS*/', function () { return js; });
fs.mkdirSync(__dirname + '/dist', { recursive: true });
fs.writeFileSync(__dirname + '/dist/index.html', html);
console.log('dist/index.html', (html.length / 1024).toFixed(1) + ' KB');
