/* Back Office Command Center — business rules.
   Pure ES5, no DOM, no network. Everything date-related works on
   America/New_York business dates stored as 'YYYY-MM-DD' strings. */
var BOCCRules = (function () {
  'use strict';
  var TZ = 'America/New_York';
  var DAY_MS = 86400000;
  var DEFAULT_WORKDAYS = '0111110'; // Sun..Sat

  function pad(n) { return (n < 10 ? '0' : '') + n; }

  // Business date/time in New York for an instant.
  function nyNow(d) {
    d = d || new Date();
    var f = new Intl.DateTimeFormat('en-US', {
      timeZone: TZ, year: 'numeric', month: '2-digit', day: '2-digit',
      hour: '2-digit', minute: '2-digit', hour12: false
    });
    var parts = f.formatToParts(d), o = {}, i;
    for (i = 0; i < parts.length; i++) { o[parts[i].type] = parts[i].value; }
    var h = o.hour === '24' ? '00' : o.hour;
    return {
      date: o.year + '-' + o.month + '-' + o.day,
      time: h + ':' + o.minute,
      minutes: parseInt(h, 10) * 60 + parseInt(o.minute, 10)
    };
  }

  function toMs(ds) { var a = ds.split('-'); return Date.UTC(+a[0], +a[1] - 1, +a[2]); }
  function fromMs(ms) {
    var d = new Date(ms);
    return d.getUTCFullYear() + '-' + pad(d.getUTCMonth() + 1) + '-' + pad(d.getUTCDate());
  }
  function addDays(ds, n) { return fromMs(toMs(ds) + n * DAY_MS); }
  function dow(ds) { return new Date(toMs(ds)).getUTCDay(); }
  function daysBetween(a, b) { return Math.round((toMs(b) - toMs(a)) / DAY_MS); }
  function isDate(ds) { return typeof ds === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(ds); }
  function mondayOf(ds) { var w = dow(ds); return addDays(ds, w === 0 ? -6 : 1 - w); }
  function sundayOf(ds) { return addDays(ds, -dow(ds)); }
  function minutesOf(hhmm) {
    if (!hhmm || !/^\d{1,2}:\d{2}$/.test(hhmm)) { return null; }
    var a = hhmm.split(':'); return (+a[0]) * 60 + (+a[1]);
  }
  function fmtTime(hhmm) {
    var m = minutesOf(hhmm); if (m === null) { return ''; }
    var h = Math.floor(m / 60), mm = m % 60, ap = h >= 12 ? 'PM' : 'AM';
    h = h % 12; if (h === 0) { h = 12; }
    return h + ':' + pad(mm) + ' ' + ap;
  }
  var DOW = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  var MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  function fmtDate(ds, withYear) {
    if (!isDate(ds)) { return ''; }
    var a = ds.split('-');
    return DOW[dow(ds)] + ', ' + MON[+a[1] - 1] + ' ' + (+a[2]) + (withYear ? ', ' + a[0] : '');
  }
  function fmtShort(ds) { if (!isDate(ds)) { return ''; } var a = ds.split('-'); return DOW[dow(ds)] + ' ' + MON[+a[1] - 1] + ' ' + (+a[2]); }

  // ---- work days ----
  // w: 'SMTWTFS' bit string, or { days: bitString, off: ['YYYY-MM-DD', ...] } for time off.
  function wd(w) {
    if (w && typeof w === 'object') { w = w.days; }
    return (typeof w === 'string' && /^[01]{7}$/.test(w)) ? w : DEFAULT_WORKDAYS;
  }
  function isWorkDay(w, ds) {
    if (w && typeof w === 'object' && w.off && w.off.indexOf(ds) >= 0) { return false; }
    return wd(w).charAt(dow(ds)) === '1';
  }
  function nextWorkDayOnOrAfter(w, ds) {
    if (wd(w).indexOf('1') < 0) { return ds; }
    var d = ds, i;
    for (i = 0; i < 400; i++) { if (isWorkDay(w, d)) { return d; } d = addDays(d, 1); }
    return ds;
  }
  function nextWorkDayAfter(w, ds) { return nextWorkDayOnOrAfter(w, addDays(ds, 1)); }

  // ---- task state ----
  var OPEN = { 'Not Started': 1, 'In Progress': 1, 'Waiting': 1 };
  function isOpen(t) { return !!OPEN[t.Status] && !t.Archived; }
  function rolls(t) {
    if (t.Kind === 'Call') { return false; }            // meetings never roll
    if (t.Rollover === 'Stay') { return false; }
    if (t.Kind === 'Block' && t.Rollover !== 'Roll') { return false; } // blocks stay by default
    return true;
  }
  // The day an item is actionable on, given today.
  function effectiveDate(t, today, w) {
    var base = t.PlannedDate;
    if (!isOpen(t) || !rolls(t)) { return base; }
    if (t.Status === 'Waiting' && isDate(t.FollowUpDate) && t.FollowUpDate > base) { base = t.FollowUpDate; }
    if (base >= today) { return base; }
    return nextWorkDayOnOrAfter(w, today);
  }
  function isCarried(t, today) {
    return isOpen(t) && rolls(t) && t.PlannedDate < today &&
      !(t.Status === 'Waiting' && isDate(t.FollowUpDate) && t.FollowUpDate >= today);
  }
  function isOverdue(t, today) { return isOpen(t) && isDate(t.DueDate) && t.DueDate < today; }
  function completedDate(t) {
    if (!t.CompletedAt) { return null; }
    return nyNow(new Date(t.CompletedAt)).date;
  }
  // Does an item belong on the list for `day`?
  function showsOnDay(t, day, today, w) {
    if (t.Archived) { return false; }
    if (day < today) {
      return t.PlannedDate === day || completedDate(t) === day;
    }
    if (!isOpen(t)) {
      // finished items show on the day they were finished (or planned, if that's today/future)
      var cd = completedDate(t);
      return cd ? cd === day : t.PlannedDate === day;
    }
    return effectiveDate(t, today, w) === day;
  }
  function callState(t, now) {
    if (t.CallState === 'Held' || t.CallState === 'Missed') { return t.CallState; }
    if (t.Status === 'Cancelled') { return 'Cancelled'; }
    if (t.PlannedDate < now.date) { return 'Not recorded'; }
    if (t.PlannedDate === now.date) {
      var st = minutesOf(t.StartTime);
      if (st !== null) {
        var end = st + (t.DurationMin ? +t.DurationMin : 0);
        if (now.minutes > end) { return 'Not recorded'; }
      }
    }
    return 'Scheduled';
  }

  // ---- subtasks (tree, up to 3 levels) ----
  function walk(nodes, fn, depth) {
    var i; nodes = nodes || []; depth = depth || 1;
    for (i = 0; i < nodes.length; i++) { fn(nodes[i], depth); walk(nodes[i].children, fn, depth + 1); }
  }
  function countSubtasks(nodes) {
    var c = { total: 0, done: 0 };
    walk(nodes, function (n) { c.total++; if (n.done) { c.done++; } });
    return c;
  }
  function openRequired(nodes) {
    var out = [];
    walk(nodes, function (n) { if (n.required && !n.done) { out.push(n.title); } });
    return out;
  }
  function canComplete(t) {
    var open = openRequired(t.Subtasks || []);
    return { ok: open.length === 0, openRequired: open };
  }
  function completeAll(nodes, by, at) {
    walk(nodes, function (n) { if (!n.done) { n.done = true; n.doneAt = at; n.doneBy = by; } });
    return nodes;
  }
  function findNode(nodes, id) {
    var hit = null; walk(nodes, function (n) { if (n.id === id) { hit = n; } }); return hit;
  }
  function findParentList(nodes, id) {
    var i; nodes = nodes || [];
    for (i = 0; i < nodes.length; i++) {
      if (nodes[i].id === id) { return nodes; }
      var r = findParentList(nodes[i].children, id); if (r) { return r; }
    }
    return null;
  }
  function depthOf(nodes, id) {
    var d = 0; walk(nodes, function (n, depth) { if (n.id === id) { d = depth; } }); return d;
  }

  // ---- recurrence ----
  function occursOn(tp, ds) {
    if (!tp || tp.Active === false) { return false; }
    if (isDate(tp.StartDate) && ds < tp.StartDate) { return false; }
    if (isDate(tp.EndDate) && ds > tp.EndDate) { return false; }
    if ((tp.Skips || []).indexOf(ds) >= 0) { return false; }
    return wd(tp.Days).charAt(dow(ds)) === '1';
  }
  function occKey(tpId, ds, owner) { return 'occ|' + String(owner).toLowerCase() + '|' + tpId + '|' + ds; }
  function cycleId(tp, ds) { return tp.Cycle === 'payroll' ? 'PAY-' + mondayOf(ds) : ''; }

  function cloneTree(nodes, prefix) {
    var out = [], i;
    nodes = nodes || [];
    for (i = 0; i < nodes.length; i++) {
      out.push({
        id: prefix + '-' + i, title: nodes[i].title, required: !!nodes[i].required,
        done: false, with: [], children: cloneTree(nodes[i].children, prefix + '-' + i)
      });
    }
    return out;
  }

  function occurrenceFromTemplate(tp, ds, owner) {
    var kind = tp.Kind || 'Task';
    var roll = kind === 'Call' ? 'Stay' : (kind === 'Block' ? (tp.Rollover === 'Roll' ? 'Roll' : 'Stay') :
      (tp.Rollover === 'Stay' ? 'Stay' : 'Roll'));
    return {
      TaskKey: occKey(tp.Id, ds, owner),
      Title: tp.Title,
      OwnerEmail: String(owner).toLowerCase(),
      Category: tp.Category || '',
      Kind: kind,
      Priority: tp.Priority || 'Normal',
      Status: 'Not Started',
      PlannedDate: ds,
      OriginalPlannedDate: ds,
      StartTime: tp.StartTime || '',
      DurationMin: tp.DurationMin || null,
      Rollover: roll,
      TemplateId: tp.Id,
      CycleId: cycleId(tp, ds),
      Description: tp.Description || '',
      Subtasks: cloneTree(tp.Items, 's'),
      Private: !!tp.Private,
      PublicLabel: tp.Private ? (tp.PublicLabel || 'Private') : '',
      Visibility: tp.Private ? 'Private' : 'Team'
    };
  }

  // Occurrences that should exist as saved records for dates in [from, to].
  // existing: array of saved tasks (any owner) — used for de-duplication.
  function planOccurrences(templates, owner, from, to, existing) {
    owner = String(owner).toLowerCase();
    var keys = {}, openByTp = {}, out = [], resolved = {}, i, j, d;
    for (i = 0; i < existing.length; i++) {
      var e = existing[i];
      if (e.TaskKey) { keys[e.TaskKey] = 1; }
      if (e.TemplateId && isOpen(e) && String(e.OwnerEmail).toLowerCase() === owner) {
        openByTp[e.TemplateId] = true;
      }
    }
    // Walk newest day first: a carried routine only ever needs its most recent occurrence.
    for (d = to; d >= from; d = addDays(d, -1)) {
      for (j = 0; j < templates.length; j++) {
        var tp = templates[j];
        if (String(tp.OwnerEmail).toLowerCase() !== owner || !occursOn(tp, d)) { continue; }
        var kind = tp.Kind || 'Task';
        var carry = kind === 'Task' && tp.Rollover !== 'Independent' && tp.Rollover !== 'Stay';
        if (carry && (openByTp[tp.Id] || resolved[tp.Id])) { continue; } // suppress duplicates / stale backfill
        var key = occKey(tp.Id, d, owner);
        if (keys[key]) { if (carry) { resolved[tp.Id] = true; } continue; }
        var occ = occurrenceFromTemplate(tp, d, owner);
        out.push(occ); keys[key] = 1;
        if (carry) { openByTp[tp.Id] = true; resolved[tp.Id] = true; }
      }
    }
    out.sort(function (a, b) { return a.PlannedDate < b.PlannedDate ? -1 : a.PlannedDate > b.PlannedDate ? 1 : 0; });
    return out;
  }
  // Unsaved preview occurrences for future days (not written until the day arrives or user edits).
  function virtualOccurrences(templates, owner, day, existing) {
    var list = planOccurrences(templates, owner, day, day, existing), i;
    for (i = 0; i < list.length; i++) { list[i].Id = 'v:' + list[i].TaskKey; list[i].Virtual = true; }
    return list;
  }

  // Split a template for "this and future" edits; preserves history.
  function splitTemplate(tp, fromDate, changes, newId) {
    var oldTp = shallow(tp); oldTp.EndDate = addDays(fromDate, -1);
    var newTp = shallow(tp), k;
    for (k in changes) { if (changes.hasOwnProperty(k)) { newTp[k] = changes[k]; } }
    newTp.Id = newId; newTp.StartDate = fromDate; newTp.Skips = [];
    if (isDate(tp.EndDate)) { newTp.EndDate = tp.EndDate; }
    return { oldTemplate: oldTp, newTemplate: newTp };
  }

  // ---- merge (two people / two tabs) ----
  var TEXT_FIELDS = { Description: 1, Notes: 1, Discussion: 1, Outcome: 1, Text: 1 };
  function shallow(o) { var r = {}, k; for (k in o) { if (o.hasOwnProperty(k)) { r[k] = o[k]; } } return r; }
  function same(a, b) { return JSON.stringify(a) === JSON.stringify(b); }
  function mergeTree(base, mine, theirs) {
    base = base || []; mine = mine || []; theirs = theirs || [];
    var baseById = {}, mineById = {}, i;
    walk(base, function (n) { baseById[n.id] = n; });
    walk(mine, function (n) { mineById[n.id] = n; });
    var result = JSON.parse(JSON.stringify(theirs));
    // apply my edits / deletions
    walk(mine, function (n) {
      var b = baseById[n.id], t = findNode(result, n.id);
      if (b && t) {
        var keys = ['title', 'done', 'doneAt', 'doneBy', 'with', 'required'], k;
        for (k = 0; k < keys.length; k++) {
          if (!same(n[keys[k]], b[keys[k]])) { t[keys[k]] = n[keys[k]]; }
        }
      }
    });
    for (var id in baseById) {
      if (baseById.hasOwnProperty(id) && !mineById[id]) {
        var pl = findParentList(result, id);
        if (pl) { for (i = 0; i < pl.length; i++) { if (pl[i].id === id) { pl.splice(i, 1); break; } } }
      }
    }
    // my additions
    function addNew(nodes, parentId) {
      var x;
      for (x = 0; x < nodes.length; x++) {
        var n = nodes[x];
        if (!baseById[n.id] && !findNode(result, n.id)) {
          var copy = JSON.parse(JSON.stringify(n));
          if (parentId) { var p = findNode(result, parentId); if (p) { (p.children = p.children || []).push(copy); continue; } }
          result.push(copy);
        } else { addNew(n.children || [], n.id); }
      }
    }
    addNew(mine, null);
    return result;
  }
  function mergeRecord(base, mine, theirs) {
    var merged = shallow(theirs), conflicts = [], k, seen = {};
    var all = [base, mine, theirs], i;
    for (i = 0; i < all.length; i++) { for (k in all[i]) { if (all[i].hasOwnProperty(k)) { seen[k] = 1; } } }
    for (k in seen) {
      if (!seen.hasOwnProperty(k) || k === 'ETag' || k === 'Modified' || k === 'Editor') { continue; }
      var mc = !same(mine[k], base[k]), tc = !same(theirs[k], base[k]);
      if (!mc) { continue; }
      if (!tc || same(mine[k], theirs[k])) { merged[k] = mine[k]; continue; }
      if (k === 'Subtasks') { merged[k] = mergeTree(base[k], mine[k], theirs[k]); continue; }
      if (TEXT_FIELDS[k]) { conflicts.push(k); merged[k] = theirs[k]; continue; }
      merged[k] = mine[k];
    }
    return { merged: merged, conflicts: conflicts };
  }

  // ---- misc ----
  function uid(prefix) {
    var s = '', i, c = '0123456789abcdefghijklmnopqrstuvwxyz';
    var rnd = (typeof crypto !== 'undefined' && crypto.getRandomValues) ? crypto.getRandomValues(new Uint8Array(16)) : null;
    for (i = 0; i < 16; i++) { s += c.charAt((rnd ? rnd[i] : Math.floor(Math.random() * 256)) % 36); }
    return (prefix || 'id') + '-' + s;
  }
  function raiseChange(cur, prop) {
    var c = parseFloat(cur), p = parseFloat(prop);
    if (!(c > 0) || !(p >= 0)) { return null; }
    return { amount: Math.round((p - c) * 100) / 100, pct: Math.round(((p - c) / c) * 1000) / 10 };
  }

  return {
    TZ: TZ, nyNow: nyNow, addDays: addDays, dow: dow, daysBetween: daysBetween, isDate: isDate,
    mondayOf: mondayOf, sundayOf: sundayOf, minutesOf: minutesOf, fmtTime: fmtTime, fmtDate: fmtDate, fmtShort: fmtShort,
    DOW: DOW, DEFAULT_WORKDAYS: DEFAULT_WORKDAYS,
    isWorkDay: isWorkDay, nextWorkDayOnOrAfter: nextWorkDayOnOrAfter, nextWorkDayAfter: nextWorkDayAfter,
    isOpen: isOpen, rolls: rolls, effectiveDate: effectiveDate, isCarried: isCarried, isOverdue: isOverdue,
    completedDate: completedDate, showsOnDay: showsOnDay, callState: callState,
    walk: walk, countSubtasks: countSubtasks, openRequired: openRequired, canComplete: canComplete,
    completeAll: completeAll, findNode: findNode, findParentList: findParentList, depthOf: depthOf,
    occursOn: occursOn, occKey: occKey, cycleId: cycleId, occurrenceFromTemplate: occurrenceFromTemplate,
    planOccurrences: planOccurrences, virtualOccurrences: virtualOccurrences, splitTemplate: splitTemplate,
    mergeRecord: mergeRecord, mergeTree: mergeTree, uid: uid, raiseChange: raiseChange
  };
}());
if (typeof module !== 'undefined') { module.exports = BOCCRules; }
