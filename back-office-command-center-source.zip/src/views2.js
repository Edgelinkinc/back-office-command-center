/* Drawer, modals, log, raises, settings, access, setup. ES5. */

/* ================= task drawer ================= */
function drawerHtml() {
  var t = findTask(S.drawer.id);
  if (!t) { return ''; }
  var ro = !canEditTask(t) || isPrivateFor(t), me = S.myEmail, call = t.Kind === 'Call', blk = t.Kind === 'Block';
  if (isPrivateFor(t)) {
    return '<div class="scrim" data-act="closedrawer"></div><aside class="drawer" role="dialog" aria-label="Private item"><div class="dhd"><div><div class="meta" style="font-weight:700">' + esc(nameOf(t.OwnerEmail)) + '</div><div style="font-size:19px;font-weight:700;color:var(--gry-t)">' + ICON.lock + ' ' + esc(t.PublicLabel || 'Private') + '</div></div>' +
      '<button class="ib" style="color:var(--plum);border-color:var(--line)" data-act="closedrawer" aria-label="Close">×</button></div><div class="dbody" id="dbody"><div class="sec">Details are visible only to ' + esc(firstName(t.OwnerEmail)) + '.</div></div></aside>';
  }
  var d = ro ? ' disabled' : '';
  var w = workOf(t.OwnerEmail), cnt = R.countSubtasks(t.Subtasks);
  var chips = [];
  chips.push(chip(t.Status, t.Status === 'Completed' ? 'grn' : t.Status === 'Waiting' ? 'blu' : t.Status === 'Cancelled' ? 'gry' : ''));
  if (R.isCarried(t, S.today)) { chips.push(chip('Carried forward · originally ' + R.fmtShort(t.OriginalPlannedDate || t.PlannedDate), 'amb')); }
  if (R.isOverdue(t, S.today)) { chips.push(chip('Overdue · due ' + R.fmtShort(t.DueDate), 'red')); }
  if (t.TemplateId) { chips.push(chip('From routine', 'gry')); }
  if (t.CycleId) { chips.push(chip('Payroll cycle ' + t.CycleId.replace('PAY-', ''), 'gry')); }
  if (call) { chips.push(chip(R.callState(t, R.nyNow()), 'gry')); }
  if (t.Virtual) { chips.push(chip('Not saved yet — saves on first change', 'gry')); }
  if (cnt.total) { chips.push(chip(cnt.done + ' of ' + cnt.total + ' done')); }
  var conflict = t._conflict ? '<div class="sec"><div class="bad-box"><b>' + esc(t._conflict.by || 'Someone') + ' changed ' + esc(t._conflict.fields.join(', ')) + ' while you were editing.</b> Their version is shown. Your text:<pre style="white-space:pre-wrap;font:inherit;margin:6px 0">' +
    esc(t._conflict.fields.map(function (f) { return t._conflict.mine[f]; }).join('\n\n')) + '</pre><button class="btn sm" data-act="keepmine" data-id="' + esc(t._id) + '">Use my text</button> <button class="btn sm" data-act="dropconflict" data-id="' + esc(t._id) + '">Keep theirs</button></div></div>' : '';
  var people = activePeople();
  var ownerSel = '<select id="f-owner" class="in" data-f="OwnerEmail"' + d + '>' + people.map(function (p) { return opt(p.Email, t.OwnerEmail, p.Email === me ? 'Me' : p.Title); }).join('') + '</select>';
  var offWarn = (!R.isWorkDay(w, t.PlannedDate) && R.isOpen(t)) ? '<div class="warn spanall"><span><b>' + esc(R.fmtDate(t.PlannedDate)) + ' is an off day for ' + esc(t.OwnerEmail === me ? 'you' : firstName(t.OwnerEmail)) + '.</b></span><button class="btn sm p" data-act="movework" data-id="' + esc(t._id) + '">Move to ' + esc(R.fmtShort(R.nextWorkDayOnOrAfter(w, t.PlannedDate))) + '</button></div>' : '';
  var fields = '<div class="sec fgrid c4">' +
    '<div class="fld"><label for="f-status">Status</label><select id="f-status" class="in" data-f="Status"' + d + '>' + opts(STATUSES, t.Status) + '</select></div>' +
    '<div class="fld"><label for="f-pri">Priority</label><select id="f-pri" class="in" data-f="Priority"' + d + '>' + opts(['High', 'Normal', 'Low'], t.Priority || 'Normal') + '</select></div>' +
    '<div class="fld"><label for="f-plan">Planned</label><input type="date" id="f-plan" class="in" data-f="PlannedDate" value="' + esc(t.PlannedDate) + '"' + d + '></div>' +
    '<div class="fld"><label for="f-due">Due</label><input type="date" id="f-due" class="in" data-f="DueDate" value="' + esc(t.DueDate) + '"' + d + '></div>' +
    '<div class="fld"><label for="f-owner">Owner</label>' + ownerSel + '</div>' +
    '<div class="fld"><label for="f-vis">Visibility</label><select id="f-vis" class="in" data-f="Visibility"' + (ro || t.OwnerEmail !== me ? ' disabled' : '') + '>' + opt('Team', t.Visibility || 'Team', 'Team can see') + opt('Private', t.Visibility, 'Private') + '</select></div>' +
    '<div class="fld"><label for="f-cat">Category</label><input id="f-cat" class="in" list="catlist" data-f="Category" value="' + esc(t.Category) + '"' + d + '><datalist id="catlist">' + myCategories().map(function (c) { return '<option value="' + esc(c) + '">'; }).join('') + '</datalist></div>' +
    '<div class="fld"><label for="f-roll">If unfinished</label><select id="f-roll" class="in" data-f="Rollover"' + (ro || call ? ' disabled' : '') + '>' + opt('Roll', t.Rollover, 'Roll to next work day') + opt('Stay', t.Rollover, 'Stay on its date') + '</select></div>' +
    '<div class="fld"><label for="f-st">Start time</label><input type="time" id="f-st" class="in" data-f="StartTime" value="' + esc(t.StartTime) + '"' + d + '></div>' +
    '<div class="fld"><label for="f-dur">Minutes</label><input type="number" min="0" step="5" id="f-dur" class="in" data-f="DurationMin" value="' + esc(t.DurationMin === null ? '' : t.DurationMin) + '" placeholder="Not set"' + d + '></div>' +
    (t.Status === 'Waiting' ? '<div class="fld"><label for="f-won">Waiting on</label><input id="f-won" class="in" data-f="WaitingOn" value="' + esc(t.WaitingOn) + '"' + d + '></div>' +
      '<div class="fld"><label for="f-fu">Follow up on</label><input type="date" id="f-fu" class="in" data-f="FollowUpDate" value="' + esc(t.FollowUpDate) + '"' + d + '></div>' : '') +
    (t.Visibility === 'Private' && t.OwnerEmail === me ? '<div class="fld span2"><label for="f-pl">What the team sees</label><input id="f-pl" class="in" data-f="PublicLabel" value="' + esc(t.PublicLabel || 'Private') + '"' + d + '></div>' : '') +
    offWarn + '</div>';
  var withH = '<div class="sec"><div class="h">With <span>who this was done with</span></div><div style="display:flex;flex-wrap:wrap;gap:4px;align-items:center">' +
    (t.WithPeople || []).map(function (p, i) { return whoChip(p, ro ? '' : 'data-act="unwith" data-id="' + esc(t._id) + '" data-i="' + i + '"'); }).join('') +
    (ro ? '' : '<button class="add" data-act="pick" data-target="task" data-id="' + esc(t._id) + '">+ person</button>') + '</div>' + pickerHtml('task', t._id) + '</div>';
  var desc = '<div class="sec"><div class="h">Description</div><label class="sr" for="f-desc">Description</label><textarea id="f-desc" class="in" rows="3" data-f="Description" placeholder="Details, links, context"' + d + '>' + esc(descOf(t)) + '</textarea></div>';
  var subs = '<div class="sec"><div class="h">Breakdown <span>' + cnt.done + ' / ' + cnt.total + ' · up to 3 levels</span></div>' + subtree(t, t.Subtasks || [], 1, ro) +
    (ro ? '' : '<div style="display:flex;gap:6px;padding-top:6px"><button class="add" data-act="addsub" data-id="' + esc(t._id) + '">+ Subtask</button></div>') + completeWarn(t) + '</div>';
  var sendBack = (t.OwnerEmail === me && t.AssignedByEmail && t.AssignedByEmail !== me && R.isOpen(t)) ? sendBackHtml(t) : '';
  var sbHist = (t.SendBack || []).length ? '<div class="sec"><div class="h">Sent back</div>' + t.SendBack.map(function (s) {
    return '<div style="font-size:12px;line-height:1.6"><b>' + esc(nameOf(s.by)) + '</b> · ' + esc(fmtStamp(s.at)) + ' · ' + esc(s.reason) + (s.suggest ? ' · suggested ' + esc(R.fmtShort(s.suggest)) : '') + '<div style="color:var(--mute)">' + esc(s.note) + '</div></div>';
  }).join('') + '</div>' : '';
  var comments = '<div class="sec"><div class="h">Comments</div>' + (t.Comments || []).map(function (c) { return '<div style="font-size:12px;line-height:1.5;margin-bottom:4px"><b>' + esc(nameOf(c.by)) + '</b> · ' + esc(fmtStamp(c.at)) + '<div>' + esc(c.text) + '</div></div>'; }).join('') +
    '<div style="display:flex;gap:6px"><label class="sr" for="f-cmt">Add a comment</label><input id="f-cmt" class="in" placeholder="Add a comment"><button class="btn sm" data-act="comment" data-id="' + esc(t._id) + '">Post</button></div></div>';
  var convs = S.notes.concat(S.shared).filter(function (n) { return n.LinkedTaskKey && n.LinkedTaskKey === t.TaskKey && !n.Archived; });
  var convH = '<div class="sec"><div class="h">Conversations <button class="btn m xs" data-act="newlog" data-task="' + esc(t._id) + '">Log Conversation</button></div>' +
    (convs.length ? convs.map(noteRow).join('') : '<div class="meta">None linked yet.</div>') + '</div>';
  var hist = '<div class="sec" style="background:var(--lav2)"><div class="h">History</div><div id="hist" class="meta" style="white-space:normal;line-height:1.7">' + histHtml(t) + '</div></div>';
  var foot = '<div class="dft">';
  if (call) {
    foot += '<div style="display:flex;gap:6px;flex-wrap:wrap">' + (ro ? '' : '<button class="btn sm g" data-act="callstate" data-v="Held" data-id="' + esc(t._id) + '">Mark held</button><button class="btn sm" data-act="callstate" data-v="Missed" data-id="' + esc(t._id) + '">Mark missed</button>') + '<button class="btn sm m" data-act="newlog" data-task="' + esc(t._id) + '">Log notes</button></div>';
  } else if (!ro) {
    foot += '<div style="display:flex;gap:6px;flex-wrap:wrap">' + (t.Status === 'Completed' || t.Status === 'Cancelled' ? '<button class="btn sm" data-act="reopen" data-id="' + esc(t._id) + '">Reopen</button>' :
      '<button class="btn sm g" data-act="complete" data-id="' + esc(t._id) + '">Complete</button>') +
      '<button class="btn sm" data-act="invite" data-id="' + esc(t._id) + '">' + (t.InviteSentAt ? 'Invite sent ' + esc(fmtStamp(t.InviteSentAt)) : 'Teams invite sent') + '</button></div>';
  }
  if (!ro && !t.Virtual) {
    foot += '<div style="display:flex;gap:6px;flex-wrap:wrap">' + (R.isOpen(t) ? '<button class="btn sm r" data-act="cancel" data-id="' + esc(t._id) + '">Cancel task</button>' : '') +
      (t.Archived ? '<button class="btn sm" data-act="restore" data-id="' + esc(t._id) + '">Restore</button>' : '<button class="btn sm" data-act="archive" data-id="' + esc(t._id) + '">Archive</button>') + '</div>';
  }
  foot += '</div>';
  return '<div class="scrim" data-act="closedrawer"></div><aside class="drawer" role="dialog" aria-label="Task details"><div class="dhd"><div style="flex:1 1 auto;min-width:0">' +
    '<div class="meta" style="font-weight:700;letter-spacing:.3px">' + esc(((t.Category || t.Kind || 'Task') + ' · ' + nameOf(t.OwnerEmail)).toUpperCase()) + '</div>' +
    '<label class="sr" for="f-title">Title</label><input id="f-title" class="ttl" data-f="Title" value="' + esc(titleOf(t)) + '"' + d + '>' +
    '<div style="display:flex;flex-wrap:wrap;gap:5px;margin-top:4px">' + chips.join('') + (t.AssignedByEmail && t.AssignedByEmail !== t.OwnerEmail ? chip('Assigned by ' + nameOf(t.AssignedByEmail), 'mag') : '') + '</div></div>' +
    '<button class="ib" style="color:var(--plum);border-color:var(--line)" data-act="closedrawer" aria-label="Close">×</button></div>' +
    '<div class="dbody" id="dbody">' + conflict + fields + (call || blk ? '' : subs) + withH + desc + sendBack + sbHist + convH + comments + hist + '</div>' + foot + '</aside>';
}
function descOf(t) {
  if (t.Visibility === 'Private' && t.OwnerEmail === S.myEmail) { var pv = S.privateMap['task|' + t.TaskKey]; return pv ? pv.Details : ''; }
  return t.Description || '';
}
function completeWarn(t) {
  if (!S.drawer || !S.drawer.warn) { return ''; }
  var open = R.openRequired(t.Subtasks || []);
  return '<div class="warn" style="margin-top:8px"><span><b>Can’t complete yet:</b> required still open — ' + esc(open.join(', ')) + '</span><span style="display:flex;gap:6px"><button class="btn sm" data-act="completeall" data-id="' + esc(t._id) + '">Complete all subtasks</button><button class="btn sm p" data-act="completeforce" data-id="' + esc(t._id) + '">Complete anyway</button></span></div>';
}
function subtree(t, nodes, depth, ro) {
  return nodes.map(function (n) {
    var d = ro ? ' disabled' : '', id = esc(t._id), nid = esc(n.id);
    var rec = n.done && n.doneAt ? '<span class="rec">Done ' + esc(fmtStamp(n.doneAt)) + ((n.with && n.with.length) ? ' · with ' + esc(n.with.map(function (p) { return p.name; }).join(', ')) : '') + '</span>' : '';
    var html = '<div class="st l' + depth + (n.done ? ' dn' : '') + '"><input type="checkbox"' + (n.done ? ' checked' : '') + d + ' data-act="subdone" data-id="' + id + '" data-node="' + nid + '" aria-label="Done: ' + esc(n.title) + '">' +
      '<label class="sr" for="n-' + nid + '">Subtask</label><input id="n-' + nid + '" class="stt" value="' + esc(n.title) + '" data-nf="title" data-id="' + id + '" data-node="' + nid + '"' + d + '>' +
      (n.required ? '<span class="c amb">Required</span>' : '') +
      (!n.done ? (n.with || []).map(function (p, i) { return whoChip(p, ro ? '' : 'data-act="unwithnode" data-id="' + id + '" data-node="' + nid + '" data-i="' + i + '"'); }).join('') : '') + rec +
      (n.inviteSentAt ? '<span class="inv">Invite sent ' + esc(fmtStamp(n.inviteSentAt)) + '</span>' : '') +
      (n.loggedAt ? '<span class="c grn">Logged ' + esc(fmtStamp(n.loggedAt)) + '</span>' : '') +
      (ro ? '' : '<button class="add" data-act="pick" data-target="node" data-id="' + id + '" data-node="' + nid + '">+ with</button>' +
        '<button class="add" data-act="nodeinvite" data-id="' + id + '" data-node="' + nid + '" title="Mark Teams invite sent">' + (n.inviteSentAt ? 'Undo invite' : 'Invite sent') + '</button>' +
        '<button class="add" data-act="newlog" data-task="' + id + '" data-node="' + nid + '">Log</button>' +
        (depth < 3 ? '<button class="ico" data-act="addsub" data-id="' + id + '" data-node="' + nid + '" aria-label="Add sub-item" title="Add sub-item">＋</button>' : '') +
        '<button class="ico" data-act="reqsub" data-id="' + id + '" data-node="' + nid + '" aria-label="Toggle required" title="Required">★</button>' +
        '<button class="ico" data-act="delsub" data-id="' + id + '" data-node="' + nid + '" aria-label="Delete ' + esc(n.title) + '">✕</button>') + '</div>' +
      pickerHtml('node', t._id, n.id);
    return html + subtree(t, n.children || [], depth + 1, ro);
  }).join('');
}
function histHtml(t) {
  var h = S.drawer && S.drawer.history;
  var base = [];
  if (t.CompletedAt) { base.push('Completed ' + fmtStamp(t.CompletedAt) + (t.CompletedBy ? ' by ' + nameOf(t.CompletedBy) : '')); }
  if (t._created) { base.push('Created ' + fmtStamp(t._created) + (t.TemplateId ? ' from routine' : '')); }
  if (!h) { return esc(base.join(' · ')) + ' <button class="lnk" data-act="loadhist" data-id="' + esc(t._id) + '">Show full history</button>'; }
  return h.length ? h.map(function (a) { return '<div>' + esc(fmtStamp(a.At)) + ' — ' + esc(nameOf(a.Actor)) + ': ' + esc(a.Action) + (a.Detail ? ' · ' + esc(a.Detail) : '') + '</div>'; }).join('') : esc(base.join(' · '));
}
function sendBackHtml(t) {
  var sb = S.drawer.sendback;
  if (!sb) { return '<div class="sec"><button class="btn sm" data-act="sendbackopen">Send back to ' + esc(firstName(t.AssignedByEmail)) + '</button></div>'; }
  var reasons = ['Need more info', 'Can\'t meet date', 'Not mine', 'Already done', 'Other'];
  return '<div class="sec" style="background:#FFF7FB"><div class="h" style="color:var(--mag-d)">Send back to ' + esc(nameOf(t.AssignedByEmail)) + '</div>' +
    '<div class="opts">' + reasons.map(function (r) { return '<button class="opt' + (sb.reason === r ? ' on' : '') + '" data-act="sbreason" data-v="' + esc(r) + '">' + esc(r) + '</button>'; }).join('') + '</div>' +
    '<div class="fgrid" style="margin-top:8px"><div class="fld span2"><label for="sb-note">Note to ' + esc(firstName(t.AssignedByEmail)) + ' (required)</label><textarea id="sb-note" class="in' + (sb.err ? ' bad' : '') + '" rows="2" data-sb="note">' + esc(sb.note || '') + '</textarea></div>' +
    '<div class="fld"><label for="sb-date">Suggest a date</label><input type="date" id="sb-date" class="in" data-sb="suggest" value="' + esc(sb.suggest || '') + '"></div></div>' +
    (sb.err ? '<div class="err">' + esc(sb.err) + '</div>' : '') +
    '<div style="display:flex;justify-content:flex-end;gap:6px;margin-top:8px"><button class="btn sm" data-act="sendbackcancel">Cancel</button><button class="btn sm m" data-act="sendback" data-id="' + esc(t._id) + '">Send back</button></div></div>';
}

/* ---- people picker (contacts + team) ---- */
function pickerHtml(target, id, node) {
  var p = S.picker; if (!p || p.target !== target || String(p.id) !== String(id) || (node && p.node !== node) || (!node && p.node)) { return ''; }
  var q = lc(p.q || ''), list = [];
  activePeople().forEach(function (x) { list.push({ name: x.Title, role: x.JobTitle || 'Team', email: x.Email, team: true }); });
  S.contacts.forEach(function (c) { if (c.Active !== false) { list.push({ name: c.Title, role: c.Role, ntid: c.NTID, stores: c.Stores, email: c.Email, contactId: c._id }); } });
  var hits = list.filter(function (x) { return !q || lc(x.name + ' ' + x.role + ' ' + (x.ntid || '') + ' ' + (x.stores || '')).indexOf(q) >= 0; }).slice(0, 8);
  return '<div class="pick" role="dialog" aria-label="Pick a person"><input id="pick-q" class="in" placeholder="Search name, store or NTID" value="' + esc(p.q || '') + '" data-act="pickq" autocomplete="off">' +
    hits.map(function (x, i) { return '<button class="po" data-act="pickone" data-i="' + i + '">' + whoChip(x) + '<span class="meta">' + esc(x.stores || '') + '</span></button>'; }).join('') +
    (q && !hits.length ? '<div class="meta" style="padding:4px">No match.</div>' : '') +
    '<div style="display:flex;justify-content:space-between;gap:6px;border-top:1px solid var(--line2);padding-top:6px;flex-wrap:wrap">' +
    (q ? '<span style="display:flex;gap:4px;align-items:center"><label class="sr" for="pick-role">Role</label><select id="pick-role" class="in" style="height:28px;width:auto">' + opts(ROLES, 'Store Manager') + '</select><button class="add" data-act="picknew">+ Add “' + esc(p.q) + '”</button></span>' : '<span></span>') +
    '<button class="btn xs p" data-act="pickclose">Done</button></div></div>';
}
function pickerList() {
  var p = S.picker, q = lc(p.q || ''), list = [];
  activePeople().forEach(function (x) { list.push({ name: x.Title, role: x.JobTitle || 'Team', email: x.Email, team: true }); });
  S.contacts.forEach(function (c) { if (c.Active !== false) { list.push({ name: c.Title, role: c.Role, ntid: c.NTID, stores: c.Stores, email: c.Email, contactId: c._id }); } });
  return list.filter(function (x) { return !q || lc(x.name + ' ' + x.role + ' ' + (x.ntid || '') + ' ' + (x.stores || '')).indexOf(q) >= 0; }).slice(0, 8);
}

/* ================= modals ================= */
function modalHtml() {
  var m = S.modal, body = '';
  if (m.type === 'task') { body = taskModal(m); }
  else if (m.type === 'log') { body = logModal(m); }
  else if (m.type === 'raise') { body = raiseModal(m); }
  else if (m.type === 'routine') { body = routineModal(m); }
  else if (m.type === 'person') { body = personModal(m); }
  else if (m.type === 'contact') { body = contactModal(m); }
  else if (m.type === 'confirm') { body = '<div class="modal sm" role="alertdialog" aria-label="Confirm"><div class="mhd"><h2>' + esc(m.title) + '</h2></div><div class="mbody">' + esc(m.text) + '</div><div class="dft" style="justify-content:flex-end"><button class="btn sm" data-act="closemodal">' + esc(m.no || 'Cancel') + '</button><button class="btn sm p" data-act="confirmyes">' + esc(m.yes || 'OK') + '</button></div></div>'; }
  else if (m.type === 'scope') { body = '<div class="modal sm" role="alertdialog" aria-label="Apply change to"><div class="mhd"><h2>Change a routine item</h2></div><div class="mbody">Apply this change to just this occurrence, or to this and all future ones? Completed history is never changed.</div><div class="dft" style="justify-content:flex-end"><button class="btn sm" data-act="scope" data-v="one">This occurrence</button><button class="btn sm p" data-act="scope" data-v="future">This and future</button></div></div>'; }
  return '<div class="scrim" data-act="' + (m.type === 'log' ? 'closelog' : 'closemodal') + '"></div>' + body;
}
function taskModal(m) {
  var me = S.myEmail, f = m.f, owner = f.OwnerEmail, w = workOf(owner);
  var people = activePeople();
  var off = f.PlannedDate && !R.isWorkDay(w, f.PlannedDate);
  return '<div class="modal" role="dialog" aria-label="Add task"><div class="mhd"><h2>' + (owner === me ? 'Add Task' : 'Assign Task') + '</h2><span class="pill">' + (m.saving ? 'Saving…' : 'Unsaved') + '</span></div><div class="mbody" id="mbody">' +
    '<div class="fgrid">' +
    '<div class="fld spanall"><label for="t-title">Title *</label><input id="t-title" class="in' + (m.err && !f.Title ? ' bad' : '') + '" data-mf="Title" value="' + esc(f.Title) + '"></div>' +
    '<div class="fld spanall"><span class="lbl">Assign to</span><div class="opts">' + people.map(function (p) { return '<button class="opt' + (owner === p.Email ? ' on' : '') + '" data-act="mset" data-k="OwnerEmail" data-v="' + esc(p.Email) + '">' + esc(p.Email === me ? 'Me' : p.Title + (p.JobTitle ? ' · ' + p.JobTitle : '')) + '</button>'; }).join('') + '</div></div>' +
    '<div class="fld"><label for="t-kind">Type</label><select id="t-kind" class="in" data-mf="Kind">' + opt('Task', f.Kind) + opt('Call', f.Kind, 'Call / meeting') + opt('Block', f.Kind, 'Work block') + '</select></div>' +
    '<div class="fld"><label for="t-cat">Category</label><input id="t-cat" class="in" list="catlist2" data-mf="Category" value="' + esc(f.Category) + '"><datalist id="catlist2">' + myCategories().map(function (c) { return '<option value="' + esc(c) + '">'; }).join('') + '</datalist></div>' +
    '<div class="fld"><label for="t-plan">Planned date *</label><input type="date" id="t-plan" class="in" data-mf="PlannedDate" value="' + esc(f.PlannedDate) + '"></div>' +
    '<div class="fld"><label for="t-due">Due date</label><input type="date" id="t-due" class="in" data-mf="DueDate" value="' + esc(f.DueDate) + '"></div>' +
    (off ? '<div class="warn spanall"><span><b>' + esc(R.fmtDate(f.PlannedDate)) + ' is an off day for ' + esc(owner === me ? 'you' : firstName(owner)) + '.</b> Next work day is ' + esc(R.fmtDate(R.nextWorkDayOnOrAfter(w, f.PlannedDate))) + '.</span><button class="btn sm p" data-act="mset" data-k="PlannedDate" data-v="' + esc(R.nextWorkDayOnOrAfter(w, f.PlannedDate)) + '">Move it</button></div>' : '') +
    '<div class="fld"><label for="t-pri">Priority</label><select id="t-pri" class="in" data-mf="Priority">' + opts(['High', 'Normal', 'Low'], f.Priority) + '</select></div>' +
    '<div class="fld"><label for="t-st">Start time</label><input type="time" id="t-st" class="in" data-mf="StartTime" value="' + esc(f.StartTime) + '"></div>' +
    '<div class="fld"><label for="t-dur">Minutes</label><input type="number" min="0" step="5" id="t-dur" class="in" data-mf="DurationMin" value="' + esc(f.DurationMin) + '" placeholder="Not set"></div>' +
    '<div class="fld"><label for="t-roll">If unfinished</label><select id="t-roll" class="in" data-mf="Rollover">' + opt('Roll', f.Rollover, 'Roll to next work day') + opt('Stay', f.Rollover, 'Stay on its date') + '</select></div>' +
    '<div class="fld spanall"><span class="lbl">Repeats</span><div class="opts">' + [['once', 'One-time'], ['workdays', 'Every work day'], ['weekly', 'Weekly on…']].map(function (x) { return '<button class="opt' + (f.repeat === x[0] ? ' on' : '') + '" data-act="mset" data-k="repeat" data-v="' + x[0] + '">' + x[1] + '</button>'; }).join('') + '</div>' +
    (f.repeat === 'weekly' ? '<div class="opts" style="margin-top:6px">' + R.DOW.map(function (dn, i) { return '<button class="dayb' + (f.days.charAt(i) === '1' ? ' on' : '') + '" data-act="mday" data-i="' + i + '" aria-pressed="' + (f.days.charAt(i) === '1') + '">' + dn.slice(0, 2) + '</button>'; }).join('') + '</div>' : '') +
    (f.repeat !== 'once' && f.Kind === 'Task' ? '<label style="display:flex;gap:6px;align-items:center;margin-top:6px;font-size:12px"><input type="checkbox" data-mf="independent"' + (f.independent ? ' checked' : '') + '> New, separate task every time (e.g. payroll) instead of carrying the open one</label>' : '') + '</div>' +
    '<div class="fld spanall"><label for="t-desc">Description</label><textarea id="t-desc" class="in" rows="2" data-mf="Description">' + esc(f.Description) + '</textarea></div>' +
    '<div class="spanall" style="background:var(--lav2);border-radius:8px;padding:8px 10px">' +
    (owner === me ? '<label style="display:flex;gap:8px;align-items:center;font-weight:700;color:var(--plum)"><input type="checkbox" data-mf="Private"' + (f.Private ? ' checked' : '') + ' style="width:16px;height:16px;accent-color:var(--plum)"> Private — only you see the details</label>' +
      (f.Private ? '<div class="fgrid" style="margin-top:8px"><div class="fld"><label for="t-pl">What the team sees</label><select id="t-pl" class="in" data-mf="PublicLabel">' + opts(['Private', 'Confidential HR', 'Personal appt', 'Busy'], f.PublicLabel) + '</select></div></div>' : '') :
      '<span class="meta">Private items can only be created by their owner.</span>') + '</div>' +
    '</div>' + (m.err ? '<div class="err" style="margin-top:8px">' + esc(m.err) + '</div>' : '') + '</div>' +
    '<div class="dft" style="justify-content:flex-end"><button class="btn sm" data-act="closemodal">Cancel</button><button class="btn sm p" data-act="savetask"' + (m.saving ? ' disabled' : '') + '>' + esc(owner === me ? 'Add task' : 'Assign to ' + firstName(owner)) + '</button></div></div>';
}
function logModal(m) {
  var f = m.f, st = m.state || 'Unsaved';
  var pill = st === 'Saved' ? 'ok' : st === 'Save failed' ? 'bad' : '';
  var linked = f.LinkedTaskKey ? (function () { var t = taskByKey(f.LinkedTaskKey); var n = t && f.LinkedNodeId ? R.findNode(t.Subtasks || [], f.LinkedNodeId) : null; return (t ? titleOf(t) : 'Task') + (n ? ' › ' + n.title : ''); }()) : '';
  return '<div class="modal" role="dialog" aria-label="Log Conversation"><div class="mhd"><h2>' + (m.editId ? 'Edit Conversation' : 'Log Conversation') + '</h2><span class="pill ' + pill + '">' + esc(st === 'Draft' ? 'Draft · autosaved ' + (m.draftAt || '') : st) + '</span></div><div class="mbody" id="mbody"><div class="fgrid">' +
    '<div class="fld spanall"><span class="lbl">People *</span><div class="chipbox' + (m.err && !f.People.length ? ' in bad' : '') + '">' + f.People.map(function (p, i) { return whoChip(p, 'data-act="unlogperson" data-i="' + i + '"'); }).join('') +
    '<button class="add" data-act="pick" data-target="log" data-id="log">+ person</button></div>' + pickerHtml('log', 'log') + '</div>' +
    '<div class="fld"><label for="l-date">Date *</label><input type="date" id="l-date" class="in" data-lf="date" value="' + esc(f.date) + '"></div>' +
    '<div class="fld"><label for="l-time">Time</label><input type="time" id="l-time" class="in" data-lf="time" value="' + esc(f.time) + '"></div>' +
    '<div class="fld"><label for="l-method">Method</label><select id="l-method" class="in" data-lf="Method">' + opts(METHODS, f.Method) + '</select></div>' +
    '<div class="fld"><label for="l-stores">Stores / book of business</label><input id="l-stores" class="in" data-lf="Stores" value="' + esc(f.Stores) + '" placeholder="Fills from the people you pick"></div>' +
    '<div class="fld spanall"><label for="l-topic">Topic</label><input id="l-topic" class="in" data-lf="Title" value="' + esc(f.Title) + '"></div>' +
    '<div class="fld spanall"><label for="l-notes">Discussion notes *</label><textarea id="l-notes" class="in' + (m.err && !f.Discussion.trim() ? ' bad' : '') + '" rows="5" data-lf="Discussion">' + esc(f.Discussion) + '</textarea></div>' +
    '<div class="fld"><label for="l-out">Outcome / decision</label><input id="l-out" class="in" data-lf="Outcome" value="' + esc(f.Outcome) + '"></div>' +
    '<div class="fld"><label for="l-vis">Visibility</label><select id="l-vis" class="in" data-lf="Visibility">' + opt('Private', f.Visibility, 'Private — only me') + opt('Shared', f.Visibility, 'Shared with team') + '</select></div>' +
    (linked ? '<div class="fld spanall"><span class="lbl">Linked to</span><div style="display:flex;gap:6px;align-items:center">' + chip(linked) + '<button class="lnk" data-act="unlink">Remove link</button></div></div>' : '') +
    (m.editId ? '' : '<div class="spanall" style="background:var(--lav);border-radius:8px;padding:8px 10px"><label style="display:flex;gap:8px;align-items:center;font-weight:700;color:var(--plum)"><input type="checkbox" data-lf="WantsFollowUp"' + (f.WantsFollowUp ? ' checked' : '') + ' style="width:16px;height:16px;accent-color:var(--plum)"> Create follow-up task</label>' +
      (f.WantsFollowUp ? '<div class="fgrid" style="margin-top:8px"><div class="fld"><label for="l-na">Next action *</label><input id="l-na" class="in' + (m.err && !f.NextAction ? ' bad' : '') + '" data-lf="NextAction" value="' + esc(f.NextAction) + '"></div><div class="fld"><label for="l-fd">Planned date *</label><input type="date" id="l-fd" class="in' + (m.err && !f.FollowUpDate ? ' bad' : '') + '" data-lf="FollowUpDate" value="' + esc(f.FollowUpDate) + '"></div></div>' : '') + '</div>') +
    '</div>' + (m.err ? '<div class="err" style="margin-top:8px">' + esc(m.err) + '</div>' : '') + '</div>' +
    '<div class="dft"><span class="meta">Manual notes · nothing is sent to anyone</span><span style="display:flex;gap:6px"><button class="btn sm" data-act="closelog">Discard…</button><button class="btn sm p" data-act="savelog"' + (st === 'Saving…' ? ' disabled' : '') + '>' + (f.WantsFollowUp && !m.editId ? 'Save note + task' : 'Save note') + '</button></span></div></div>';
}
function taskByKey(k) { var all = allTasks(), i; for (i = 0; i < all.length; i++) { if (all[i].TaskKey === k) { return all[i]; } } return null; }

/* ================= conversation log ================= */
function noteRow(n) {
  var people = (n.People || []).map(function (p) { return whoChip(p); }).join('');
  var t = n.LinkedTaskKey ? taskByKey(n.LinkedTaskKey) : null;
  return '<div class="r" style="align-items:flex-start;flex-wrap:wrap;gap:12px;cursor:default"><div style="flex:0 0 130px"><b style="color:var(--plum);display:block">' + esc(R.fmtShort(n.ConvDate)) + '</b><span class="meta">' + esc(n.ConvAt ? R.fmtTime(R.nyNow(new Date(n.ConvAt)).time) : '') + ' · ' + esc(n.Method) + '</span>' +
    (n._created && n.ConvDate && R.nyNow(new Date(n._created)).date !== n.ConvDate ? '<div class="meta">Logged ' + esc(fmtStamp(n._created)) + '</div>' : '') + '</div>' +
    '<div style="flex:1 1 360px;min-width:0;display:flex;flex-direction:column;gap:4px"><div style="display:flex;flex-wrap:wrap;gap:4px">' + people + (n.Stores ? chip(n.Stores, 'gry') : '') + chip(n.Visibility === 'Shared' ? 'Shared with team' : 'Private', n.Visibility === 'Shared' ? 'grn' : 'gry') + (n.OwnerEmail !== S.myEmail ? chip('By ' + firstName(n.OwnerEmail)) : '') + '</div>' +
    (n.Title ? '<div><b>Topic:</b> ' + esc(n.Title) + '</div>' : '') + '<div style="white-space:pre-wrap">' + esc(n.Discussion) + '</div>' +
    (n.Outcome ? '<div><b>Outcome:</b> ' + esc(n.Outcome) + '</div>' : '') +
    (n.NextAction ? '<div><b>Next:</b> ' + esc(n.NextAction) + (n.FollowUpDate ? ' · ' + esc(R.fmtShort(n.FollowUpDate)) : '') + '</div>' : '') +
    '<div style="display:flex;gap:10px;flex-wrap:wrap">' + (t ? '<button class="lnk" data-act="open" data-id="' + esc(t._id) + '">Open linked task</button>' : '') +
    (n.FollowUpTaskKey && taskByKey(n.FollowUpTaskKey) ? '<button class="lnk" data-act="open" data-id="' + esc(taskByKey(n.FollowUpTaskKey)._id) + '">Open follow-up</button>' : '') +
    (n.OwnerEmail === S.myEmail ? '<button class="lnk" data-act="editnote" data-list="' + (n.Visibility === 'Shared' ? 'BOCC_SharedNotes' : 'BOCC_Notes') + '" data-id="' + esc(n._id) + '">Edit</button>' +
      (n.Archived ? '<button class="lnk" data-act="archnote" data-v="0" data-list="' + (n.Visibility === 'Shared' ? 'BOCC_SharedNotes' : 'BOCC_Notes') + '" data-id="' + esc(n._id) + '">Restore</button>' : '<button class="lnk" data-act="archnote" data-v="1" data-list="' + (n.Visibility === 'Shared' ? 'BOCC_SharedNotes' : 'BOCC_Notes') + '" data-id="' + esc(n._id) + '">Archive</button>') : '') +
    (n.EditedAt ? '<span class="meta">Edited ' + esc(fmtStamp(n.EditedAt)) + '</span>' : '') + '</div></div></div>';
}
function filteredNotes() {
  var F = S.logF || (S.logF = { q: '', person: '', role: '', store: '', from: '', to: '', show: 'all', archived: false });
  return S.notes.concat(S.shared).filter(function (n) {
    if (!F.archived && n.Archived) { return false; }
    if (F.show === 'mine' && n.OwnerEmail !== S.myEmail) { return false; }
    if (F.show === 'shared' && n.Visibility !== 'Shared') { return false; }
    if (F.from && n.ConvDate < F.from) { return false; }
    if (F.to && n.ConvDate > F.to) { return false; }
    if (F.role && !(n.People || []).some(function (p) { return p.role === F.role; })) { return false; }
    if (F.person && JSON.stringify(n.People || []).toLowerCase().indexOf(lc(F.person)) < 0) { return false; }
    if (F.store && lc(n.Stores).indexOf(lc(F.store)) < 0) { return false; }
    if (F.q && lc([n.Title, n.Discussion, n.Outcome, n.NextAction, JSON.stringify(n.People)].join(' ')).indexOf(lc(F.q)) < 0) { return false; }
    return true;
  }).sort(function (a, b) { return (b.ConvAt || b.ConvDate) > (a.ConvAt || a.ConvDate) ? 1 : -1; });
}
function logView() {
  var F = S.logF || (S.logF = { q: '', person: '', role: '', store: '', from: '', to: '', show: 'all', archived: false });
  var list = filteredNotes();
  return '<div style="display:flex;flex-direction:column;gap:10px"><div style="display:flex;flex-wrap:wrap;justify-content:space-between;gap:8px;align-items:center"><h1 class="pg">Conversation Log</h1>' +
    '<div style="display:flex;gap:6px;flex-wrap:wrap"><button class="btn sm m" data-act="newlog">Log Conversation</button><button class="btn sm" data-act="exportnotes" data-v="csv">Export CSV</button><button class="btn sm" data-act="exportnotes" data-v="json">Export JSON</button></div></div>' +
    '<div class="card" style="padding:10px 12px;display:flex;flex-direction:column;gap:8px"><div class="fgrid c4">' +
    '<div class="fld"><label for="lf-q">Search text</label><input id="lf-q" class="in" data-lfil="q" value="' + esc(F.q) + '"></div>' +
    '<div class="fld"><label for="lf-p">Person / NTID</label><input id="lf-p" class="in" data-lfil="person" value="' + esc(F.person) + '"></div>' +
    '<div class="fld"><label for="lf-s">Store</label><input id="lf-s" class="in" data-lfil="store" value="' + esc(F.store) + '"></div>' +
    '<div class="fld"><label for="lf-r">Role</label><select id="lf-r" class="in" data-lfil="role">' + opt('', F.role, 'All roles') + opts(ROLES, F.role) + '</select></div>' +
    '<div class="fld"><label for="lf-f">From</label><input type="date" id="lf-f" class="in" data-lfil="from" value="' + esc(F.from) + '"></div>' +
    '<div class="fld"><label for="lf-t">To</label><input type="date" id="lf-t" class="in" data-lfil="to" value="' + esc(F.to) + '"></div>' +
    '<div class="fld"><label for="lf-sh">Show</label><select id="lf-sh" class="in" data-lfil="show">' + opt('all', F.show, 'Mine + shared') + opt('mine', F.show, 'Only mine') + opt('shared', F.show, 'Shared with team') + '</select></div>' +
    '<div class="fld"><span class="lbl">Archived</span><label style="display:flex;gap:6px;align-items:center;height:34px"><input type="checkbox" data-lfil="archived"' + (F.archived ? ' checked' : '') + '> Include archived</label></div>' +
    '</div></div><div class="card"><div class="gh">Conversations <span>' + list.length + '</span></div>' + (list.length ? list.map(noteRow).join('') : '<div class="empty">No conversations yet. Use Log Conversation to add one.</div>') + '</div></div>';
}

/* ================= raises ================= */
function raisesView() {
  var tab = S.raiseTab || 'Submitted', sel = S.raiseSel;
  var me = S.me || {}, approver = me.Raises === 'Approve', submitter = me.Raises === 'Submit' || S.admin;
  var tabs = ['Submitted', 'Returned', 'Approved', 'Denied', 'Draft'];
  var rows = S.raises.filter(function (r) { return r.Status === tab; }).sort(function (a, b) { return (b.SubmittedAt || '') > (a.SubmittedAt || '') ? 1 : -1; });
  var cur = null; S.raises.forEach(function (r) { if (r._id === sel) { cur = r; } });
  var list = '<section class="card" style="flex:1 1 320px;max-width:420px"><div style="display:flex;gap:6px;flex-wrap:wrap;padding:8px;background:var(--lav)">' + tabs.map(function (t) {
    var n = S.raises.filter(function (r) { return r.Status === t; }).length;
    return '<button class="opt' + (tab === t ? ' on' : '') + '" data-act="raisetab" data-v="' + t + '">' + esc(t === 'Submitted' ? (approver ? 'Awaiting me' : 'Awaiting CEO') : t) + ' · ' + n + '</button>';
  }).join('') + '</div>' + (rows.length ? rows.map(function (r) {
    return '<div class="r" data-act="raisesel" data-id="' + esc(r._id) + '" style="flex-direction:column;align-items:stretch;gap:2px' + (r._id === sel ? ';background:var(--lav2);box-shadow:inset 4px 0 0 var(--plum)' : '') + '"><div style="display:flex;justify-content:space-between;gap:8px"><b>' + esc(r.Title) + '</b>' + chip(r.Status, r.Status === 'Approved' ? 'grn' : r.Status === 'Denied' ? 'red' : r.Status === 'Returned' ? 'blu' : 'amb') + '</div>' +
      '<span class="meta">' + esc([r.NTID, r.Store, r.Position].filter(Boolean).join(' · ')) + '</span><span class="meta">$' + esc(r.CurrentRate) + ' → $' + esc(r.ProposedRate) + (r.EffectiveDate ? ' · eff. ' + esc(R.fmtShort(r.EffectiveDate)) : '') + '</span></div>';
  }).join('') : '<div class="empty">None.</div>') + '</section>';
  var det = '<section class="card" style="flex:999 1 520px;min-width:0">' + (cur ? raiseDetail(cur, approver) : '<div class="empty">Pick a request.</div>') + '</section>';
  return '<div style="display:flex;flex-direction:column;gap:10px"><div style="display:flex;flex-wrap:wrap;gap:8px;justify-content:space-between;align-items:center"><div><h1 class="pg">Raise Requests</h1><div class="meta">Visible only to HR and the CEO</div></div>' +
    (submitter ? '<button class="btn m sm" data-act="newraise">+ New raise request</button>' : '') + '</div><div class="cols">' + list + det + '</div></div>';
}
function raiseDetail(r, approver) {
  var ch = R.raiseChange(r.CurrentRate, r.ProposedRate);
  function cell(k, v) { return '<div style="background:var(--lav2);border:1px solid var(--line2);border-radius:8px;padding:8px 10px"><div class="meta" style="font-weight:600">' + esc(k) + '</div><div style="font-size:16px;font-weight:700">' + esc(v) + '</div></div>'; }
  var canDecide = approver && r.Status === 'Submitted';
  var canEdit = !approver && (r.Status === 'Returned' || r.Status === 'Draft');
  return '<div style="padding:14px 16px;border-bottom:1px solid var(--line2);display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap"><div><div class="meta" style="font-weight:700">RAISE REQUEST · ' + esc(r.RequestKey) + '</div><div style="font-size:20px;font-weight:700;color:var(--plum)">' + esc(r.Title) + (r.NTID ? ' · ' + esc(r.NTID) : '') + '</div><div class="meta">' + esc([r.Store, r.Position].filter(Boolean).join(' · ')) + '</div></div>' + chip(r.Status, 'amb') + '</div>' +
    '<div style="padding:14px 16px;display:flex;flex-direction:column;gap:12px"><div class="fgrid c3">' + cell('Current rate', '$' + r.CurrentRate + '/hr') + cell('Proposed rate', '$' + r.ProposedRate + '/hr') + cell('Change', ch ? (ch.amount >= 0 ? '+' : '') + '$' + ch.amount.toFixed(2) + ' · ' + ch.pct + '%' : '—') +
    cell('Effective', R.fmtShort(r.EffectiveDate) || '—') + cell('Reason', r.Reason || '—') + cell('Last raise', r.LastRaise ? R.fmtShort(r.LastRaise) || r.LastRaise : '—') + '</div>' +
    '<div><div class="h">HR justification</div><div style="white-space:pre-wrap">' + esc(r.Justification) + '</div></div>' +
    '<div><div class="h">Attachments</div><div id="raise-att" class="meta">' + (S.raiseAtt && S.raiseAtt.id === r._id ? (S.raiseAtt.files.length ? S.raiseAtt.files.map(function (f) { return '<a href="' + esc(CONFIG.spHost + f.ServerRelativeUrl) + '" target="_blank" rel="noopener">' + esc(f.FileName) + '</a>'; }).join(' · ') : 'None') : '<button class="lnk" data-act="raiseatt" data-id="' + esc(r._id) + '">Show attachments</button>') + '</div></div>' +
    (r.CeoComment ? '<div><div class="h">CEO comment</div><div style="white-space:pre-wrap">' + esc(r.CeoComment) + '</div></div>' : '') +
    (canDecide ? '<div class="fld"><label for="ceo-c">CEO comment (required to deny or return)</label><textarea id="ceo-c" class="in" rows="3"></textarea></div><div style="display:flex;gap:8px;justify-content:flex-end;flex-wrap:wrap"><button class="btn r" data-act="decide" data-v="Denied" data-id="' + esc(r._id) + '">Deny</button><button class="btn" data-act="decide" data-v="Returned" data-id="' + esc(r._id) + '">Return to HR</button><button class="btn g" data-act="decide" data-v="Approved" data-id="' + esc(r._id) + '">Approve</button></div>' : '') +
    (canEdit ? '<div style="display:flex;justify-content:flex-end"><button class="btn p" data-act="editraise" data-id="' + esc(r._id) + '">Edit and resubmit</button></div>' : '') +
    '<div style="background:var(--lav);border-radius:8px;padding:10px 12px;font-size:12px;line-height:1.6"><b style="color:var(--plum)">On approve:</b> HR gets a task to enter the approved raise in payroll. The app never changes pay itself.<br><b style="color:var(--plum)">History:</b> ' +
    (r.History || []).map(function (h) { return esc(fmtStamp(h.at) + ' — ' + h.what + ' by ' + nameOf(h.by)); }).join('<br>') + '</div></div>';
}
function raiseModal(m) {
  var f = m.f, ch = R.raiseChange(f.CurrentRate, f.ProposedRate);
  function fld(id, label, key, type, req) { return '<div class="fld"><label for="' + id + '">' + esc(label) + (req ? ' *' : '') + '</label><input id="' + id + '" class="in' + (m.err && req && !f[key] ? ' bad' : '') + '" ' + (type ? 'type="' + type + '" ' : '') + 'data-rf="' + key + '" value="' + esc(f[key]) + '"></div>'; }
  return '<div class="modal" role="dialog" aria-label="Raise request"><div class="mhd"><h2>' + (m.editId ? 'Edit Raise Request' : 'New Raise Request') + '</h2><span class="pill">' + (m.saving ? 'Saving…' : 'Draft') + '</span></div><div class="mbody" id="mbody"><div class="fgrid c3">' +
    '<div class="fld"><label for="r-emp">Employee name *</label><input id="r-emp" class="in' + (m.err && !f.Title ? ' bad' : '') + '" list="emplist" data-rf="Title" value="' + esc(f.Title) + '"><datalist id="emplist">' + S.contacts.map(function (c) { return '<option value="' + esc(c.Title) + '">' + esc(c.NTID || '') + '</option>'; }).join('') + '</datalist></div>' +
    fld('r-ntid', 'NTID', 'NTID') + fld('r-store', 'Store', 'Store') +
    '<div class="fld"><label for="r-pos">Position</label><select id="r-pos" class="in" data-rf="Position">' + opts(['Rep', 'Store Manager', 'Coach', 'Back office', 'Other'], f.Position) + '</select></div>' +
    fld('r-cur', 'Current rate ($/hr)', 'CurrentRate', 'number', true) + fld('r-pro', 'Proposed rate ($/hr)', 'ProposedRate', 'number', true) +
    '<div class="fld"><span class="lbl">Change</span><input id="r-chg" class="in" readonly value="' + esc(ch ? (ch.amount >= 0 ? '+' : '') + '$' + ch.amount.toFixed(2) + ' · ' + ch.pct + '%' : 'Calculated') + '" aria-label="Calculated change"></div>' +
    fld('r-eff', 'Effective date', 'EffectiveDate', 'date', true) +
    '<div class="fld"><label for="r-rs">Reason *</label><select id="r-rs" class="in" data-rf="Reason">' + opts(['Promotion', 'Merit / performance', 'Market adjustment', 'Added responsibilities', 'Other'], f.Reason) + '</select></div>' +
    fld('r-last', 'Last raise date', 'LastRaise', 'date') +
    '<div class="fld spanall"><label for="r-ju">Justification for the CEO *</label><textarea id="r-ju" class="in' + (m.err && !f.Justification ? ' bad' : '') + '" rows="5" data-rf="Justification">' + esc(f.Justification) + '</textarea></div>' +
    '<div class="fld spanall"><label for="r-file">Attach files</label><input type="file" id="r-file" multiple></div>' +
    '</div>' + (m.err ? '<div class="err" style="margin-top:8px">' + esc(m.err) + '</div>' : '') + '</div>' +
    '<div class="dft"><span class="meta">Goes to the CEO for approval · HR and CEO only</span><span style="display:flex;gap:6px"><button class="btn sm" data-act="closemodal">Cancel</button><button class="btn sm" data-act="saveraise" data-v="Draft">Save draft</button><button class="btn sm p" data-act="saveraise" data-v="Submitted"' + (m.saving ? ' disabled' : '') + '>Submit to CEO</button></span></div></div>';
}

/* ================= settings ================= */
function settingsView() {
  var p = prefsOf(S.myEmail), w = p.WorkDays || R.DEFAULT_WORKDAYS, themes = p.DayThemes || {};
  var days = R.DOW.map(function (dn, i) { var on = w.charAt(i) === '1'; return '<button class="dayb' + (on ? ' on' : '') + '" style="width:auto;flex:1 1 0;min-width:44px;height:52px;display:flex;flex-direction:column;align-items:center;justify-content:center" data-act="wday" data-i="' + i + '" aria-pressed="' + on + '">' + dn + '<span style="font-size:10px;font-weight:600">' + (on ? 'Work' : 'Off') + '</span></button>'; }).join('');
  var tps = templatesOf(S.myEmail).slice().sort(function (a, b) { return (a.SortOrder || 99) - (b.SortOrder || 99); });
  var stopped = S.templates.filter(function (t) { return t.OwnerEmail === S.myEmail && t.Active === false; });
  function dayStr(d) { if (d === '0111110') { return 'Mon–Fri'; } if (d === '1111111') { return 'Every day'; } return R.DOW.filter(function (x, i) { return (d || '').charAt(i) === '1'; }).join(', '); }
  var rt = tps.map(function (t) {
    return '<tr><td><b>' + esc(asRuleTpl(t).Title) + '</b>' + (t.Private ? ' ' + chip('Private', 'gry') : '') + '<div class="meta">' + esc(t.Category || '') + '</div></td><td>' + chip(t.Kind === 'Call' ? 'Call' : t.Kind === 'Block' ? 'Work block' : 'Task group', t.Kind === 'Call' ? 'plum' : t.Kind === 'Block' ? '' : 'blu') + '</td>' +
      '<td>' + esc(dayStr(t.Days)) + '</td><td>' + (t.StartTime ? esc(R.fmtTime(t.StartTime)) : t.AfterLabel ? esc(t.AfterLabel) : '<span style="color:var(--amb-t);font-weight:600">Not set</span>') + '</td>' +
      '<td>' + (t.DurationMin ? esc(t.DurationMin + ' min') : '<span style="color:var(--amb-t);font-weight:600">Not set</span>') + '</td>' +
      '<td class="meta" style="white-space:normal">' + esc(t.Kind === 'Call' ? 'Stays · Not recorded if missed' : t.Kind === 'Block' ? (t.Rollover === 'Roll' ? 'Rolls' : 'Stays on its day') : t.Rollover === 'Independent' ? 'New each time' + (t.Cycle ? ' · payroll cycle' : '') : t.Rollover === 'Stay' ? 'Stays' : 'Carry unfinished · no duplicate') + '</td>' +
      '<td style="white-space:nowrap"><button class="btn xs" data-act="editroutine" data-id="' + esc(t._id) + '">Edit</button> <button class="btn xs r" data-act="stoproutine" data-id="' + esc(t._id) + '">Stop</button></td></tr>';
  }).join('');
  var cats = (p.Categories || []);
  var html = '<div style="display:flex;flex-direction:column;gap:12px;max-width:1340px"><h1 class="pg">Settings</h1><div class="cols">' +
    '<section class="card" style="flex:1 1 440px;min-width:0"><div class="gh">My work days <span>Tap a day to set it off</span></div><div style="padding:12px;display:flex;flex-direction:column;gap:12px">' +
    '<div style="display:flex;gap:6px">' + days + '</div><div class="meta" style="white-space:normal">All 7 days always show on your calendar. Unfinished work rolls to your next work day.</div>' +
    '<div class="fgrid"><div class="fld"><label for="p-ds">Day starts</label><input type="time" id="p-ds" class="in" data-pf="DayStart" value="' + esc(p.DayStart) + '"></div><div class="fld"><label for="p-de">Day ends</label><input type="time" id="p-de" class="in" data-pf="DayEnd" value="' + esc(p.DayEnd) + '"></div>' +
    '<div class="fld"><label for="p-vis">New items default to</label><select id="p-vis" class="in" data-pf="DefaultVisibility">' + opt('Team', p.DefaultVisibility || 'Team', 'Team can see') + opt('Private', p.DefaultVisibility, 'Private') + '</select></div></div>' +
    '<div class="fld"><span class="lbl">Time off (treated as off days)</span><div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center">' + (p.TimeOff || []).map(function (d, i) { return '<span class="c gry">' + esc(R.fmtShort(d)) + ' <button class="ico" style="padding:0" data-act="deloff" data-i="' + i + '" aria-label="Remove">×</button></span>'; }).join('') +
    '<label class="sr" for="p-off">Add a day off</label><input type="date" id="p-off" class="in" style="width:auto"><button class="btn sm" data-act="addoff">Add</button></div></div></div></section>' +
    '<section class="card" style="flex:1 1 440px;min-width:0"><div class="gh">Day themes &amp; categories</div><div style="padding:12px;display:flex;flex-direction:column;gap:10px"><div class="fgrid">' +
    R.DOW.map(function (dn, i) { return '<div class="fld"><label for="th-' + i + '">' + dn + ' theme</label><input id="th-' + i + '" class="in" data-theme="' + i + '" value="' + esc(themes[i] || '') + '"></div>'; }).join('') + '</div>' +
    '<div class="fld"><span class="lbl">Categories (order sets the order on Today)</span><div style="display:flex;flex-direction:column;gap:4px">' + cats.map(function (c, i) { return '<div style="display:flex;gap:4px"><label class="sr" for="cat-' + i + '">Category</label><input id="cat-' + i + '" class="in" data-cat="' + i + '" value="' + esc(c) + '"><button class="btn xs" data-act="catup" data-i="' + i + '" aria-label="Move up">↑</button><button class="btn xs r" data-act="catdel" data-i="' + i + '" aria-label="Remove">×</button></div>'; }).join('') +
    '<button class="btn sm" data-act="catadd" style="align-self:flex-start">+ Add category</button></div><div class="meta">Renaming a category updates your open tasks and routines that use it.</div></div></div></section></div>' +
    '<section class="card"><div class="gh">My routines <span><button class="btn xs p" data-act="newroutine">+ Add routine</button> <label class="btn xs" style="cursor:pointer">Import JSON<input type="file" accept=".json" data-act="importroutines" class="sr"></label></span></div><div class="scrollx"><table class="tbl" style="min-width:860px"><thead><tr><th>Routine</th><th>Type</th><th>Days</th><th>Time</th><th>Length</th><th>If missed / unfinished</th><th></th></tr></thead><tbody>' +
    (rt || '<tr><td colspan="7" class="meta">No routines yet. Add the things you do every day or week.</td></tr>') + '</tbody></table></div>' +
    (stopped.length ? '<div class="meta" style="padding:8px 12px">Stopped (history kept): ' + stopped.map(function (t) { return esc(asRuleTpl(t).Title); }).join(', ') + '</div>' : '') + '</section>' +
    contactsCard() + (S.admin ? teamCard() : '') +
    '<section class="card"><div class="gh">Backup</div><div style="padding:12px;display:flex;flex-wrap:wrap;gap:8px;align-items:center"><button class="btn sm" data-act="backup" data-v="json">Export everything (JSON)</button><button class="btn sm" data-act="backup" data-v="tasks">Tasks (CSV)</button><button class="btn sm" data-act="exportnotes" data-v="csv">Notes (CSV)</button><span class="meta">Includes history and original dates.</span></div></section></div>';
  return html;
}
function contactsCard() {
  var q = lc(S.contactQ || '');
  var list = S.contacts.filter(function (c) { return !q || lc(c.Title + ' ' + c.NTID + ' ' + c.Stores + ' ' + c.Role + ' ' + c.Coach).indexOf(q) >= 0; }).sort(function (a, b) { return a.Title < b.Title ? -1 : 1; });
  var counts = {}; S.contacts.forEach(function (c) { counts[c.Role || 'Other'] = (counts[c.Role || 'Other'] || 0) + 1; });
  return '<section class="card"><div class="gh">Contacts <span>' + Object.keys(counts).map(function (k) { return esc(k) + ' ' + counts[k]; }).join(' · ') + '</span></div><div style="padding:10px 12px;display:flex;gap:8px;flex-wrap:wrap;align-items:center">' +
    '<label class="sr" for="c-q">Search contacts</label><input id="c-q" class="in" style="max-width:280px" placeholder="Search name, NTID, store" value="' + esc(S.contactQ || '') + '" data-act="contactq"><button class="btn sm p" data-act="newcontact">+ Add person</button>' +
    '<label class="btn sm" style="cursor:pointer">Import CSV<input type="file" accept=".csv" class="sr" data-act="importcontacts"></label><span class="meta">CSV columns: Name, Role, NTID, Stores, Email, Phone, Coach</span></div>' +
    '<div class="scrollx" style="max-height:360px;overflow:auto"><table class="tbl"><thead><tr><th>Name</th><th>Role</th><th>NTID</th><th>Stores</th><th>Coach</th><th>Email</th><th></th></tr></thead><tbody>' +
    list.slice(0, 300).map(function (c) { return '<tr' + (c.Active === false ? ' style="opacity:.5"' : '') + '><td><b>' + esc(c.Title) + '</b></td><td>' + esc(c.Role) + '</td><td>' + esc(c.NTID) + '</td><td>' + esc(c.Stores) + '</td><td>' + esc(c.Coach) + '</td><td>' + esc(c.Email) + '</td><td><button class="btn xs" data-act="editcontact" data-id="' + esc(c._id) + '">Edit</button></td></tr>'; }).join('') +
    (list.length ? '' : '<tr><td colspan="7" class="meta">No contacts yet.</td></tr>') + '</tbody></table></div></section>';
}
function teamCard() {
  return '<section class="card"><div class="gh">Team &amp; access <span>Admin only · <button class="btn xs p" data-act="newperson">+ Add team member</button></span></div><div class="scrollx"><table class="tbl"><thead><tr><th>Person</th><th>Reports to</th><th>Access</th><th>Raises</th><th>Active</th><th></th></tr></thead><tbody>' +
    S.people.slice().sort(function (a, b) { return (a.SortOrder || 99) - (b.SortOrder || 99); }).map(function (p) {
      return '<tr><td><b>' + esc(p.Title) + '</b><div class="meta">' + esc(p.JobTitle) + ' · ' + esc(p.Email) + '</div></td><td>' + esc(p.ReportsTo ? nameOf(p.ReportsTo) : '—') + '</td><td>' + chip(p.Access || 'Member', p.Access === 'Executive' ? 'plum' : p.Access === 'Manager' ? 'blu' : '') + '</td><td>' + esc(p.Raises || '—') + '</td><td>' + (p.Active === false ? 'No' : 'Yes') + '</td><td><button class="btn xs" data-act="editperson" data-id="' + esc(p._id) + '">Edit</button></td></tr>';
    }).join('') + '</tbody></table></div><div class="meta" style="padding:8px 12px">New people also need site access: use Setup → Grant site access after adding them.</div></section>';
}
function routineModal(m) {
  var f = m.f;
  return '<div class="modal" role="dialog" aria-label="Routine"><div class="mhd"><h2>' + (m.editId ? 'Edit Routine' : 'Add Routine') + '</h2></div><div class="mbody" id="mbody"><div class="fgrid">' +
    '<div class="fld spanall"><label for="rt-t">Title *</label><input id="rt-t" class="in' + (m.err && !f.Title ? ' bad' : '') + '" data-tf="Title" value="' + esc(f.Title) + '"></div>' +
    '<div class="fld"><label for="rt-k">Type</label><select id="rt-k" class="in" data-tf="Kind">' + opt('Task', f.Kind, 'Task group (checklist)') + opt('Call', f.Kind, 'Call / meeting') + opt('Block', f.Kind, 'Work block') + '</select></div>' +
    '<div class="fld"><label for="rt-c">Category</label><input id="rt-c" class="in" list="catlist3" data-tf="Category" value="' + esc(f.Category) + '"><datalist id="catlist3">' + myCategories().map(function (c) { return '<option value="' + esc(c) + '">'; }).join('') + '</datalist></div>' +
    '<div class="fld spanall"><span class="lbl">Days</span><div class="opts">' + R.DOW.map(function (dn, i) { return '<button class="dayb' + (f.Days.charAt(i) === '1' ? ' on' : '') + '" data-act="tday" data-i="' + i + '">' + dn.slice(0, 2) + '</button>'; }).join('') + '</div></div>' +
    '<div class="fld"><label for="rt-st">Start time</label><input type="time" id="rt-st" class="in" data-tf="StartTime" value="' + esc(f.StartTime) + '"></div>' +
    '<div class="fld"><label for="rt-d">Minutes</label><input type="number" id="rt-d" min="0" step="5" class="in" data-tf="DurationMin" value="' + esc(f.DurationMin) + '" placeholder="Not set"></div>' +
    '<div class="fld"><label for="rt-al">Time label if no start time</label><input id="rt-al" class="in" data-tf="AfterLabel" value="' + esc(f.AfterLabel) + '" placeholder="e.g. Morning, After 5 PM call"></div>' +
    '<div class="fld"><label for="rt-r">If unfinished</label><select id="rt-r" class="in" data-tf="Rollover">' + (f.Kind === 'Task' ? opt('Carry', f.Rollover, 'Carry the open one · no duplicate') + opt('Independent', f.Rollover, 'New, separate one each time') + opt('Stay', f.Rollover, 'Stay on its day') : f.Kind === 'Block' ? opt('Stay', f.Rollover, 'Stay on its day') + opt('Roll', f.Rollover, 'Roll to next work day') : opt('Stay', 'Stay', 'Stays · marked Not recorded')) + '</select></div>' +
    (f.Kind === 'Task' ? '<div class="fld"><label for="rt-cy">Payroll cycle</label><select id="rt-cy" class="in" data-tf="Cycle">' + opt('', f.Cycle, 'No') + opt('payroll', f.Cycle, 'Yes — tie to this week’s payroll') + '</select></div>' : '') +
    '<div class="fld"><label for="rt-sd">Starts</label><input type="date" id="rt-sd" class="in" data-tf="StartDate" value="' + esc(f.StartDate) + '"></div>' +
    '<div class="fld"><label for="rt-ed">Ends (optional)</label><input type="date" id="rt-ed" class="in" data-tf="EndDate" value="' + esc(f.EndDate) + '"></div>' +
    (f.Kind === 'Task' ? '<div class="fld spanall"><label for="rt-items">Checklist — one per line. Start a line with “- ” for a sub-item, “-- ” for a third level, end with “ *” if required.</label><textarea id="rt-items" class="in" rows="7" data-tf="itemsText">' + esc(f.itemsText) + '</textarea></div>' : '') +
    '<div class="spanall"><label style="display:flex;gap:8px;align-items:center;font-weight:700;color:var(--plum)"><input type="checkbox" data-tf="Private"' + (f.Private ? ' checked' : '') + '> Private routine</label>' + (f.Private ? '<div class="fld" style="margin-top:6px;max-width:300px"><label for="rt-pl">What the team sees</label><select id="rt-pl" class="in" data-tf="PublicLabel">' + opts(['Private', 'Confidential HR', 'Personal appt', 'Busy'], f.PublicLabel) + '</select></div>' : '') + '</div>' +
    '</div>' + (m.err ? '<div class="err" style="margin-top:8px">' + esc(m.err) + '</div>' : '') + '<div class="meta" style="margin-top:8px">Changes apply from today forward. Items already on past days keep what they were.</div></div>' +
    '<div class="dft" style="justify-content:flex-end"><button class="btn sm" data-act="closemodal">Cancel</button><button class="btn sm p" data-act="saveroutine">Save routine</button></div></div>';
}
function personModal(m) {
  var f = m.f;
  return '<div class="modal sm" role="dialog" aria-label="Team member"><div class="mhd"><h2>' + (m.editId ? 'Edit Team Member' : 'Add Team Member') + '</h2></div><div class="mbody" id="mbody"><div class="fgrid">' +
    '<div class="fld spanall"><label for="pp-n">Name *</label><input id="pp-n" class="in" data-pmf="Title" value="' + esc(f.Title) + '"></div>' +
    '<div class="fld spanall"><label for="pp-e">Microsoft email *</label><input id="pp-e" class="in" type="email" data-pmf="Email" value="' + esc(f.Email) + '"' + (m.editId ? ' readonly' : '') + '></div>' +
    '<div class="fld"><label for="pp-j">Job title</label><input id="pp-j" class="in" data-pmf="JobTitle" value="' + esc(f.JobTitle) + '"></div>' +
    '<div class="fld"><label for="pp-r">Reports to</label><select id="pp-r" class="in" data-pmf="ReportsTo">' + opt('', f.ReportsTo, '— nobody —') + activePeople().filter(function (p) { return p.Email !== f.Email; }).map(function (p) { return opt(p.Email, f.ReportsTo, p.Title); }).join('') + '</select></div>' +
    '<div class="fld"><label for="pp-a">Access</label><select id="pp-a" class="in" data-pmf="Access">' + opts(['Member', 'Manager', 'Executive'], f.Access || 'Member') + '</select></div>' +
    '<div class="fld"><label for="pp-x">Raise requests</label><select id="pp-x" class="in" data-pmf="Raises">' + opt('', f.Raises, 'None') + opt('Submit', f.Raises) + opt('Approve', f.Raises) + '</select></div>' +
    '<div class="fld"><label for="pp-o">Order</label><input id="pp-o" class="in" type="number" data-pmf="SortOrder" value="' + esc(f.SortOrder) + '"></div>' +
    '<div class="fld"><span class="lbl">Active</span><label style="display:flex;gap:6px;align-items:center;height:34px"><input type="checkbox" data-pmf="Active"' + (f.Active !== false ? ' checked' : '') + '> Can sign in</label></div>' +
    '</div>' + (m.err ? '<div class="err" style="margin-top:8px">' + esc(m.err) + '</div>' : '') + '</div><div class="dft" style="justify-content:flex-end"><button class="btn sm" data-act="closemodal">Cancel</button><button class="btn sm p" data-act="saveperson">Save</button></div></div>';
}
function contactModal(m) {
  var f = m.f;
  function fl(id, l, k) { return '<div class="fld"><label for="' + id + '">' + l + '</label><input id="' + id + '" class="in" data-cmf="' + k + '" value="' + esc(f[k]) + '"></div>'; }
  return '<div class="modal sm" role="dialog" aria-label="Contact"><div class="mhd"><h2>' + (m.editId ? 'Edit Contact' : 'Add Contact') + '</h2></div><div class="mbody" id="mbody"><div class="fgrid">' +
    fl('cm-n', 'Name *', 'Title') + '<div class="fld"><label for="cm-r">Role</label><select id="cm-r" class="in" data-cmf="Role">' + opts(ROLES, f.Role) + '</select></div>' + fl('cm-t', 'NTID', 'NTID') + fl('cm-s', 'Stores / book', 'Stores') + fl('cm-c', 'Coach', 'Coach') + fl('cm-e', 'Email', 'Email') + fl('cm-p', 'Phone', 'Phone') +
    '<div class="fld"><span class="lbl">Active</span><label style="display:flex;gap:6px;align-items:center;height:34px"><input type="checkbox" data-cmf="Active"' + (f.Active !== false ? ' checked' : '') + '> Active</label></div>' +
    '</div>' + (m.err ? '<div class="err" style="margin-top:8px">' + esc(m.err) + '</div>' : '') + '</div><div class="dft" style="justify-content:flex-end"><button class="btn sm" data-act="closemodal">Cancel</button><button class="btn sm p" data-act="savecontact">Save</button></div></div>';
}

/* ================= access log (admin) ================= */
function accessView() {
  var rows = S.access.slice().sort(function (a, b) { return (b.SignedInAt || '') > (a.SignedInAt || '') ? 1 : -1; });
  var wk0 = R.sundayOf(S.today), last = {};
  rows.forEach(function (r) { var k = r.UserEmail; if (!last[k] || (r.LastActive || r.SignedInAt) > (last[k].LastActive || last[k].SignedInAt)) { last[k] = r; } });
  var people = activePeople().map(function (p) {
    var l = last[p.Email], when = l ? (l.LastActive || l.SignedInAt) : '', d = when ? R.nyNow(new Date(when)).date : '';
    var active = when && (Date.now() - new Date(when).getTime()) < 5 * 60000;
    var color = !when || d < wk0 ? '#C0362C' : d === S.today ? '#1E9E57' : '#D9A21B';
    return '<div class="r ro"><span style="width:9px;height:9px;border-radius:50%;background:' + color + ';flex:0 0 9px"></span><span class="ti"><b>' + esc(p.Title) + '</b></span>' + (active ? chip('Active now', 'grn') : when ? (d < wk0 ? chip('Not this week · ' + fmtStamp(when), 'red') : '<span class="meta">' + esc(fmtStamp(when)) + '</span>') : chip('Never signed in', 'red')) + '</div>';
  }).join('');
  function dur(r) { if (!r.LastActive || !r.SignedInAt) { return '—'; } var m = Math.round((new Date(r.LastActive) - new Date(r.SignedInAt)) / 60000); return m < 60 ? m + 'm' : Math.floor(m / 60) + 'h ' + (m % 60) + 'm'; }
  return '<div style="display:flex;flex-direction:column;gap:10px"><div style="display:flex;flex-wrap:wrap;gap:8px;justify-content:space-between;align-items:center"><div style="display:flex;gap:10px;align-items:baseline;flex-wrap:wrap"><h1 class="pg">Access Log</h1>' + chip('Only you can see this', 'plum') + '</div>' +
    '<div style="display:flex;gap:6px"><button class="btn sm" data-act="reloadaccess">Refresh</button><button class="btn sm" data-act="exportaccess">Export CSV</button></div></div><div class="cols">' +
    '<section class="card" style="flex:1 1 280px;max-width:360px"><div class="gh">This week <span>' + esc(R.fmtShort(wk0)) + ' – ' + esc(R.fmtShort(R.addDays(wk0, 6))) + '</span></div>' + people + '</section>' +
    '<section class="card" style="flex:999 1 520px;min-width:0"><div class="gh">Sign-in history <span>Newest first</span></div><div class="scrollx"><table class="tbl"><thead><tr><th>Person</th><th>Signed in</th><th>Last active</th><th>Time in app</th><th>Device</th><th>Browser</th></tr></thead><tbody>' +
    (rows.length ? rows.slice(0, 400).map(function (r) { return '<tr><td><b>' + esc(nameOf(r.UserEmail)) + '</b></td><td>' + esc(fmtStamp(r.SignedInAt)) + '</td><td>' + esc(fmtStamp(r.LastActive)) + '</td><td>' + esc(dur(r)) + '</td><td>' + esc(r.Device) + '</td><td>' + esc(r.Browser) + '</td></tr>'; }).join('') : '<tr><td colspan="6" class="meta">No sign-ins recorded yet.</td></tr>') +
    '</tbody></table></div><div class="meta" style="padding:8px 12px">Successful sign-ins to this app. Failed or blocked Microsoft sign-ins live in Entra sign-in logs.</div></section></div></div>';
}

/* ================= setup (admin) ================= */
function setupView() {
  return '<div style="display:flex;flex-direction:column;gap:10px;max-width:980px"><h1 class="pg">Setup</h1><div class="card" style="padding:14px 16px;display:flex;flex-direction:column;gap:10px">' +
    '<div><b>1. Lists & columns.</b> Creates or repairs every SharePoint list, column, unique index and privacy setting. Safe to run again.</div><div><button class="btn sm p" data-act="provision">Create / repair lists</button></div>' +
    '<div><b>2. Lock down Raise Requests.</b> Only you and people marked “Approve” or “Submit” for raises can open that list.</div><div><button class="btn sm p" data-act="restrictraises">Apply raise access</button></div>' +
    '<div><b>3. Grant site access.</b> Adds every active team member to the site’s Members group so they can sign in and save.</div><div><button class="btn sm p" data-act="grantaccess">Grant site access</button></div>' +
    '<div><b>4. Routines and contacts.</b> Import from Settings → My routines (JSON) and Settings → Contacts (CSV).</div>' +
    '</div><div class="card"><div class="gh">Setup log</div><pre id="setuplog" style="margin:0;padding:10px 12px;font:12px/1.5 ui-monospace,Consolas,monospace;white-space:pre-wrap;max-height:360px;overflow:auto">' + esc((S.setupLog || []).join('\n')) + '</pre></div></div>';
}
