/* Actions, boot. ES5. */
function rec(list, id) {
  if (list === 'BOCC_Tasks') { return S.tasks[id]; }
  var arr = { BOCC_Templates: S.templates, BOCC_People: S.people, BOCC_Contacts: S.contacts, BOCC_Notes: S.notes, BOCC_SharedNotes: S.shared, BOCC_Raises: S.raises }[list] || [];
  for (var i = 0; i < arr.length; i++) { if (String(arr[i]._id) === String(id)) { return arr[i]; } }
  return null;
}
function nyToIso(date, time) {
  var a = date.split('-'), t = (time || '12:00').split(':');
  var guess = Date.UTC(+a[0], +a[1] - 1, +a[2], +t[0], +t[1]) + 4 * 3600000, i;
  for (i = 0; i < 3; i++) {
    var n = R.nyNow(new Date(guess));
    var diff = (R.daysBetween(n.date, date) * 1440) + ((+t[0]) * 60 + (+t[1]) - n.minutes);
    if (!diff) { break; }
    guess += diff * 60000;
  }
  return new Date(guess).toISOString();
}

/* ---------- tasks ---------- */
function withTask(id, fn) {
  var t = findTask(id); if (!t) { return; }
  if (t.Virtual) {
    materializeVirtual(t).then(function (saved) {
      if (S.drawer && S.drawer.id === id) { S.drawer.id = saved._id; }
      fn(saved); render();
    }, function (e) { toast('Could not save: ' + e.message); });
    return;
  }
  fn(t);
}
function changeTask(t, fields, delay) { Q.change('BOCC_Tasks', t, fields, delay); }
function savePrivate(key, fields) {
  var p = S.privateMap[key];
  if (p) { Q.change('BOCC_Private', p, fields); return Promise.resolve(p); }
  var f = { Title: 'private', Key: key, OwnerEmail: S.myEmail }, k; for (k in fields) { if (fields.hasOwnProperty(k)) { f[k] = fields[k]; } }
  return createRec('BOCC_Private', f, 'Key').then(function (r) { S.privateMap[key] = r; return r; });
}
var TEMPLATE_FIELDS = { Title: 1, StartTime: 1, DurationMin: 1 };
function setTaskField(id, field, value) {
  withTask(id, function (t) {
    if (field === 'DurationMin') { value = value === '' ? null : +value; }
    if (t.TemplateId && TEMPLATE_FIELDS[field] && !(S.modal && S.modal.type === 'scope')) {
      S.modal = { type: 'scope', id: t._id, field: field, value: value }; render(); return;
    }
    applyTaskField(t, field, value);
  });
}
function applyTaskField(t, field, value) {
  var f = {};
  if (field === 'Title' && t.Visibility === 'Private' && t.OwnerEmail === S.myEmail) { savePrivate('task|' + t.TaskKey, { RealTitle: value }); return; }
  if (field === 'Description' && t.Visibility === 'Private' && t.OwnerEmail === S.myEmail) { savePrivate('task|' + t.TaskKey, { Details: value }); return; }
  if (field === 'Status' && value === 'Completed') { tryComplete(t, false); return; }
  f[field] = value;
  if (field === 'Status') {
    if (value !== 'Completed') { f.CompletedAt = ''; f.CompletedBy = ''; }
    logActivity(t, 'Status → ' + value);
  }
  if (field === 'PlannedDate') {
    if (!R.isDate(value)) { return; }
    if (!t.OriginalPlannedDate) { f.OriginalPlannedDate = t.PlannedDate; }
    logActivity(t, 'Rescheduled', R.fmtShort(t.PlannedDate) + ' → ' + R.fmtShort(value));
  }
  if (field === 'DueDate') { logActivity(t, 'Due date', value ? R.fmtShort(value) : 'cleared'); }
  if (field === 'OwnerEmail') {
    if (value !== S.myEmail) { f.AssignedByEmail = S.myEmail; f.SeenByOwner = false; }
    if (t.Visibility === 'Private') { toast('Private items can’t be reassigned — make it Team first.'); render(); return; }
    logActivity(t, 'Assigned', nameOf(value));
  }
  if (field === 'Visibility') {
    if (value === 'Private') {
      savePrivate('task|' + t.TaskKey, { RealTitle: t.Title, Details: t.Description || '' });
      f.Title = t.PublicLabel || 'Private'; f.PublicLabel = t.PublicLabel || 'Private'; f.Description = '';
    } else {
      var pv = S.privateMap['task|' + t.TaskKey];
      f.Title = (pv && pv.RealTitle) || t.Title; f.Description = (pv && pv.Details) || '';
    }
  }
  if (field === 'PublicLabel' && t.Visibility === 'Private') { f.Title = value || 'Private'; }
  changeTask(t, f, field === 'Description' || field === 'Title' || field === 'WaitingOn' ? 900 : 200);
  if (field !== 'Description' && field !== 'Title') { render(); }
}
function tryComplete(t, force) {
  var c = R.canComplete(t);
  if (!c.ok && !force) { S.drawer = { id: t._id, warn: true }; render(); return; }
  changeTask(t, { Status: 'Completed', CompletedAt: nowIso(), CompletedBy: S.myEmail }, 100);
  logActivity(t, 'Completed', force && !c.ok ? 'override — open required: ' + c.openRequired.join(', ') : '');
  if (S.drawer) { S.drawer.warn = false; }
  render();
}
function mutateTree(t, fn, label) {
  var tree = copy(t.Subtasks || []);
  fn(tree);
  changeTask(t, { Subtasks: tree }, 300);
  if (label) { logActivity(t, label); }
  render();
}

/* ---------- picker ---------- */
function addPerson(p) {
  var P = S.picker; if (!P) { return; }
  var person = { name: p.name, role: p.role || '', ntid: p.ntid || '', email: p.email || '', stores: p.stores || '' };
  if (P.target === 'log') {
    var f = S.modal.f;
    if (!f.People.some(function (x) { return x.name === person.name && x.ntid === person.ntid; })) { f.People.push(person); }
    var st = f.Stores ? f.Stores.split(/\s*,\s*/) : [];
    (person.stores || '').split(/\s*,\s*/).forEach(function (s) { if (s && st.indexOf(s) < 0) { st.push(s); } });
    f.Stores = st.join(', ');
    saveLogDraft();
  } else {
    withTask(P.id, function (t) {
      if (P.target === 'task') {
        var list = copy(t.WithPeople || []); list.push(person); changeTask(t, { WithPeople: list }, 200);
      } else {
        mutateTree(t, function (tree) { var n = R.findNode(tree, P.node); if (n) { n.with = (n.with || []).concat([person]); } });
      }
    });
  }
  P.q = ''; render();
}

/* ---------- conversation log ---------- */
function newLog(ctx) {
  ctx = ctx || {};
  var now = R.nyNow(), draftId = R.uid('d');
  var f = { People: [], date: now.date, time: now.time, Method: 'Call', Stores: '', Title: '', Discussion: '', Outcome: '', Visibility: 'Private',
    LinkedTaskKey: '', LinkedNodeId: '', WantsFollowUp: false, NextAction: '', FollowUpDate: '' };
  if (!ctx.taskId) {
    var d = latestDraft();
    if (d) { S.modal = { type: 'log', f: d.f, draftId: d.draftId, state: 'Draft', draftAt: fmtStamp(d.at) }; render(); toast('Continuing your unsaved conversation draft.'); return; }
  }
  if (ctx.taskId) {
    var t = findTask(ctx.taskId);
    if (t) {
      var go = function (tt) {
        f.LinkedTaskKey = tt.TaskKey; f.Title = titleOf(tt);
        f.People = copy(tt.WithPeople || []);
        if (ctx.node) { var n = R.findNode(tt.Subtasks || [], ctx.node); if (n) { f.LinkedNodeId = n.id; f.Title = n.title; f.People = copy(n.with || []); } }
        f.Stores = f.People.map(function (p) { return p.stores; }).filter(Boolean).join(', ');
        if (tt.Kind === 'Call' && tt.PlannedDate !== now.date) { f.date = tt.PlannedDate; f.time = tt.StartTime || '12:00'; }
        S.modal = { type: 'log', f: f, draftId: draftId, state: 'Unsaved' }; render();
      };
      if (t.Virtual) { withTask(ctx.taskId, go); return; }
      go(t); return;
    }
  }
  S.modal = { type: 'log', f: f, draftId: draftId, state: 'Unsaved' }; render();
}
function latestDraft() {
  var best = null, k, i;
  for (i = 0; i < localStorage.length; i++) {
    k = localStorage.key(i);
    if (k && k.indexOf('bocc-draft-' + S.myEmail + '-') === 0) { var d = jparse(localStorage.getItem(k), null); if (d && (!best || d.at > best.at)) { best = d; } }
  }
  (S.drafts || []).forEach(function (r) { var d = jparse(r.Json, null); if (d && d.f && (!best || d.at > best.at)) { best = d; } });
  return best;
}
var pushDraft = debounce(function () {
  var m = S.modal; if (!m || m.type !== 'log' || m.editId) { return; }
  var d = { draftId: m.draftId, f: m.f, at: nowIso() }, key = S.myEmail + '|' + m.draftId;
  var existing = null; (S.drafts || []).forEach(function (r) { if (r.Key === key) { existing = r; } });
  var p = existing ? (Q.change('BOCC_Drafts', existing, { Json: JSON.stringify(d) }, 0), Promise.resolve(existing)) :
    createRec('BOCC_Drafts', { Title: 'draft', Key: key, OwnerEmail: S.myEmail, Kind: 'log', Json: JSON.stringify(d) }, 'Key').then(function (r) { (S.drafts = S.drafts || []).push(r); return r; });
  p.then(function () { if (S.modal && S.modal.draftId === d.draftId && S.modal.state !== 'Saving…') { S.modal.state = 'Draft'; S.modal.draftAt = R.fmtTime(R.nyNow().time); var pill = document.querySelector('.modal .pill'); if (pill) { pill.textContent = 'Draft · autosaved ' + S.modal.draftAt; pill.className = 'pill'; } } }, function () {});
}, 1500);
function saveLogDraft() {
  var m = S.modal; if (!m || m.type !== 'log' || m.editId) { return; }
  try { localStorage.setItem('bocc-draft-' + S.myEmail + '-' + m.draftId, JSON.stringify({ draftId: m.draftId, f: m.f, at: nowIso() })); } catch (e) {}
  pushDraft();
}
function clearDraft(draftId) {
  try { localStorage.removeItem('bocc-draft-' + S.myEmail + '-' + draftId); } catch (e) {}
  var key = S.myEmail + '|' + draftId;
  (S.drafts || []).forEach(function (r) { if (r.Key === key) { Q.change('BOCC_Drafts', r, { Json: '' }, 0); } });
  S.drafts = (S.drafts || []).filter(function (r) { return r.Key !== key; });
}
function createFollowUp(note) {
  var key = 'fu|' + note.RequestKey;
  var existing = taskByKey(key);
  var p = existing ? Promise.resolve(existing) : createRec('BOCC_Tasks', {
    Title: note.NextAction, TaskKey: key, OwnerEmail: note.OwnerEmail, Kind: 'Task', Status: 'Not Started', Priority: 'Normal', Category: 'Follow-Up',
    PlannedDate: note.FollowUpDate, OriginalPlannedDate: note.FollowUpDate, Rollover: 'Roll', Visibility: 'Team', WithPeople: note.People || [],
    Stores: note.Stores || '', SourceNoteKey: note.RequestKey, SeenByOwner: true, Subtasks: []
  }, 'TaskKey');
  return p.then(function (t) {
    S.tasks[t._id] = t;
    var list = note.Visibility === 'Shared' ? 'BOCC_SharedNotes' : 'BOCC_Notes';
    var n = rec(list, note._id) || note;
    if (n._id) { Q.change(list, n, { FollowUpTaskKey: key }, 0); }
    return t;
  });
}
function saveLog() {
  var m = S.modal, f = m.f;
  m.err = '';
  if (!f.People.length) { m.err = 'Add at least one person.'; }
  else if (!R.isDate(f.date)) { m.err = 'Pick the date of the conversation.'; }
  else if (!f.Discussion.trim()) { m.err = 'Discussion notes can’t be empty.'; }
  else if (f.WantsFollowUp && (!f.NextAction.trim() || !R.isDate(f.FollowUpDate))) { m.err = 'A follow-up needs a next action and a planned date.'; }
  if (m.err) { render(); return; }
  var list = f.Visibility === 'Shared' ? 'BOCC_SharedNotes' : 'BOCC_Notes';
  var roles = []; f.People.forEach(function (p) { if (p.role && roles.indexOf(p.role) < 0) { roles.push(p.role); } });
  var fields = { Title: f.Title || '(no topic)', OwnerEmail: S.myEmail, People: f.People, Roles: roles.join(', '), Stores: f.Stores, BookAtTime: f.Stores,
    ConvAt: nyToIso(f.date, f.time), ConvDate: f.date, Method: f.Method, Discussion: f.Discussion, Outcome: f.Outcome, NextAction: f.WantsFollowUp ? f.NextAction : '',
    FollowUpDate: f.WantsFollowUp ? f.FollowUpDate : '', WantsFollowUp: !!f.WantsFollowUp, LinkedTaskKey: f.LinkedTaskKey, LinkedNodeId: f.LinkedNodeId, Visibility: f.Visibility === 'Shared' ? 'Shared' : 'Private' };
  m.state = 'Saving…'; render();
  var done;
  if (m.editId) {
    var old = rec(m.editList, m.editId);
    fields.EditedAt = nowIso(); delete fields.WantsFollowUp;
    if (m.editList === list) { Q.change(list, old, fields, 0); done = Promise.resolve(old); }
    else {
      fields.RequestKey = old.RequestKey; fields.FollowUpTaskKey = old.FollowUpTaskKey; fields.WantsFollowUp = old.WantsFollowUp;
      done = createRec(list, fields, 'RequestKey').then(function (n) {
        (list === 'BOCC_Notes' ? S.notes : S.shared).push(n);
        return SP.remove(m.editList, old._id).then(function () {
          if (m.editList === 'BOCC_Notes') { S.notes = S.notes.filter(function (x) { return x._id !== old._id; }); } else { S.shared = S.shared.filter(function (x) { return x._id !== old._id; }); }
          return n;
        });
      });
    }
  } else {
    fields.RequestKey = 'n|' + m.draftId;
    done = createRec(list, fields, 'RequestKey').then(function (n) {
      var arr = list === 'BOCC_Notes' ? S.notes : S.shared;
      if (!arr.some(function (x) { return x._id === n._id; })) { arr.push(n); }
      var chain = Promise.resolve(n);
      if (n.WantsFollowUp) { chain = createFollowUp(n).then(function () { return n; }); }
      return chain.then(function () {
        var t = f.LinkedTaskKey ? taskByKey(f.LinkedTaskKey) : null;
        if (t) {
          if (f.LinkedNodeId) {
            var tree = copy(t.Subtasks || []), node = R.findNode(tree, f.LinkedNodeId);
            if (node) { node.loggedAt = nowIso(); node.loggedNoteKey = n.RequestKey; changeTask(t, { Subtasks: tree }, 0); }
          } else if (t.Kind === 'Call' && t.CallState !== 'Held') { changeTask(t, { CallState: 'Held' }, 0); }
          logActivity(t, 'Conversation logged', f.People.map(function (p) { return p.name; }).join(', '));
        }
        clearDraft(m.draftId);
        return n;
      });
    });
  }
  done.then(function () {
    m.state = 'Saved'; render();
    setTimeout(function () { if (S.modal === m) { S.modal = null; S.picker = null; render(); } }, 500);
    toast(f.WantsFollowUp && !m.editId ? 'Conversation saved · follow-up task added for ' + R.fmtShort(f.FollowUpDate) : 'Conversation saved');
  }, function (e) { m.state = 'Save failed'; m.err = 'Not saved: ' + e.message + '. Your notes are kept — try again.'; render(); });
}

/* ---------- new task ---------- */
function newTaskModal(owner) {
  var me = S.myEmail, defPriv = prefsOf(me).DefaultVisibility === 'Private';
  owner = owner || me;
  S.modal = { type: 'task', key: R.uid('t'), f: { Title: '', OwnerEmail: owner, Kind: 'Task', Category: '', PlannedDate: S.day < S.today ? S.today : S.day, DueDate: '', Priority: 'Normal', StartTime: '', DurationMin: '',
    Rollover: 'Roll', repeat: 'once', days: R.DEFAULT_WORKDAYS, independent: false, Description: '', Private: defPriv && owner === me, PublicLabel: 'Private' } };
  render(); setTimeout(function () { var el = byId('t-title'); if (el) { el.focus(); } }, 30);
}
function saveTask() {
  var m = S.modal, f = m.f, me = S.myEmail;
  if (!f.Title.trim()) { m.err = 'Give the task a title.'; render(); return; }
  if (!R.isDate(f.PlannedDate)) { m.err = 'Pick a planned date.'; render(); return; }
  var priv = f.Private && f.OwnerEmail === me;
  m.saving = true; m.err = ''; render();
  var p;
  if (f.repeat !== 'once') {
    var tid = 'tpl-' + m.key.slice(2);
    var tpl = { Title: priv ? f.PublicLabel : f.Title, TemplateId: tid, OwnerEmail: f.OwnerEmail, Kind: f.Kind, Category: f.Category, Days: f.repeat === 'workdays' ? (prefsOf(f.OwnerEmail).WorkDays || R.DEFAULT_WORKDAYS) : f.days,
      StartTime: f.StartTime, DurationMin: f.DurationMin === '' ? null : +f.DurationMin, Rollover: f.Kind === 'Task' ? (f.independent ? 'Independent' : (f.Rollover === 'Stay' ? 'Stay' : 'Carry')) : (f.Kind === 'Block' && f.Rollover === 'Roll' ? 'Roll' : 'Stay'),
      Items: [], StartDate: f.PlannedDate, EndDate: '', Skips: [], Active: true, Private: priv, PublicLabel: priv ? f.PublicLabel : '', Priority: f.Priority, SortOrder: 50, Description: f.Description };
    p = (priv ? savePrivate('tpl|' + tid, { RealTitle: f.Title, Details: f.Description }) : Promise.resolve()).then(function () {
      return createRec('BOCC_Templates', tpl, 'TemplateId');
    }).then(function (r) { S.templates.push(r); return materialize(); });
  } else {
    var key = 'id|' + m.key;
    var t = { Title: priv ? f.PublicLabel : f.Title, TaskKey: key, OwnerEmail: f.OwnerEmail, AssignedByEmail: f.OwnerEmail !== me ? me : '', Kind: f.Kind, Category: f.Category,
      Priority: f.Priority, Status: 'Not Started', PlannedDate: f.PlannedDate, OriginalPlannedDate: f.PlannedDate, DueDate: f.DueDate, StartTime: f.StartTime,
      DurationMin: f.DurationMin === '' ? null : +f.DurationMin, Rollover: f.Kind === 'Call' ? 'Stay' : f.Rollover, Description: priv ? '' : f.Description, Subtasks: [], WithPeople: [],
      Visibility: priv ? 'Private' : 'Team', PublicLabel: priv ? f.PublicLabel : '', SeenByOwner: f.OwnerEmail === me };
    p = (priv ? savePrivate('task|' + key, { RealTitle: f.Title, Details: f.Description }) : Promise.resolve()).then(function () {
      return createRec('BOCC_Tasks', t, 'TaskKey');
    }).then(function (r) { S.tasks[r._id] = r; logActivity(r, f.OwnerEmail !== me ? 'Assigned to ' + nameOf(f.OwnerEmail) : 'Created'); });
  }
  p.then(function () { S.modal = null; render(); toast(f.OwnerEmail !== me ? 'Assigned to ' + nameOf(f.OwnerEmail) : 'Task added'); },
    function (e) { m.saving = false; m.err = 'Not saved: ' + e.message + '. Nothing was lost — try again.'; render(); });
}
function quickAdd(text) {
  text = text.trim(); if (!text) { return; }
  var key = 'id|' + R.uid('t').slice(2), vis = prefsOf(S.myEmail).DefaultVisibility === 'Private';
  var t = { Title: vis ? 'Private' : text, TaskKey: key, OwnerEmail: S.myEmail, Kind: 'Task', Category: '', Priority: 'Normal', Status: 'Not Started',
    PlannedDate: S.day < S.today ? S.today : S.day, OriginalPlannedDate: S.day < S.today ? S.today : S.day, Rollover: 'Roll', Subtasks: [], WithPeople: [], Visibility: vis ? 'Private' : 'Team', PublicLabel: vis ? 'Private' : '', SeenByOwner: true };
  (vis ? savePrivate('task|' + key, { RealTitle: text }) : Promise.resolve()).then(function () { return createRec('BOCC_Tasks', t, 'TaskKey'); })
    .then(function (r) { S.tasks[r._id] = r; render(); var q = byId('quick'); if (q) { q.focus(); } }, function (e) { toast('Not saved: ' + e.message); var q = byId('quick'); if (q) { q.value = text; } });
}

/* ---------- prefs ---------- */
function myPrefs() {
  var p = S.prefs[S.myEmail];
  if (p) { return Promise.resolve(p); }
  return createRec('BOCC_Prefs', { Title: S.myEmail, Email: S.myEmail, WorkDays: R.DEFAULT_WORKDAYS, TimeOff: [], DayThemes: {}, Categories: [], DefaultVisibility: 'Team' }, 'Email')
    .then(function (r) { S.prefs[S.myEmail] = r; return r; });
}
function setPref(fields, rerender) { myPrefs().then(function (p) { Q.change('BOCC_Prefs', p, fields, 500); if (rerender !== false) { render(); } }); }

/* ---------- routines ---------- */
function treeToText(nodes, depth) {
  depth = depth || 0;
  return (nodes || []).map(function (n) { return new Array(depth + 1).join('-') + (depth ? ' ' : '') + n.title + (n.required ? ' *' : '') + (n.children && n.children.length ? '\n' + treeToText(n.children, depth + 1) : ''); }).join('\n');
}
function textToTree(text) {
  var root = [], stack = [{ children: root }];
  String(text || '').split(/\r?\n/).forEach(function (line) {
    if (!line.trim()) { return; }
    var m = /^(-*)\s*(.*?)(\s\*)?$/.exec(line.trim()), depth = Math.min((m[1] || '').length, 2);
    var node = { title: m[2], required: !!m[3], children: [] };
    while (stack.length > depth + 1) { stack.pop(); }
    var parent = stack[Math.min(depth, stack.length - 1)];
    parent.children.push(node); stack.length = Math.min(depth, stack.length - 1) + 1; stack.push(node);
  });
  return root;
}
function routineModal0(t) {
  var f = t ? { Title: asRuleTpl(t).Title, Kind: t.Kind || 'Task', Category: t.Category, Days: t.Days || R.DEFAULT_WORKDAYS, StartTime: t.StartTime, DurationMin: t.DurationMin === null ? '' : t.DurationMin,
    AfterLabel: t.AfterLabel, Rollover: t.Rollover || (t.Kind === 'Task' ? 'Carry' : 'Stay'), Cycle: t.Cycle, StartDate: t.StartDate || S.today, EndDate: t.EndDate, itemsText: treeToText(t.Items), Private: t.Private, PublicLabel: t.PublicLabel || 'Private' } :
    { Title: '', Kind: 'Task', Category: '', Days: R.DEFAULT_WORKDAYS, StartTime: '', DurationMin: '', AfterLabel: '', Rollover: 'Carry', Cycle: '', StartDate: S.today, EndDate: '', itemsText: '', Private: false, PublicLabel: 'Private' };
  S.modal = { type: 'routine', editId: t ? t._id : null, f: f }; render();
}
function saveRoutine() {
  var m = S.modal, f = m.f;
  if (!f.Title.trim()) { m.err = 'Give the routine a title.'; render(); return; }
  if (f.Days.indexOf('1') < 0) { m.err = 'Pick at least one day.'; render(); return; }
  var fields = { Kind: f.Kind, Category: f.Category, Days: f.Days, StartTime: f.StartTime, DurationMin: f.DurationMin === '' ? null : +f.DurationMin, AfterLabel: f.AfterLabel,
    Rollover: f.Kind === 'Call' ? 'Stay' : f.Rollover, Cycle: f.Kind === 'Task' ? f.Cycle : '', StartDate: f.StartDate || S.today, EndDate: f.EndDate, Items: f.Kind === 'Task' ? textToTree(f.itemsText) : [],
    Private: !!f.Private, PublicLabel: f.Private ? f.PublicLabel : '', Title: f.Private ? f.PublicLabel : f.Title };
  var p;
  if (m.editId) {
    var t = rec('BOCC_Templates', m.editId);
    if (f.Private) { savePrivate('tpl|' + t.TemplateId, { RealTitle: f.Title }); }
    Q.change('BOCC_Templates', t, fields, 0); p = Promise.resolve();
  } else {
    fields.TemplateId = 'tpl-' + R.uid('x').slice(2); fields.OwnerEmail = S.myEmail; fields.Active = true; fields.Skips = []; fields.SortOrder = 50;
    p = (f.Private ? savePrivate('tpl|' + fields.TemplateId, { RealTitle: f.Title }) : Promise.resolve()).then(function () { return createRec('BOCC_Templates', fields, 'TemplateId'); }).then(function (r) { S.templates.push(r); });
  }
  p.then(function () { S.modal = null; render(); materialize(); toast('Routine saved'); }, function (e) { m.err = 'Not saved: ' + e.message; render(); });
}
function importRoutines(file) {
  var fr = new FileReader();
  fr.onload = function () {
    var data = jparse(fr.result, null);
    if (!data) { toast('That file isn’t valid JSON.'); return; }
    var list = data.templates || data, chain = Promise.resolve(), n = 0;
    if (data.categories || data.dayThemes || data.workDays) {
      chain = myPrefs().then(function (p) {
        var f = {}; if (data.categories) { f.Categories = data.categories; } if (data.dayThemes) { f.DayThemes = data.dayThemes; } if (data.workDays) { f.WorkDays = data.workDays; }
        Q.change('BOCC_Prefs', p, f, 0);
      });
    }
    list.forEach(function (t, i) {
      chain = chain.then(function () {
        var tid = t.TemplateId || ('tpl-' + lc(S.myEmail).split('@')[0] + '-' + (t.Key || i));
        var exists = S.templates.some(function (x) { return x.TemplateId === tid; });
        if (exists) { return; }
        var f = { Title: t.Title, TemplateId: tid, OwnerEmail: S.myEmail, Kind: t.Kind || 'Task', Category: t.Category || '', Days: t.Days || R.DEFAULT_WORKDAYS, StartTime: t.StartTime || '',
          DurationMin: t.DurationMin || null, AfterLabel: t.AfterLabel || '', Rollover: t.Rollover || (t.Kind === 'Task' || !t.Kind ? 'Carry' : 'Stay'), Cycle: t.Cycle || '',
          Items: t.Items || (t.itemsText ? textToTree(t.itemsText) : []), StartDate: t.StartDate || S.today, EndDate: '', Skips: [], Active: true, Private: false, PublicLabel: '', Priority: t.Priority || 'Normal', SortOrder: t.SortOrder || i + 1 };
        return createRec('BOCC_Templates', f, 'TemplateId').then(function (r) { S.templates.push(r); n++; });
      });
    });
    chain.then(function () { toast(n + ' routines imported'); materialize(); render(); }, function (e) { toast('Import stopped: ' + e.message); render(); });
  };
  fr.readAsText(file);
}

/* ---------- contacts & people ---------- */
function importContacts(file) {
  var fr = new FileReader();
  fr.onload = function () {
    var rows = parseCsv(fr.result); if (rows.length < 2) { toast('No rows found.'); return; }
    var head = rows[0].map(function (h) { return lc(h).trim(); });
    function col(r, n) { var i = head.indexOf(n); return i < 0 ? '' : (r[i] || '').trim(); }
    var chain = Promise.resolve(), made = 0, upd = 0;
    rows.slice(1).forEach(function (r) {
      var c = { Title: col(r, 'name'), Role: col(r, 'role') || 'Other', NTID: lc(col(r, 'ntid')), Stores: col(r, 'stores'), Email: col(r, 'email'), Phone: col(r, 'phone'), Coach: col(r, 'coach'), Active: true };
      if (!c.Title) { return; }
      chain = chain.then(function () {
        var ex = null; S.contacts.forEach(function (x) { if ((c.NTID && x.NTID === c.NTID) || (!c.NTID && lc(x.Title) === lc(c.Title) && x.Role === c.Role)) { ex = x; } });
        if (ex) { Q.change('BOCC_Contacts', ex, c, 0); upd++; return; }
        return createRec('BOCC_Contacts', c).then(function (x) { S.contacts.push(x); made++; if (made % 20 === 0) { toast('Importing… ' + made); } });
      });
    });
    chain.then(function () { toast(made + ' added, ' + upd + ' updated'); render(); }, function (e) { toast('Import stopped: ' + e.message); render(); });
  };
  fr.readAsText(file);
}

/* ---------- raises ---------- */
function raiseModal0(r) {
  S.modal = { type: 'raise', editId: r ? r._id : null, key: r ? r.RequestKey : 'RR-' + R.uid('x').slice(2, 10).toUpperCase(),
    f: r ? { Title: r.Title, NTID: r.NTID, Store: r.Store, Position: r.Position, CurrentRate: r.CurrentRate, ProposedRate: r.ProposedRate, EffectiveDate: r.EffectiveDate, Reason: r.Reason, LastRaise: r.LastRaise, Justification: r.Justification } :
      { Title: '', NTID: '', Store: '', Position: 'Rep', CurrentRate: '', ProposedRate: '', EffectiveDate: '', Reason: 'Promotion', LastRaise: '', Justification: '' } };
  render();
}
function saveRaise(status) {
  var m = S.modal, f = m.f;
  if (status === 'Submitted' && (!f.Title || !f.CurrentRate || !f.ProposedRate || !f.EffectiveDate || !f.Justification)) { m.err = 'Fill in the required fields before submitting.'; render(); return; }
  if (!f.Title) { m.err = 'Add the employee’s name.'; render(); return; }
  m.saving = true; render();
  var hist = { at: nowIso(), by: S.myEmail, what: status === 'Submitted' ? (m.editId ? 'Resubmitted' : 'Submitted') : 'Saved draft' };
  var fields = { Title: f.Title, NTID: f.NTID, Store: f.Store, Position: f.Position, CurrentRate: f.CurrentRate, ProposedRate: f.ProposedRate, EffectiveDate: f.EffectiveDate,
    Reason: f.Reason, LastRaise: f.LastRaise, Justification: f.Justification, Status: status, SubmittedBy: S.myEmail, SubmittedAt: status === 'Submitted' ? nowIso() : '' };
  var files = byId('r-file') ? byId('r-file').files : [];
  var p;
  if (m.editId) { var r = rec('BOCC_Raises', m.editId); fields.History = (r.History || []).concat([hist]); Q.change('BOCC_Raises', r, fields, 0); p = Promise.resolve(r); }
  else { fields.RequestKey = m.key; fields.History = [hist]; p = createRec('BOCC_Raises', fields, 'RequestKey').then(function (x) { S.raises.push(x); return x; }); }
  p.then(function (r) {
    var chain = Promise.resolve();
    Array.prototype.forEach.call(files || [], function (file) { chain = chain.then(function () { return SP.attach('BOCC_Raises', r._id, file); }); });
    return chain.then(function () { return r; });
  }).then(function (r) { S.modal = null; S.raiseSel = r._id; S.raiseTab = status; render(); toast(status === 'Submitted' ? 'Sent to the CEO for approval' : 'Draft saved'); },
    function (e) { m.saving = false; m.err = 'Not saved: ' + e.message; render(); });
}
function decideRaise(id, decision) {
  var r = rec('BOCC_Raises', id), c = byId('ceo-c') ? byId('ceo-c').value.trim() : '';
  if (decision !== 'Approved' && !c) { toast('Add a comment to deny or return.'); var el = byId('ceo-c'); if (el) { el.classList.add('bad'); el.focus(); } return; }
  Q.change('BOCC_Raises', r, { Status: decision, DecidedBy: S.myEmail, DecidedAt: nowIso(), CeoComment: c, History: (r.History || []).concat([{ at: nowIso(), by: S.myEmail, what: decision + (c ? ': ' + c : '') }]) }, 0);
  if (decision === 'Approved' && r.SubmittedBy) {
    var owner = r.SubmittedBy;
    createRec('BOCC_Tasks', { Title: 'Enter approved raise in payroll — ' + r.Title + (r.EffectiveDate ? ' · eff. ' + R.fmtShort(r.EffectiveDate) : ''), TaskKey: 'raise|' + r.RequestKey,
      OwnerEmail: owner, AssignedByEmail: S.myEmail, Kind: 'Task', Category: 'Payroll', Priority: 'High', Status: 'Not Started', PlannedDate: R.nextWorkDayOnOrAfter(workOf(owner), S.today),
      OriginalPlannedDate: R.nextWorkDayOnOrAfter(workOf(owner), S.today), Rollover: 'Roll', Visibility: 'Team', Subtasks: [], WithPeople: [], SeenByOwner: false }, 'TaskKey').then(function (t) { S.tasks[t._id] = t; }, function () {});
  }
  S.raiseTab = decision; render(); toast('Raise ' + decision.toLowerCase());
}

/* ---------- export ---------- */
function exportNotes(kind) {
  var list = filteredNotes();
  if (kind === 'json') { download('conversation-log-' + S.today + '.json', JSON.stringify(list.map(baseCopy), null, 2), 'application/json'); return; }
  download('conversation-log-' + S.today + '.csv', csv([['Date', 'Time', 'Method', 'People', 'Roles', 'Stores', 'Topic', 'Notes', 'Outcome', 'Next action', 'Follow-up date', 'Visibility', 'Linked task', 'Logged', 'Edited', 'Archived']].concat(list.map(function (n) {
    var t = n.LinkedTaskKey ? taskByKey(n.LinkedTaskKey) : null;
    return [n.ConvDate, n.ConvAt ? R.nyNow(new Date(n.ConvAt)).time : '', n.Method, (n.People || []).map(function (p) { return p.name + (p.ntid ? ' (' + p.ntid + ')' : ''); }).join('; '), n.Roles, n.Stores, n.Title, n.Discussion, n.Outcome, n.NextAction, n.FollowUpDate, n.Visibility, t ? titleOf(t) : '', n._created, n.EditedAt, n.Archived ? 'yes' : ''];
  }))), 'text/csv');
}
function backup(kind) {
  toast('Preparing export…');
  Promise.all([SP.getAll('BOCC_Tasks', "OwnerEmail eq '" + S.myEmail + "'"), SP.getAll('BOCC_Activity'), SP.getAll('BOCC_DayNotes')]).then(function (r) {
    var tasks = r[0].map(fromSP), keys = {};
    allTasks().forEach(function (t) { if (t.AssignedByEmail === S.myEmail && !tasks.some(function (x) { return x._id === t._id; })) { tasks.push(t); } });
    tasks.forEach(function (t) { keys[t.TaskKey] = 1; });
    var act = r[1].map(fromSP).filter(function (a) { return keys[a.TaskKey]; });
    tasks.forEach(function (t) { if (t.Visibility === 'Private' && t.OwnerEmail === S.myEmail) { var pv = S.privateMap['task|' + t.TaskKey]; if (pv) { t.Title = pv.RealTitle || t.Title; t.Description = pv.Details || ''; } } });
    if (kind === 'tasks') {
      download('tasks-' + S.today + '.csv', csv([['Title', 'Status', 'Owner', 'Assigned by', 'Category', 'Priority', 'Planned', 'Original planned', 'Due', 'Completed at', 'Kind', 'Template', 'Payroll cycle', 'Subtasks done', 'With', 'Visibility']].concat(tasks.map(function (t) {
        var c = R.countSubtasks(t.Subtasks);
        return [t.Title, t.Status, t.OwnerEmail, t.AssignedByEmail, t.Category, t.Priority, t.PlannedDate, t.OriginalPlannedDate, t.DueDate, t.CompletedAt, t.Kind, t.TemplateId, t.CycleId, c.done + '/' + c.total, (t.WithPeople || []).map(function (p) { return p.name; }).join('; '), t.Visibility];
      }))), 'text/csv');
      return;
    }
    var out = { exportedAt: nowIso(), app: CONFIG.appName, user: S.myEmail, tasks: tasks.map(baseCopy), activity: act.map(baseCopy),
      routines: S.templates.filter(function (t) { return t.OwnerEmail === S.myEmail; }).map(function (t) { var b = baseCopy(t); b.Title = asRuleTpl(t).Title; return b; }),
      conversations: S.notes.concat(S.shared).filter(function (n) { return n.OwnerEmail === S.myEmail; }).map(baseCopy),
      dayNotes: r[2].map(fromSP).filter(function (d) { return d.OwnerEmail === S.myEmail; }).map(baseCopy), prefs: S.prefs[S.myEmail] ? baseCopy(S.prefs[S.myEmail]) : null, contacts: S.contacts.map(baseCopy) };
    download('back-office-backup-' + S.today + '.json', JSON.stringify(out, null, 2), 'application/json');
  }, function (e) { toast('Export failed: ' + e.message); });
}

/* ---------- setup ---------- */
function slog(line) { (S.setupLog = S.setupLog || []).push(line); var el = byId('setuplog'); if (el) { el.textContent = S.setupLog.join('\n'); el.scrollTop = el.scrollHeight; } }
function provision() {
  S.setupLog = []; slog('Starting… ' + new Date().toLocaleString());
  var chain = Promise.resolve();
  BOCCSchema.lists.forEach(function (def) { chain = chain.then(function () { return SP.provisionList(def, slog); }); });
  chain.then(function () {
    if (!personBy(S.myEmail)) {
      slog('Adding you to the team list');
      return createRec('BOCC_People', { Title: (AUTH.account() && AUTH.account().name) || S.myEmail, Email: S.myEmail, JobTitle: 'HR', Access: 'Executive', Raises: 'Submit', Active: true, SortOrder: 2 }, 'Email')
        .then(function (r) { S.people.push(r); S.me = r; });
    }
  }).then(function () { slog('Done. Reloading data…'); return loadAll(); }).then(function () { slog('Ready.'); render(); }, function (e) { slog('STOPPED: ' + e.message); });
}
function restrictRaises() {
  S.setupLog = S.setupLog || [];
  var ppl = [{ email: S.myEmail, role: 'Full Control' }];
  activePeople().forEach(function (p) { if (p.Email !== S.myEmail && (p.Raises === 'Approve' || p.Raises === 'Submit')) { ppl.push({ email: p.Email, role: 'Contribute' }); } });
  SP.restrictList('BOCC_Raises', ppl, slog).then(function () { slog('Raise Requests locked to: ' + ppl.map(function (p) { return p.email; }).join(', ')); }, function (e) { slog('STOPPED: ' + e.message); });
}
function grantAccess() {
  var chain = Promise.resolve();
  activePeople().forEach(function (p) {
    if (p.Email === S.myEmail) { return; }
    chain = chain.then(function () { slog('Granting site access: ' + p.Email); return SP.addMember(p.Email).catch(function (e) { slog('  could not add ' + p.Email + ': ' + e.message); }); });
  });
  chain.then(function () { slog('Site access done.'); });
}

/* ---------- access log ---------- */
var session = { id: null, rec: null };
function startAccessLog() {
  session.id = R.uid('s');
  createRec('BOCC_Access', { Title: S.myEmail, SessionId: session.id, UserEmail: S.myEmail, SignedInAt: nowIso(), LastActive: nowIso(), Device: device(), Browser: browser() }, 'SessionId')
    .then(function (r) { session.rec = r; }, function () {});
  setInterval(function () { if (!document.hidden && session.rec) { Q.change('BOCC_Access', session.rec, { LastActive: nowIso() }, 0); } }, CONFIG.accessPingMs);
}
function loadAccess() { return SP.getAll('BOCC_Access').then(function (r) { S.access = r.map(fromSP); render(); }); }

/* ================= event wiring ================= */
var undoFn = null;
var A = {
  view: function (el) { S.view = el.getAttribute('data-v'); S.search = ''; S.navOpen = false; S.drawer = null; if (S.view === 'today') { S.viewing = S.myEmail; S.day = S.today; } if (S.view === 'access') { loadAccess(); } window.scrollTo(0, 0); render(); },
  navtoggle: function () { S.navOpen = !S.navOpen; render(); },
  prev: function () { if (S.view === 'week') { S.weekStart = R.addDays(S.weekStart, -7); } else { S.day = R.addDays(S.day, -1); } render(); },
  next: function () { if (S.view === 'week') { S.weekStart = R.addDays(S.weekStart, 7); } else { S.day = R.addDays(S.day, 1); } render(); },
  gotoday: function (el) { var d = el.getAttribute('data-day'); S.day = d || S.today; S.weekStart = R.sundayOf(S.day); S.view = 'today'; S.search = ''; render(); },
  signout: function () { if (Q.any()) { Q.flushAll(); } AUTH.logout(); },
  newtask: function (el) { newTaskModal(el.getAttribute('data-owner')); },
  newlog: function (el) { newLog({ taskId: el.getAttribute('data-task'), node: el.getAttribute('data-node') }); },
  open: function (el, ev) {
    if (ev.target && (ev.target.type === 'checkbox' || ev.target.closest('button'))) { return; }
    var id = el.getAttribute('data-id'), t = findTask(id);
    S.drawer = { id: id }; S.picker = null;
    if (t && !t.Virtual && t.OwnerEmail === S.myEmail && t.AssignedByEmail && t.AssignedByEmail !== S.myEmail && !t.SeenByOwner) { changeTask(t, { SeenByOwner: true }, 0); }
    render();
  },
  closedrawer: function () { S.drawer = null; S.picker = null; render(); },
  toggle: function (el, ev) {
    ev.stopPropagation();
    withTask(el.getAttribute('data-id'), function (t) {
      if (t.Status === 'Completed') { applyTaskField(t, 'Status', 'Not Started'); logActivity(t, 'Reopened'); }
      else { tryComplete(t, false); }
    });
  },
  complete: function (el) { withTask(el.getAttribute('data-id'), function (t) { tryComplete(t, false); }); },
  completeforce: function (el) { withTask(el.getAttribute('data-id'), function (t) { tryComplete(t, true); }); },
  completeall: function (el) { withTask(el.getAttribute('data-id'), function (t) { var tree = R.completeAll(copy(t.Subtasks || []), S.myEmail, nowIso()); changeTask(t, { Subtasks: tree }, 0); t.Subtasks = tree; tryComplete(t, false); }); },
  reopen: function (el) { withTask(el.getAttribute('data-id'), function (t) { changeTask(t, { Status: 'Not Started', CompletedAt: '', CompletedBy: '' }, 0); logActivity(t, 'Reopened'); render(); }); },
  cancel: function (el) { withTask(el.getAttribute('data-id'), function (t) { var prev = t.Status; changeTask(t, { Status: 'Cancelled' }, 0); logActivity(t, 'Cancelled'); undoFn = function () { changeTask(t, { Status: prev }, 0); render(); }; toast('Task cancelled', true); render(); }); },
  archive: function (el) { withTask(el.getAttribute('data-id'), function (t) { changeTask(t, { Archived: true }, 0); logActivity(t, 'Archived'); S.drawer = null; undoFn = function () { changeTask(t, { Archived: false }, 0); render(); }; toast('Archived', true); render(); }); },
  restore: function (el) { withTask(el.getAttribute('data-id'), function (t) { changeTask(t, { Archived: false }, 0); logActivity(t, 'Restored'); render(); }); },
  undo: function () { if (undoFn) { undoFn(); undoFn = null; } S.toast = null; render(); },
  invite: function (el) { withTask(el.getAttribute('data-id'), function (t) { changeTask(t, { InviteSentAt: t.InviteSentAt ? '' : nowIso() }, 0); logActivity(t, t.InviteSentAt ? 'Teams invite marked sent' : 'Invite mark removed'); render(); }); },
  nodeinvite: function (el) { var nid = el.getAttribute('data-node'); withTask(el.getAttribute('data-id'), function (t) { mutateTree(t, function (tree) { var n = R.findNode(tree, nid); if (n) { n.inviteSentAt = n.inviteSentAt ? '' : nowIso(); } }, 'Teams invite sent: ' + (R.findNode(t.Subtasks || [], nid) || {}).title); }); },
  callstate: function (el) { var v = el.getAttribute('data-v'); withTask(el.getAttribute('data-id'), function (t) { changeTask(t, { CallState: v, Status: v === 'Held' ? 'Completed' : t.Status, CompletedAt: v === 'Held' ? nowIso() : t.CompletedAt }, 0); logActivity(t, 'Call ' + v.toLowerCase()); render(); }); },
  movework: function (el) { withTask(el.getAttribute('data-id'), function (t) { applyTaskField(t, 'PlannedDate', R.nextWorkDayOnOrAfter(workOf(t.OwnerEmail), t.PlannedDate)); }); },
  addsub: function (el) {
    var nid = el.getAttribute('data-node');
    withTask(el.getAttribute('data-id'), function (t) {
      var newId = R.uid('n');
      mutateTree(t, function (tree) {
        var node = { id: newId, title: '', done: false, with: [], children: [] };
        if (nid) { var p = R.findNode(tree, nid); if (p) { (p.children = p.children || []).push(node); } } else { tree.push(node); }
      });
      setTimeout(function () { var x = byId('n-' + newId); if (x) { x.focus(); } }, 40);
    });
  },
  delsub: function (el) {
    var nid = el.getAttribute('data-node');
    withTask(el.getAttribute('data-id'), function (t) {
      var before = copy(t.Subtasks || []);
      mutateTree(t, function (tree) { var pl = R.findParentList(tree, nid); if (pl) { for (var i = 0; i < pl.length; i++) { if (pl[i].id === nid) { pl.splice(i, 1); break; } } } });
      undoFn = function () { changeTask(t, { Subtasks: before }, 0); render(); }; toast('Subtask removed', true);
    });
  },
  reqsub: function (el) { var nid = el.getAttribute('data-node'); withTask(el.getAttribute('data-id'), function (t) { mutateTree(t, function (tree) { var n = R.findNode(tree, nid); if (n) { n.required = !n.required; } }); }); },
  pick: function (el) { S.picker = { target: el.getAttribute('data-target'), id: el.getAttribute('data-id'), node: el.getAttribute('data-node') || null, q: '' }; render(); setTimeout(function () { var q = byId('pick-q'); if (q) { q.focus(); } }, 30); },
  pickone: function (el) { var list = pickerList(); addPerson(list[+el.getAttribute('data-i')]); setTimeout(function () { var q = byId('pick-q'); if (q) { q.focus(); } }, 30); },
  picknew: function () {
    var name = S.picker.q.trim(), role = byId('pick-role') ? byId('pick-role').value : 'Other';
    if (!name) { return; }
    createRec('BOCC_Contacts', { Title: name, Role: role, Active: true }).then(function (c) { S.contacts.push(c); addPerson({ name: c.Title, role: c.Role, contactId: c._id }); }, function (e) { toast('Could not add: ' + e.message); });
  },
  pickclose: function () { S.picker = null; render(); },
  unwith: function (el) { var i = +el.getAttribute('data-i'); withTask(el.getAttribute('data-id'), function (t) { var l = copy(t.WithPeople || []); l.splice(i, 1); changeTask(t, { WithPeople: l }, 0); render(); }); },
  unwithnode: function (el) { var i = +el.getAttribute('data-i'), nid = el.getAttribute('data-node'); withTask(el.getAttribute('data-id'), function (t) { mutateTree(t, function (tree) { var n = R.findNode(tree, nid); if (n) { n.with.splice(i, 1); } }); }); },
  unlogperson: function (el) { S.modal.f.People.splice(+el.getAttribute('data-i'), 1); saveLogDraft(); render(); },
  unlink: function () { S.modal.f.LinkedTaskKey = ''; S.modal.f.LinkedNodeId = ''; render(); },
  comment: function (el) {
    var v = byId('f-cmt').value.trim(); if (!v) { return; }
    withTask(el.getAttribute('data-id'), function (t) { changeTask(t, { Comments: (t.Comments || []).concat([{ by: S.myEmail, at: nowIso(), text: v }]) }, 0); logActivity(t, 'Comment'); render(); });
  },
  loadhist: function (el) {
    var t = findTask(el.getAttribute('data-id'));
    SP.getAll('BOCC_Activity', "TaskKey eq '" + String(t.TaskKey).replace(/'/g, "''") + "'").then(function (r) {
      if (S.drawer) { S.drawer.history = r.map(fromSP).sort(function (a, b) { return a.At < b.At ? 1 : -1; }); render(); }
    }, function (e) { toast('Could not load history: ' + e.message); });
  },
  sendbackopen: function () { S.drawer.sendback = { reason: 'Need more info', note: '', suggest: '' }; render(); setTimeout(function () { var x = byId('sb-note'); if (x) { x.focus(); } }, 30); },
  sbreason: function (el) { S.drawer.sendback.reason = el.getAttribute('data-v'); render(); },
  sendbackcancel: function () { S.drawer.sendback = null; render(); },
  sendback: function (el) {
    var sb = S.drawer.sendback;
    if (!sb.note.trim()) { sb.err = 'Add a note so they know why.'; render(); return; }
    withTask(el.getAttribute('data-id'), function (t) {
      var to = t.AssignedByEmail;
      changeTask(t, { OwnerEmail: to, AssignedByEmail: S.myEmail, SeenByOwner: false, Status: 'Not Started', PlannedDate: R.isDate(sb.suggest) ? sb.suggest : S.today,
        SendBack: (t.SendBack || []).concat([{ by: S.myEmail, at: nowIso(), reason: sb.reason, note: sb.note.trim(), suggest: sb.suggest || '' }]) }, 0);
      logActivity(t, 'Sent back to ' + nameOf(to), sb.reason + ' — ' + sb.note.trim());
      S.drawer = null; render(); toast('Sent back to ' + nameOf(to));
    });
  },
  keepmine: function (el) { var t = S.tasks[el.getAttribute('data-id')]; if (t && t._conflict) { var f = {}; t._conflict.fields.forEach(function (k) { f[k] = t._conflict.mine[k]; }); t._conflict = null; changeTask(t, f, 0); render(); } },
  dropconflict: function (el) { var t = S.tasks[el.getAttribute('data-id')]; if (t) { t._conflict = null; render(); } },
  closemodal: function () { S.modal = null; S.picker = null; render(); },
  closelog: function () {
    var m = S.modal, f = m.f;
    if (m.state === 'Saved' || (!f.Discussion && !f.People.length && !f.Outcome)) { if (!m.editId) { clearDraft(m.draftId); } S.modal = null; S.picker = null; render(); return; }
    S.confirmBack = m; S.modal = { type: 'confirm', title: 'Discard this conversation?', text: 'Your typed notes will be deleted. To keep them for later, choose Keep draft — it stays saved and reopens next time you click Log Conversation.', yes: 'Discard', no: 'Keep draft', act: 'discardlog', draftId: m.draftId };
    render();
  },
  confirmyes: function () { var m = S.modal; if (m.act === 'discardlog') { clearDraft(m.draftId); S.confirmBack = null; S.modal = null; } else if (m.act === 'stoproutine') { var t = rec('BOCC_Templates', m.id); Q.change('BOCC_Templates', t, { Active: false, EndDate: S.today }, 0); S.modal = null; toast('Routine stopped · history kept'); } render(); },
  scope: function (el) {
    var m = S.modal, t = S.tasks[m.id] || findTask(m.id), v = el.getAttribute('data-v');
    S.modal = null;
    applyTaskField(t, m.field, m.value);
    if (v === 'future' && t.TemplateId) {
      var tp = null; S.templates.forEach(function (x) { if (x.TemplateId === t.TemplateId) { tp = x; } });
      if (tp) {
        var ch = {}; ch[m.field] = m.value;
        if (m.field === 'Title' && tp.Private) { savePrivate('tpl|' + tp.TemplateId, { RealTitle: m.value }); delete ch.Title; }
        var sp = R.splitTemplate(asRuleTpl(tp), R.addDays(t.PlannedDate, 1), ch, 'tpl-' + R.uid('x').slice(2));
        Q.change('BOCC_Templates', tp, { EndDate: sp.oldTemplate.EndDate }, 0);
        var nt = baseCopy(tp); nt.TemplateId = sp.newTemplate.Id; nt.StartDate = sp.newTemplate.StartDate; nt.EndDate = tp.EndDate || ''; nt.Skips = [];
        var k; for (k in ch) { if (ch.hasOwnProperty(k)) { nt[k] = ch[k]; } }
        createRec('BOCC_Templates', nt, 'TemplateId').then(function (r) { S.templates.push(r); if (tp.Private) { var pv = S.privateMap['tpl|' + tp.TemplateId]; if (pv) { savePrivate('tpl|' + r.TemplateId, { RealTitle: m.field === 'Title' ? m.value : pv.RealTitle }); } } render(); });
      }
    }
    render();
  },
  mset: function (el) { S.modal.f[el.getAttribute('data-k')] = el.getAttribute('data-v'); if (el.getAttribute('data-k') === 'OwnerEmail' && el.getAttribute('data-v') !== S.myEmail) { S.modal.f.Private = false; } render(); },
  mday: function (el) { var i = +el.getAttribute('data-i'), d = S.modal.f.days.split(''); d[i] = d[i] === '1' ? '0' : '1'; S.modal.f.days = d.join(''); render(); },
  tday: function (el) { var i = +el.getAttribute('data-i'), d = S.modal.f.Days.split(''); d[i] = d[i] === '1' ? '0' : '1'; S.modal.f.Days = d.join(''); render(); },
  savetask: function () { saveTask(); },
  savelog: function () { saveLog(); },
  editnote: function (el) {
    var list = el.getAttribute('data-list'), n = rec(list, el.getAttribute('data-id'));
    var at = n.ConvAt ? R.nyNow(new Date(n.ConvAt)) : { date: n.ConvDate, time: '' };
    S.modal = { type: 'log', editId: n._id, editList: list, draftId: 'edit', state: 'Unsaved', f: { People: copy(n.People || []), date: n.ConvDate || at.date, time: at.time, Method: n.Method || 'Call', Stores: n.Stores, Title: n.Title,
      Discussion: n.Discussion || '', Outcome: n.Outcome || '', Visibility: n.Visibility === 'Shared' ? 'Shared' : 'Private', LinkedTaskKey: n.LinkedTaskKey, LinkedNodeId: n.LinkedNodeId, WantsFollowUp: false, NextAction: '', FollowUpDate: '' } };
    render();
  },
  archnote: function (el) { var list = el.getAttribute('data-list'), n = rec(list, el.getAttribute('data-id')), v = el.getAttribute('data-v') === '1'; Q.change(list, n, { Archived: v }, 0); if (v) { undoFn = function () { Q.change(list, n, { Archived: false }, 0); render(); }; toast('Conversation archived', true); } render(); },
  exportnotes: function (el) { exportNotes(el.getAttribute('data-v')); },
  raisetab: function (el) { S.raiseTab = el.getAttribute('data-v'); S.raiseSel = null; render(); },
  raisesel: function (el) { S.raiseSel = +el.getAttribute('data-id'); render(); },
  newraise: function () { raiseModal0(null); },
  editraise: function (el) { raiseModal0(rec('BOCC_Raises', el.getAttribute('data-id'))); },
  saveraise: function (el) { saveRaise(el.getAttribute('data-v')); },
  decide: function (el) { decideRaise(el.getAttribute('data-id'), el.getAttribute('data-v')); },
  raiseatt: function (el) { var id = +el.getAttribute('data-id'); SP.attachments('BOCC_Raises', id).then(function (f) { S.raiseAtt = { id: id, files: f }; render(); }, function (e) { toast(e.message); }); },
  wday: function (el) { var i = +el.getAttribute('data-i'); myPrefs().then(function (p) { var d = (p.WorkDays || R.DEFAULT_WORKDAYS).split(''); d[i] = d[i] === '1' ? '0' : '1'; Q.change('BOCC_Prefs', p, { WorkDays: d.join('') }, 300); render(); }); },
  addoff: function () { var v = byId('p-off').value; if (!R.isDate(v)) { return; } myPrefs().then(function (p) { var l = (p.TimeOff || []).slice(); if (l.indexOf(v) < 0) { l.push(v); l.sort(); } Q.change('BOCC_Prefs', p, { TimeOff: l }, 0); render(); }); },
  deloff: function (el) { var i = +el.getAttribute('data-i'); myPrefs().then(function (p) { var l = (p.TimeOff || []).slice(); l.splice(i, 1); Q.change('BOCC_Prefs', p, { TimeOff: l }, 0); render(); }); },
  catadd: function () { myPrefs().then(function (p) { var l = (p.Categories || []).slice(); l.push('New category'); Q.change('BOCC_Prefs', p, { Categories: l }, 0); render(); }); },
  catdel: function (el) { var i = +el.getAttribute('data-i'); myPrefs().then(function (p) { var l = (p.Categories || []).slice(); l.splice(i, 1); Q.change('BOCC_Prefs', p, { Categories: l }, 0); render(); }); },
  catup: function (el) { var i = +el.getAttribute('data-i'); if (!i) { return; } myPrefs().then(function (p) { var l = (p.Categories || []).slice(), x = l[i]; l[i] = l[i - 1]; l[i - 1] = x; Q.change('BOCC_Prefs', p, { Categories: l }, 0); render(); }); },
  newroutine: function () { routineModal0(null); },
  editroutine: function (el) { routineModal0(rec('BOCC_Templates', el.getAttribute('data-id'))); },
  stoproutine: function (el) { S.modal = { type: 'confirm', title: 'Stop this routine?', text: 'It won’t appear from today on. Everything already done stays in your history.', yes: 'Stop routine', act: 'stoproutine', id: el.getAttribute('data-id') }; render(); },
  saveroutine: function () { saveRoutine(); },
  newcontact: function () { S.modal = { type: 'contact', f: { Title: '', Role: 'Store Manager', NTID: '', Stores: '', Coach: '', Email: '', Phone: '', Active: true } }; render(); },
  editcontact: function (el) { var c = rec('BOCC_Contacts', el.getAttribute('data-id')); S.modal = { type: 'contact', editId: c._id, f: baseCopy(c) }; render(); },
  savecontact: function () {
    var m = S.modal, f = m.f; if (!f.Title) { m.err = 'Name is required.'; render(); return; }
    var fields = { Title: f.Title, Role: f.Role, NTID: lc(f.NTID), Stores: f.Stores, Coach: f.Coach, Email: f.Email, Phone: f.Phone, Active: f.Active !== false };
    if (m.editId) { Q.change('BOCC_Contacts', rec('BOCC_Contacts', m.editId), fields, 0); S.modal = null; render(); return; }
    createRec('BOCC_Contacts', fields).then(function (c) { S.contacts.push(c); S.modal = null; render(); }, function (e) { m.err = e.message; render(); });
  },
  newperson: function () { S.modal = { type: 'person', f: { Title: '', Email: '', JobTitle: '', ReportsTo: '', Access: 'Member', Raises: '', Active: true, SortOrder: 10 } }; render(); },
  editperson: function (el) { var p = rec('BOCC_People', el.getAttribute('data-id')); S.modal = { type: 'person', editId: p._id, f: baseCopy(p) }; render(); },
  saveperson: function () {
    var m = S.modal, f = m.f;
    if (!f.Title || !/@/.test(f.Email || '')) { m.err = 'Name and a Microsoft email are required.'; render(); return; }
    var fields = { Title: f.Title, Email: lc(f.Email), JobTitle: f.JobTitle, ReportsTo: lc(f.ReportsTo), Access: f.Access, Raises: f.Raises, Active: f.Active !== false, SortOrder: f.SortOrder === '' ? 10 : +f.SortOrder };
    if (m.editId) { Q.change('BOCC_People', rec('BOCC_People', m.editId), fields, 0); S.modal = null; render(); return; }
    createRec('BOCC_People', fields, 'Email').then(function (p) { S.people.push(p); S.modal = null; render(); toast('Added. Run Setup → Grant site access so they can sign in.'); }, function (e) { m.err = e.message; render(); });
  },
  backup: function (el) { backup(el.getAttribute('data-v')); },
  reloadaccess: function () { loadAccess(); },
  exportaccess: function () { download('access-log-' + S.today + '.csv', csv([['Person', 'Email', 'Signed in', 'Last active', 'Device', 'Browser']].concat(S.access.map(function (r) { return [nameOf(r.UserEmail), r.UserEmail, r.SignedInAt, r.LastActive, r.Device, r.Browser]; }))), 'text/csv'); },
  provision: function () { provision(); },
  restrictraises: function () { restrictRaises(); },
  grantaccess: function () { grantAccess(); },
  teamsel: function (el) { S.teamSel = el.getAttribute('data-email'); render(); },
  viewweek: function (el) { S.viewing = el.getAttribute('data-email'); S.view = 'week'; S.weekStart = R.sundayOf(S.today); render(); },
  notetotask: function (el) {
    var ta = byId('daynote'), sel = ta ? ta.value.substring(ta.selectionStart, ta.selectionEnd).trim() : '';
    if (!sel && ta) { var before = ta.value.substring(0, ta.selectionStart), lineStart = before.lastIndexOf('\n') + 1, lineEnd = ta.value.indexOf('\n', ta.selectionStart); sel = ta.value.substring(lineStart, lineEnd < 0 ? ta.value.length : lineEnd).trim(); }
    if (!sel) { toast('Select a line in your notes first.'); return; }
    quickAdd(sel); toast('Task added: ' + sel);
  }
};
document.addEventListener('click', function (ev) {
  var el = ev.target.closest('[data-act]'); if (!el) { return; }
  var act = el.getAttribute('data-act');
  if (/^(search|quick|daynote|pickq|contactq|viewing|importroutines|importcontacts)$/.test(act)) { return; }
  if (act === 'subdone') { return; }
  if (A[act]) { if (el.tagName === 'A' || el.tagName === 'BUTTON') { ev.preventDefault(); } A[act](el, ev); }
});
document.addEventListener('keydown', function (ev) {
  if (ev.key === 'Escape') { if (S.picker) { S.picker = null; render(); } else if (S.modal) { if (S.modal.type === 'log') { A.closelog(); } else { S.modal = null; render(); } } else if (S.drawer) { S.drawer = null; render(); } else if (S.navOpen) { S.navOpen = false; render(); } return; }
  var el = ev.target;
  if (ev.key === 'Enter' && el.id === 'quick') { ev.preventDefault(); var v = el.value; el.value = ''; quickAdd(v); return; }
  if (ev.key === 'Enter' && el.id === 'f-cmt') { ev.preventDefault(); A.comment({ getAttribute: function () { return S.drawer.id; } }); return; }
  if (ev.key === 'Enter' && el.classList && el.classList.contains('stt')) { ev.preventDefault(); el.blur(); return; }
  if ((ev.key === 'Enter' || ev.key === ' ') && el.getAttribute && el.getAttribute('role') === 'button' && el.getAttribute('data-act')) { ev.preventDefault(); el.click(); }
  if (ev.key === 'Enter' && el.classList && el.classList.contains('r') && el.getAttribute('data-act') === 'open') { A.open(el, ev); }
});
var searchLater = debounce(function () { render(); }, 250);
var dayNoteLater = debounce(function (day, text) {
  var key = S.myEmail + '|' + day, r = S.dayNotes[key];
  if (r) { Q.change('BOCC_DayNotes', r, { Text: text }, 0); return; }
  createRec('BOCC_DayNotes', { Title: day, Key: key, OwnerEmail: S.myEmail, Day: day, Text: text }, 'Key').then(function (x) { S.dayNotes[key] = x; if (x.Text !== text) { Q.change('BOCC_DayNotes', x, { Text: text }, 0); } });
}, 900);
function onField(ev) {
  var el = ev.target, v = el.type === 'checkbox' ? el.checked : el.value, a;
  if ((a = el.getAttribute('data-act'))) {
    if (a === 'search') { S.search = v.trim(); searchLater(); return; }
    if (a === 'daynote') { try { localStorage.setItem('bocc-daynote-' + el.getAttribute('data-day'), v); } catch (e) {} dayNoteLater(el.getAttribute('data-day'), v); return; }
    if (a === 'pickq') { S.picker.q = v; render(); return; }
    if (a === 'contactq') { S.contactQ = v; debounce(render, 200)(); return; }
    if (a === 'viewing' && ev.type === 'change') { S.viewing = v; render(); return; }
    if (a === 'importroutines' && ev.type === 'change' && el.files[0]) { importRoutines(el.files[0]); return; }
    if (a === 'importcontacts' && ev.type === 'change' && el.files[0]) { importContacts(el.files[0]); return; }
    if (a === 'subdone' && ev.type === 'change') {
      var nid = el.getAttribute('data-node');
      withTask(el.getAttribute('data-id'), function (t) {
        var node = R.findNode(t.Subtasks || [], nid);
        mutateTree(t, function (tree) { var n = R.findNode(tree, nid); if (n) { n.done = v; n.doneAt = v ? nowIso() : ''; n.doneBy = v ? S.myEmail : ''; } },
          (v ? 'Done: ' : 'Reopened: ') + (node ? node.title : '') + (v && node && node.with && node.with.length ? ' · with ' + node.with.map(function (p) { return p.name; }).join(', ') : ''));
      });
      return;
    }
  }
  var k;
  if ((k = el.getAttribute('data-f'))) {
    var commit = el.tagName === 'SELECT' || el.type === 'date' || el.type === 'time' || el.type === 'number' || el.type === 'checkbox';
    // pickers & selects save on change; the title saves when you leave it (it may ask "this or future");
    // other text fields autosave while typing.
    if (commit || k === 'Title' || k === 'Category') { if (ev.type === 'change') { setTaskField(S.drawer.id, k, v); } }
    else if (ev.type === 'input') { setTaskField(S.drawer.id, k, v); }
    return;
  }
  if ((k = el.getAttribute('data-nf'))) {
    if (ev.type !== 'change') { return; }
    var nid2 = el.getAttribute('data-node');
    withTask(el.getAttribute('data-id'), function (t) { mutateTree(t, function (tree) { var n = R.findNode(tree, nid2); if (n) { n[k] = v; } }); });
    return;
  }
  if ((k = el.getAttribute('data-mf'))) { S.modal.f[k] = v; if (ev.type === 'change' && (el.tagName === 'SELECT' || el.type === 'checkbox' || el.type === 'date')) { render(); } return; }
  if ((k = el.getAttribute('data-lf'))) { S.modal.f[k] = v; if (S.modal.state !== 'Saving…') { S.modal.state = S.modal.editId ? 'Unsaved' : S.modal.state; } saveLogDraft(); if (el.type === 'checkbox' || (ev.type === 'change' && el.tagName === 'SELECT')) { render(); } return; }
  if ((k = el.getAttribute('data-rf'))) { S.modal.f[k] = v; if (k === 'CurrentRate' || k === 'ProposedRate') { var ch = R.raiseChange(S.modal.f.CurrentRate, S.modal.f.ProposedRate), out = byId('r-chg'); if (out) { out.value = ch ? (ch.amount >= 0 ? '+' : '') + '$' + ch.amount.toFixed(2) + ' · ' + ch.pct + '%' : 'Calculated'; } } if (ev.type === 'change' && k === 'Title') { S.contacts.forEach(function (c) { if (c.Title === v) { S.modal.f.NTID = c.NTID || ''; S.modal.f.Store = c.Stores || ''; if (byId('r-ntid') && !byId('r-ntid').value) { byId('r-ntid').value = S.modal.f.NTID; } if (byId('r-store') && !byId('r-store').value) { byId('r-store').value = S.modal.f.Store; } } }); } return; }
  if ((k = el.getAttribute('data-tf'))) { S.modal.f[k] = v; if (ev.type === 'change' && (el.tagName === 'SELECT' || el.type === 'checkbox')) { if (k === 'Kind') { S.modal.f.Rollover = v === 'Task' ? 'Carry' : 'Stay'; } render(); } return; }
  if ((k = el.getAttribute('data-pmf'))) { S.modal.f[k] = v; return; }
  if ((k = el.getAttribute('data-cmf'))) { S.modal.f[k] = v; return; }
  if ((k = el.getAttribute('data-sb'))) { S.drawer.sendback[k] = v; S.drawer.sendback.err = ''; return; }
  if ((k = el.getAttribute('data-lfil'))) { S.logF[k] = v; if (ev.type === 'change' || el.type !== 'text') { softRenderSoon(); } else { debounce(render, 300)(); } return; }
  if ((k = el.getAttribute('data-pf'))) { if (ev.type === 'change') { var o = {}; o[k] = v; setPref(o, false); } return; }
  if (el.hasAttribute('data-theme')) {
    if (ev.type !== 'change') { return; }
    var i = el.getAttribute('data-theme'); myPrefs().then(function (p) { var th = copy(p.DayThemes || {}); th[i] = v; Q.change('BOCC_Prefs', p, { DayThemes: th }, 300); });
    return;
  }
  if (el.hasAttribute('data-cat') && ev.type === 'change') {
    var ci = +el.getAttribute('data-cat');
    myPrefs().then(function (p) {
      var l = (p.Categories || []).slice(), old = l[ci]; l[ci] = v; Q.change('BOCC_Prefs', p, { Categories: l }, 0);
      if (old && old !== v) {
        tasksOf(S.myEmail).forEach(function (t) { if (t.Category === old && R.isOpen(t)) { changeTask(t, { Category: v }, 0); } });
        templatesOf(S.myEmail).forEach(function (t) { if (t.Category === old) { Q.change('BOCC_Templates', t, { Category: v }, 0); } });
      }
      render();
    });
  }
}
var softRenderSoon = debounce(function () { render(); }, 50);
document.addEventListener('input', onField);
document.addEventListener('change', onField);
document.addEventListener('visibilitychange', function () { if (!document.hidden) { checkDay(); sync(); } });

/* ================= boot ================= */
function screen(html) { byId('app').innerHTML = html; }
function loginScreen(msg) {
  screen('<div class="login"><section class="l"><div style="display:flex;align-items:center;gap:12px"><span class="dia" style="width:22px;height:22px"></span><span style="font-family:\'Bebas Neue\',Impact,sans-serif;font-size:26px;letter-spacing:1.5px">EdgeLink</span></div>' +
    '<div style="display:flex;flex-direction:column;gap:22px;max-width:520px"><h1>Back Office<br>Command Center</h1><p style="margin:0;font-size:16px;line-height:1.55;color:#E3D3EE">Your day, your team’s work, and everything handed between you — in one place, saved as you go.</p>' +
    '<div class="feat"><span class="tick">✓</span><div><b>Today, carried forward</b>Unfinished work follows you to your next work day.</div></div><div class="feat"><span class="tick">✓</span><div><b>Assign and send back</b>Hand tasks to anyone on the team, with notes both ways.</div></div><div class="feat"><span class="tick">✓</span><div><b>Private when it needs to be</b>Confidential blocks and notes stay yours.</div></div></div>' +
    '<div style="font-size:12px;color:#C9B3D8">EdgeLink Inc. · Internal use only</div></section>' +
    '<section class="r2"><div style="width:100%;max-width:400px;display:flex;flex-direction:column;gap:16px"><div class="card" style="padding:30px 26px;display:flex;flex-direction:column;gap:16px;border-radius:14px">' +
    '<div><h2 style="margin:0;font-size:24px;color:var(--plum)">Sign in</h2><p style="margin:6px 0 0;color:var(--mute);line-height:1.5">Use your EdgeLink Microsoft account — the same one you use for Outlook and Teams.</p></div>' +
    '<button class="ms" id="signin"><svg width="20" height="20" viewBox="0 0 21 21" aria-hidden="true"><rect x="1" y="1" width="9" height="9" fill="#F25022"></rect><rect x="11" y="1" width="9" height="9" fill="#7FBA00"></rect><rect x="1" y="11" width="9" height="9" fill="#00A4EF"></rect><rect x="11" y="11" width="9" height="9" fill="#FFB900"></rect></svg>Sign in with Microsoft</button>' +
    '<div style="font-size:12px;color:var(--mute2);border-top:1px solid var(--line2);padding-top:12px;line-height:1.5">Works on PC, iPad, tablet and phone. Microsoft handles your password — this app never sees it.</div></div>' +
    (msg ? '<div class="bad-box" role="alert">' + msg + '</div>' : '') +
    '<div style="text-align:center;font-size:12px;color:var(--mute2)">Trouble signing in? <a href="mailto:hr@edgelinkinc.com">hr@edgelinkinc.com</a></div></div></section></div>');
  byId('signin').onclick = function () { AUTH.login(); };
}
function messageScreen(title, body, actions) {
  screen('<div class="login"><section class="r2" style="flex-basis:100%"><div class="card" style="max-width:520px;padding:28px;border-radius:14px;display:flex;flex-direction:column;gap:12px"><h2 style="margin:0;color:var(--plum)">' + esc(title) + '</h2><div style="line-height:1.55">' + body + '</div><div style="display:flex;gap:8px;flex-wrap:wrap">' + (actions || '') +
    '<button class="btn" id="so">Sign out</button></div></div></section></div>');
  byId('so').onclick = function () { AUTH.logout(); };
}
function checkDay() {
  var t = R.nyNow().date;
  if (t !== S.today) {
    var wasToday = S.day === S.today;
    S.today = t; if (wasToday) { S.day = t; S.weekStart = R.sundayOf(t); }
    materialize(); render();
  } else if (S.ready && S.view === 'today' && S.day === S.today) { softRender(); }
}
function restorePending() {
  var p = jparse(localStorage.getItem('bocc-pending'), []);
  p.forEach(function (x) { var r = rec(x.list, x.id); if (r) { Q.change(x.list, r, x.fields, 200); } });
}
function boot() {
  screen('<div style="padding:40px;text-align:center;color:var(--mute)">Loading…</div>');
  if (CONFIG.clientId.indexOf('__') === 0) { messageScreen('Not configured yet', 'This page needs its Azure app ID. Ask HR.'); return; }
  AUTH.init().then(function (account) {
    if (!account) { loginScreen(); return; }
    SP.init(CONFIG, AUTH.token);
    S.myEmail = lc(account.username);
    return SP.siteExists().then(function (exists) {
      if (!exists) { messageScreen('Almost ready', 'The SharePoint site for this app hasn’t been created yet. HR is setting it up.'); return; }
      return SP.canManage().then(function (admin) {
        S.admin = admin;
        return SP.canRead('BOCC_People').then(function (hasLists) {
          if (!hasLists) {
            if (!admin) { messageScreen('Almost ready', 'The app’s lists haven’t been set up yet, or you don’t have access. HR is setting it up.'); return; }
            S.me = { Title: account.name, Email: S.myEmail, Access: 'Executive' }; S.people = []; S.ready = true; S.view = 'setup'; S.viewing = S.myEmail; render(); return;
          }
          return loadAll().then(function () {
            S.me = personBy(S.myEmail);
            if (!S.me || S.me.Active === false) {
              if (admin) { S.me = { Title: account.name, Email: S.myEmail, Access: 'Executive' }; S.view = 'setup'; }
              else { messageScreen('This account isn’t on the Back Office team', 'Signed in as <b>' + esc(account.username) + '</b>. Ask HR to add you — <a href="mailto:hr@edgelinkinc.com">hr@edgelinkinc.com</a>.'); return; }
            }
            SP.getAll('BOCC_Drafts').then(function (r) { S.drafts = r.map(fromSP).filter(function (d) { return d.Json; }); }, function () {});
            S.viewing = S.myEmail; S.ready = true;
            restorePending(); render(); materialize(); startAccessLog();
            setInterval(sync, CONFIG.pollMs); setInterval(checkDay, 30000);
          });
        });
      });
    });
  }).catch(function (e) {
    var msg = (e && (e.errorMessage || e.message)) || 'Something went wrong.';
    if (/AADSTS50105|not assigned/i.test(msg)) { loginScreen('Your account isn’t allowed to use this app. Ask HR to add you.'); return; }
    if (e && e.status === 403) { messageScreen('No access yet', 'You’re signed in, but you don’t have access to the Back Office site yet. Ask HR to add you.'); return; }
    messageScreen('Couldn’t load', esc(msg) + '<br><br>Nothing you typed has been lost. Check your connection and reload.', '<button class="btn p" onclick="location.reload()">Reload</button>');
  });
}
document.addEventListener('DOMContentLoaded', boot);
