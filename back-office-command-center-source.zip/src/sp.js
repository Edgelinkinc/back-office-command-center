/* SharePoint REST data layer + schema + provisioning. ES5. */
var BOCCSchema = (function () {
  function T(n, o) { return { name: n, type: 'Text', indexed: o && o.indexed, unique: o && o.unique }; }
  function N(n) { return { name: n, type: 'Note' }; }
  function Num(n) { return { name: n, type: 'Number' }; }
  function B(n) { return { name: n, type: 'Boolean' }; }
  // security: 'team' = all members read/write; 'own' = item-level read/edit own only;
  // 'restricted' = broken inheritance, only listed people.
  var lists = [
    { title: 'BOCC_People', security: 'team', fields: [T('Email', { indexed: true, unique: true }), T('JobTitle'), T('ReportsTo'), T('Access'), T('Raises'), B('Active'), Num('SortOrder')] },
    { title: 'BOCC_Prefs', security: 'team', fields: [T('Email', { indexed: true, unique: true }), T('WorkDays'), T('DayStart'), T('DayEnd'), N('TimeOff'), N('DayThemes'), N('Categories'), T('DefaultVisibility')] },
    { title: 'BOCC_Tasks', security: 'team', versioning: true, fields: [
      T('TaskKey', { indexed: true, unique: true }), T('OwnerEmail', { indexed: true }), T('AssignedByEmail'), T('Category'), T('Kind'), T('Priority'),
      T('Status', { indexed: true }), T('PlannedDate', { indexed: true }), T('OriginalPlannedDate'), T('DueDate'), T('StartTime'), Num('DurationMin'),
      T('Rollover'), T('TemplateId'), T('CycleId'), N('Description'), N('Subtasks'), N('WithPeople'), T('Stores'), T('WaitingOn'), T('FollowUpDate'),
      T('CompletedAt'), T('CompletedBy'), T('CallState'), T('Visibility'), T('PublicLabel'), B('Archived'), N('SendBack'), N('Comments'),
      T('InviteSentAt'), B('SeenByOwner'), T('SourceNoteKey')] },
    { title: 'BOCC_Private', security: 'own', fields: [T('Key', { indexed: true, unique: true }), T('OwnerEmail'), T('RealTitle'), N('Details')] },
    { title: 'BOCC_Templates', security: 'team', fields: [
      T('TemplateId', { indexed: true, unique: true }), T('OwnerEmail', { indexed: true }), T('Kind'), T('Category'), T('Days'), T('StartTime'), Num('DurationMin'),
      T('AfterLabel'), T('Rollover'), T('Cycle'), N('Items'), T('StartDate'), T('EndDate'), N('Skips'), B('Active'), B('Private'), T('PublicLabel'), T('Priority'), Num('SortOrder')] },
    { title: 'BOCC_Notes', security: 'own', fields: noteFields() },
    { title: 'BOCC_SharedNotes', security: 'team', fields: noteFields() },
    { title: 'BOCC_DayNotes', security: 'own', fields: [T('Key', { indexed: true, unique: true }), T('OwnerEmail'), T('Day'), N('Text')] },
    { title: 'BOCC_Drafts', security: 'own', fields: [T('Key', { indexed: true, unique: true }), T('OwnerEmail'), T('Kind'), N('Json')] },
    { title: 'BOCC_Contacts', security: 'team', fields: [T('Role'), T('NTID', { indexed: true }), T('Stores'), T('Email'), T('Phone'), T('Coach'), B('Active')] },
    { title: 'BOCC_Raises', security: 'restricted', attachments: true, fields: [
      T('RequestKey', { indexed: true, unique: true }), T('NTID'), T('Store'), T('Position'), T('CurrentRate'), T('ProposedRate'), T('EffectiveDate'),
      T('Reason'), T('LastRaise'), N('Justification'), T('Status'), T('SubmittedBy'), T('SubmittedAt'), T('DecidedBy'), T('DecidedAt'), N('CeoComment'), N('History')] },
    { title: 'BOCC_Access', security: 'own', fields: [T('SessionId', { indexed: true, unique: true }), T('UserEmail', { indexed: true }), T('SignedInAt'), T('LastActive'), T('Device'), T('Browser')] },
    { title: 'BOCC_Activity', security: 'team', fields: [T('TaskKey', { indexed: true }), T('Actor'), T('At'), T('Action'), N('Detail')] }
  ];
  function noteFields() {
    return [T('RequestKey', { indexed: true, unique: true }), T('OwnerEmail', { indexed: true }), N('People'), T('Roles'), T('Stores'), T('ConvAt'), T('ConvDate', { indexed: true }),
      T('Method'), N('Discussion'), N('Outcome'), T('NextAction'), T('FollowUpDate'), B('WantsFollowUp'), T('LinkedTaskKey'), T('LinkedNodeId'),
      T('FollowUpTaskKey'), T('Visibility'), B('Archived'), T('BookAtTime'), T('EditedAt')];
  }
  var map = {}, i, j;
  for (i = 0; i < lists.length; i++) {
    map[lists[i].title] = lists[i];
    // SharePoint can't enforce unique values on lists where people only see their own items;
    // those keys stay indexed and the app de-duplicates them itself (see SP.createOnce).
    if (lists[i].security === 'own') { for (j = 0; j < lists[i].fields.length; j++) { if (lists[i].fields[j].unique) { lists[i].fields[j].unique = false; lists[i].fields[j].indexed = true; lists[i].appUnique = lists[i].fields[j].name; } } }
  }
  return { lists: lists, byTitle: map };
}());

var SP = (function () {
  var cfg, tokenFn, typeCache = {};
  function init(config, getToken) { cfg = config; tokenFn = getToken; }
  function base() { return cfg.spHost + cfg.sitePath; }
  function enc(s) { return encodeURIComponent(s).replace(/'/g, '%27%27'); }
  function listUrl(t) { return base() + "/_api/web/lists/getbytitle('" + t.replace(/'/g, "''") + "')"; }

  function xhr(method, url, body, headers) {
    return tokenFn().then(function (tok) {
      return new Promise(function (resolve, reject) {
        var x = new XMLHttpRequest();
        x.open(method === 'MERGE' ? 'POST' : method, url, true);
        x.setRequestHeader('Authorization', 'Bearer ' + tok);
        x.setRequestHeader('Accept', 'application/json;odata=minimalmetadata');
        if (method === 'MERGE') { x.setRequestHeader('X-HTTP-Method', 'MERGE'); }
        var h = headers || {}, k;
        for (k in h) { if (h.hasOwnProperty(k)) { x.setRequestHeader(k, h[k]); } }
        if (body !== undefined && body !== null && !h['Content-Type']) { x.setRequestHeader('Content-Type', 'application/json;odata=verbose'); }
        x.timeout = 30000;
        x.onload = function () {
          var data = null;
          if (x.responseText) { try { data = JSON.parse(x.responseText); } catch (e) { data = x.responseText; } }
          if (x.status >= 200 && x.status < 300) { resolve({ status: x.status, data: data, etag: x.getResponseHeader('ETag') }); }
          else {
            var msg = (data && data['odata.error'] && data['odata.error'].message && data['odata.error'].message.value) ||
              (data && data.error && data.error.message && (data.error.message.value || data.error.message)) || ('HTTP ' + x.status);
            var err = new Error(msg); err.status = x.status; err.data = data;
            err.duplicate = /duplicate values/i.test(msg);
            reject(err);
          }
        };
        x.onerror = function () { var e = new Error('Network error'); e.status = 0; e.network = true; reject(e); };
        x.ontimeout = function () { var e = new Error('Timed out'); e.status = 0; e.network = true; reject(e); };
        x.send(body === undefined || body === null ? null : (typeof body === 'string' ? body : JSON.stringify(body)));
      });
    });
  }

  function itemType(list) {
    if (typeCache[list]) { return Promise.resolve(typeCache[list]); }
    return xhr('GET', listUrl(list) + '?$select=ListItemEntityTypeFullName').then(function (r) {
      typeCache[list] = r.data.ListItemEntityTypeFullName; return typeCache[list];
    });
  }
  var SELECT = '$select=*,Editor/EMail,Editor/Title,Author/EMail,Author/Title&$expand=Editor,Author';
  function getAll(list, filter, top) {
    var url = listUrl(list) + '/items?' + SELECT + '&$top=' + (top || 2000) + (filter ? '&$filter=' + encodeURIComponent(filter) : '');
    var out = [];
    function page(u) {
      return xhr('GET', u).then(function (r) {
        out = out.concat(r.data.value || []);
        var next = r.data['odata.nextLink'];
        return next ? page(next) : out;
      });
    }
    return page(url);
  }
  function getItem(list, id) { return xhr('GET', listUrl(list) + '/items(' + id + ')?' + SELECT).then(function (r) { return r.data; }); }
  function create(list, fields) {
    return itemType(list).then(function (type) {
      var body = { __metadata: { type: type } }, k;
      for (k in fields) { if (fields.hasOwnProperty(k)) { body[k] = fields[k]; } }
      return xhr('POST', listUrl(list) + '/items', body);
    }).then(function (r) { return getItem(list, r.data.Id || r.data.ID); });
  }
  function update(list, id, fields, etag) {
    return itemType(list).then(function (type) {
      var body = { __metadata: { type: type } }, k;
      for (k in fields) { if (fields.hasOwnProperty(k)) { body[k] = fields[k]; } }
      return xhr('MERGE', listUrl(list) + '/items(' + id + ')', body, { 'IF-MATCH': etag || '*' });
    }).then(function () { return getItem(list, id); });
  }
  function findBy(list, field, value) {
    return getAll(list, field + " eq '" + String(value).replace(/'/g, "''") + "'", 5).then(function (rows) { return rows[0] || null; });
  }
  // Create once; if a unique key already exists, return the existing row (retry-safe).
  function remove(list, id) { return xhr('POST', listUrl(list) + '/items(' + id + ')', null, { 'X-HTTP-Method': 'DELETE', 'IF-MATCH': '*' }); }
  function createOnce(list, keyField, fields) {
    var def = BOCCSchema.byTitle[list];
    if (def && def.appUnique === keyField) {
      // App-enforced uniqueness: look first, create, then keep only the oldest row with this key.
      var key = fields[keyField];
      return findAll(list, keyField, key).then(function (rows) {
        if (rows.length) { rows[0].__existed = true; return rows[0]; }
        return create(list, fields).then(function () { return findAll(list, keyField, key); }).then(function (rows2) {
          var chain = Promise.resolve();
          rows2.slice(1).forEach(function (extra) { chain = chain.then(function () { return remove(list, extra.Id || extra.ID).catch(function () {}); }); });
          return chain.then(function () { return rows2[0]; });
        });
      });
    }
    return create(list, fields).catch(function (e) {
      if (e.duplicate) { return findBy(list, keyField, fields[keyField]).then(function (row) { if (row) { row.__existed = true; return row; } throw e; }); }
      throw e;
    });
  }
  function findAll(list, field, value) {
    return getAll(list, field + " eq '" + String(value).replace(/'/g, "''") + "'", 50).then(function (rows) {
      return rows.sort(function (a, b) { return (a.Id || a.ID) - (b.Id || b.ID); });
    });
  }
  function me() { return xhr('GET', base() + '/_api/web/currentuser?$select=Id,Email,Title,LoginName,IsSiteAdmin').then(function (r) { return r.data; }); }
  function canManage() {
    // Site owner = has ManagePermissions (PermissionKind 26 -> bit 25 of Low).
    return xhr('GET', base() + '/_api/web/effectivebasepermissions')
      .then(function (r) { var low = parseInt((r.data && r.data.Low) || 0, 10); return (low & 0x02000000) !== 0; })
      .catch(function () { return false; });
  }
  function canRead(list) {
    return xhr('GET', listUrl(list) + '/items?$top=1&$select=Id').then(function () { return true; }).catch(function () { return false; });
  }
  function attach(list, id, file) {
    return tokenFn().then(function (tok) {
      return new Promise(function (resolve, reject) {
        var fr = new FileReader();
        fr.onload = function () {
          var x = new XMLHttpRequest();
          x.open('POST', listUrl(list) + '/items(' + id + ")/AttachmentFiles/add(FileName='" + enc(file.name) + "')", true);
          x.setRequestHeader('Authorization', 'Bearer ' + tok);
          x.setRequestHeader('Accept', 'application/json;odata=minimalmetadata');
          x.onload = function () { if (x.status < 300) { resolve(); } else { reject(new Error('Attachment upload failed (' + x.status + ')')); } };
          x.onerror = function () { reject(new Error('Network error')); };
          x.send(fr.result);
        };
        fr.onerror = function () { reject(new Error('Could not read file')); };
        fr.readAsArrayBuffer(file);
      });
    });
  }
  function attachments(list, id) {
    return xhr('GET', listUrl(list) + '/items(' + id + ')/AttachmentFiles').then(function (r) { return r.data.value || []; });
  }

  // ---------- provisioning (admin only) ----------
  function fieldXml(f) {
    var a = ' Name="' + f.name + '" StaticName="' + f.name + '" DisplayName="' + f.name + '"';
    if (f.indexed || f.unique) { a += ' Indexed="TRUE"'; }
    if (f.unique) { a += ' EnforceUniqueValues="TRUE"'; }
    if (f.type === 'Text') { return '<Field Type="Text" MaxLength="255"' + a + ' />'; }
    if (f.type === 'Note') { return '<Field Type="Note" NumLines="6" RichText="FALSE" UnlimitedLengthInDocumentLibrary="TRUE"' + a + ' />'; }
    if (f.type === 'Number') { return '<Field Type="Number"' + a + ' />'; }
    if (f.type === 'Boolean') { return '<Field Type="Boolean"' + a + '><Default>0</Default></Field>'; }
    return '';
  }
  function siteExists() { return xhr('GET', base() + '/_api/web?$select=Title').then(function () { return true; }).catch(function (e) { if (e.status === 404) { return false; } throw e; }); }
  function createSite(title, ownerEmail) {
    return xhr('POST', cfg.spHost + '/_api/SPSiteManager/create', {
      request: { Title: title, Url: base(), Lcid: 1033, ShareByEmailEnabled: false, WebTemplate: 'STS#3', Owner: ownerEmail, Description: 'Back Office Command Center data' }
    }, { 'Content-Type': 'application/json;odata.metadata=none', 'Accept': 'application/json;odata.metadata=none' });
  }
  function provisionList(def, log) {
    var url = listUrl(def.title);
    return xhr('GET', url + '?$select=Id').then(function () { log('List exists: ' + def.title); return false; }, function (e) {
      if (e.status !== 404) { throw e; }
      log('Creating list ' + def.title);
      return xhr('POST', base() + '/_api/web/lists', { __metadata: { type: 'SP.List' }, BaseTemplate: 100, Title: def.title, AllowContentTypes: true, ContentTypesEnabled: false }).then(function () { return true; });
    }).then(function () {
      return xhr('GET', url + '/fields?$select=InternalName&$top=500');
    }).then(function (r) {
      var have = {}, i, chain = Promise.resolve();
      for (i = 0; i < r.data.value.length; i++) { have[r.data.value[i].InternalName] = 1; }
      def.fields.forEach(function (f) {
        if (have[f.name]) { return; }
        chain = chain.then(function () {
          log('  + ' + def.title + '.' + f.name);
          return xhr('POST', url + '/fields/createfieldasxml', { parameters: { __metadata: { type: 'SP.XmlSchemaFieldCreationInformation' }, SchemaXml: fieldXml(f), Options: 0 } });
        });
      });
      return chain;
    }).then(function () {
      var props = { __metadata: { type: 'SP.List' }, EnableAttachments: !!def.attachments, EnableVersioning: !!def.versioning };
      if (def.security === 'own') { props.ReadSecurity = 2; props.WriteSecurity = 2; }
      return xhr('MERGE', url, props, { 'IF-MATCH': '*' });
    });
  }
  function roleDefId(name) { return xhr('GET', base() + "/_api/web/roledefinitions/getbyname('" + name + "')?$select=Id").then(function (r) { return r.data.Id; }); }
  function ensureUser(email) {
    return xhr('POST', base() + '/_api/web/ensureuser', { logonName: 'i:0#.f|membership|' + email }).then(function (r) { return r.data; });
  }
  function restrictList(title, people, log) {
    // people: [{email, role:'Full Control'|'Contribute'}]
    var url = listUrl(title);
    log('Restricting ' + title + ' to ' + people.map(function (p) { return p.email; }).join(', '));
    return xhr('POST', url + '/breakroleinheritance(copyRoleAssignments=false,clearSubscopes=true)').then(function () {
      var chain = Promise.resolve();
      people.forEach(function (p) {
        chain = chain.then(function () {
          return Promise.all([ensureUser(p.email), roleDefId(p.role)]).then(function (res) {
            return xhr('POST', url + '/roleassignments/addroleassignment(principalid=' + res[0].Id + ',roledefid=' + res[1] + ')');
          });
        });
      });
      return chain;
    });
  }
  function addMember(email) {
    return xhr('POST', base() + '/_api/web/associatedmembergroup/users', { __metadata: { type: 'SP.User' }, LoginName: 'i:0#.f|membership|' + email });
  }

  return {
    init: init, xhr: xhr, getAll: getAll, getItem: getItem, create: create, update: update, findBy: findBy, createOnce: createOnce,
    remove: remove, me: me, canManage: canManage, canRead: canRead, attach: attach, attachments: attachments,
    siteExists: siteExists, createSite: createSite, provisionList: provisionList, restrictList: restrictList, addMember: addMember, ensureUser: ensureUser
  };
}());
