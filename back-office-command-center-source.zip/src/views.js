/* Views: everything the person sees. HTML strings, every user value passed through esc(). ES5. */
var ICON = {
  lock: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="4" y="11" width="16" height="10" rx="2"></rect><path d="M8 11V7a4 4 0 0 1 8 0v4"></path></svg>',
  today: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 11l3 3 8-8"></path><path d="M20 12v7a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h9"></path></svg>',
  week: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="17" rx="2"></rect><path d="M3 9h18M8 2v4M16 2v4"></path></svg>',
  team: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="9" cy="8" r="3.5"></circle><path d="M2.5 20c.8-3.5 3.4-5.5 6.5-5.5s5.7 2 6.5 5.5"></path><circle cx="17.5" cy="9" r="2.5"></circle><path d="M17 14.5c2.5.2 4 1.9 4.5 4.5"></path></svg>',
  log: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>',
  more: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h16"></path></svg>'
};
var STATUSES = ['Not Started', 'In Progress', 'Waiting', 'Completed', 'Cancelled'];
var ROLES = ['Coach', 'Store Manager', 'Rep', 'RDM', 'Executive', 'Employee', 'Other'];
var METHODS = ['Call', 'Teams', 'Email', 'In Person', 'Other'];
function opt(v, cur, label) { return '<option value="' + esc(v) + '"' + (v === cur ? ' selected' : '') + '>' + esc(label === undefined ? v : label) + '</option>'; }
function opts(list, cur) { return list.map(function (v) { return opt(v, cur); }).join(''); }
function chip(text, cls) { return '<span class="c ' + (cls || '') + '">' + esc(text) + '</span>'; }
function whoChip(p, removeAct) {
  return '<span class="who"><i>' + esc(initials(p.name)) + '</i>' + esc(p.name) + (p.role ? ' · ' + esc(p.role) : '') + (p.ntid ? ' · ' + esc(p.ntid) : '') +
    (removeAct ? '<button type="button" ' + removeAct + ' aria-label="Remove ' + esc(p.name) + '">×</button>' : '') + '</span>';
}

/* ================= shell ================= */
function render() {
  var root = byId('app');
  if (!S.ready) { return; }
  var scrollY = window.scrollY, dScroll = byId('dbody') ? byId('dbody').scrollTop : 0, mScroll = byId('mbody') ? byId('mbody').scrollTop : 0;
  var focus = document.activeElement && document.activeElement.id, selS, selE;
  try { selS = document.activeElement.selectionStart; selE = document.activeElement.selectionEnd; } catch (e) {}
  root.innerHTML = header() + '<div class="wrap">' + nav() + '<main class="main" id="main">' + mainView() + '</main></div>' + tabbar() + fab() +
    (S.drawer ? drawerHtml() : '') + (S.modal ? modalHtml() : '') + (S.toast ? toastHtml() : '');
  window.scrollTo(0, scrollY);
  if (byId('dbody')) { byId('dbody').scrollTop = dScroll; }
  if (byId('mbody')) { byId('mbody').scrollTop = mScroll; }
  if (focus && byId(focus)) { var el = byId(focus); el.focus(); try { if (selS !== undefined) { el.setSelectionRange(selS, selE); } } catch (e2) {} }
  paintSave();
  S.flash = {};
}
function header() {
  var dayNav = (S.view === 'today' || S.view === 'week') ?
    '<div style="display:flex;align-items:center;gap:4px"><button class="ib" data-act="prev" aria-label="Previous">‹</button>' +
    '<div style="font-weight:600;font-size:14px;padding:0 6px;white-space:nowrap">' + esc(S.view === 'week' ? 'Week of ' + R.fmtShort(S.weekStart) : R.fmtDate(S.day)) + '</div>' +
    '<button class="ib" data-act="next" aria-label="Next">›</button><button class="tb hidem" data-act="gotoday">Today</button></div>' : '';
  var viewing = (S.view === 'today' || S.view === 'week') ?
    '<label class="sr" for="viewing">Whose day</label><select id="viewing" class="tb hidem" data-act="viewing">' +
    activePeople().map(function (p) { return opt(p.Email, S.viewing, p.Email === S.myEmail ? 'My day' : p.Title); }).join('') + '</select>' : '';
  return '<header class="top"><button class="ib mobonly" data-act="navtoggle" aria-label="Menu">' + '≡' + '</button>' +
    '<a class="logo" href="#" data-act="gotoday"><span class="dia"></span>' + esc(CONFIG.appName) + '</a>' + dayNav + viewing +
    '<div class="search hidem"><label class="sr" for="search">Search</label><input id="search" placeholder="Search tasks, notes, people, stores…" value="' + esc(S.search) + '" data-act="search" autocomplete="off"></div>' +
    '<span id="saveState" class="save" role="status" aria-live="polite"></span>' +
    '<button class="btn w sm hidem" data-act="newtask">+ Task</button><button class="btn m sm hidem" data-act="newlog">Log Conversation</button></header>';
}
function navBtn(view, label, count, cls) {
  return '<button data-act="view" data-v="' + view + '" class="' + (S.view === view ? 'on' : '') + '">' + esc(label) + (count ? ' <span class="n ' + (cls || '') + '">' + esc(count) + '</span>' : '') + '</button>';
}
function nav() {
  var mine = tasksOf(S.myEmail);
  var unseen = mine.filter(function (t) { return t.AssignedByEmail && t.AssignedByEmail !== S.myEmail && R.isOpen(t) && !t.SeenByOwner; }).length;
  var sent = allTasks().filter(function (t) { return t.AssignedByEmail === S.myEmail && t.OwnerEmail !== S.myEmail && R.isOpen(t); }).length;
  var over = mine.filter(function (t) { return R.isOverdue(t, S.today); }).length;
  var todayOpen = dayItems(S.myEmail, S.today).filter(function (t) { return t.Kind !== 'Call' && t.Kind !== 'Block' && R.isOpen(t); }).length;
  var pendingRaises = S.raises.filter(function (r) { return r.Status === 'Submitted'; }).length;
  return '<nav class="nav' + (S.navOpen ? ' open' : '') + '" aria-label="Views">' +
    navBtn('today', 'Today', todayOpen) + navBtn('assigned', 'Assigned to me', unseen, 'mag') + navBtn('sent', 'Sent by me', sent) +
    navBtn('week', 'Week') + navBtn('upcoming', 'Upcoming') + navBtn('overdue', 'Overdue', over, 'red') + navBtn('completed', 'Completed') +
    '<div class="sep"></div>' + navBtn('team', 'Team') + (S.canRaises ? navBtn('raises', 'Raise Requests', pendingRaises, 'amb') : '') +
    navBtn('log', 'Conversation Log') + navBtn('settings', 'Settings') +
    (S.admin ? navBtn('access', 'Access Log', 'Only you') + navBtn('setup', 'Setup') : '') +
    '<div class="sep"></div><button data-act="signout">Sign out</button>' +
    '<div style="font-size:11px;color:var(--mute2);padding:4px 10px">' + esc(S.me ? S.me.Title : '') + '</div></nav>';
}
function tabbar() {
  function b(v, ic, l) { return '<button data-act="view" data-v="' + v + '" class="' + (S.view === v ? 'on' : '') + '">' + ic + esc(l) + '</button>'; }
  return '<nav class="tabbar" aria-label="Main">' + b('today', ICON.today, 'Today') + b('week', ICON.week, 'Week') + b('team', ICON.team, 'Team') + b('log', ICON.log, 'Log') +
    '<button data-act="navtoggle">' + ICON.more + 'More</button></nav>';
}
function fab() { return '<div class="fab"><button class="btn m" data-act="newlog">Log</button><button class="btn p" data-act="newtask">+ Task</button></div>'; }
function toastHtml() { return '<div class="toast" role="status">' + esc(S.toast.text) + (S.toast.undo ? '<button data-act="undo">Undo</button>' : '') + '</div>'; }
var toastTimer;
function toast(text, undo) {
  S.toast = { text: text, undo: undo || null }; clearTimeout(toastTimer);
  toastTimer = setTimeout(function () { S.toast = null; softRender(); }, undo ? 7000 : 4000); softRender();
}

function mainView() {
  if (S.search) { return searchView(); }
  switch (S.view) {
    case 'week': return weekView();
    case 'assigned': return listView('Assigned to me', tasksOf(S.myEmail).filter(function (t) { return t.AssignedByEmail && t.AssignedByEmail !== S.myEmail && R.isOpen(t); }), 'Nothing assigned to you right now.');
    case 'sent': return listView('Sent by me', allTasks().filter(function (t) { return t.AssignedByEmail === S.myEmail && t.OwnerEmail !== S.myEmail && !t.Archived; }), 'You haven\'t assigned anything yet.', true);
    case 'upcoming': return listView('Upcoming', tasksOf(S.myEmail).filter(function (t) { return R.isOpen(t) && R.effectiveDate(t, S.today, workOf(S.myEmail)) > S.today; }), 'Nothing scheduled ahead.', false, true);
    case 'overdue': return listView('Overdue', tasksOf(S.myEmail).filter(function (t) { return R.isOverdue(t, S.today); }), 'Nothing overdue.');
    case 'completed': return listView('Completed', tasksOf(S.myEmail).filter(function (t) { return t.Status === 'Completed'; }), 'Nothing completed in the last ' + CONFIG.taskWindowDays + ' days.', false, false, true);
    case 'team': return teamView();
    case 'log': return logView();
    case 'raises': return S.canRaises ? raisesView() : '';
    case 'settings': return settingsView();
    case 'access': return S.admin ? accessView() : '';
    case 'setup': return S.admin ? setupView() : '';
    default: return dayView(S.viewing || S.myEmail, S.day);
  }
}

/* ================= task rows ================= */
function taskRow(t, opts2) {
  opts2 = opts2 || {};
  var me = S.myEmail, ro = !canEditTask(t) || isPrivateFor(t), done = t.Status === 'Completed', w = workOf(t.OwnerEmail);
  var chips = [];
  if (opts2.showOwner && t.OwnerEmail !== me) { chips.push(chip('To ' + firstName(t.OwnerEmail))); }
  if (t.AssignedByEmail && t.AssignedByEmail !== t.OwnerEmail && t.OwnerEmail === me) {
    var sb = t.SendBack && t.SendBack.length && t.SendBack[t.SendBack.length - 1];
    if (sb && sb.by === t.AssignedByEmail) { chips.push(chip('Sent back by ' + firstName(sb.by), 'mag')); }
    else { chips.push(chip('From ' + firstName(t.AssignedByEmail), personBy(t.AssignedByEmail) && personBy(t.AssignedByEmail).JobTitle === 'CEO' ? 'plum' : '')); }
  }
  if (opts2.showOwner && t.SendBack && t.SendBack.length && t.SendBack[t.SendBack.length - 1].by === t.OwnerEmail) { chips.push(chip('Sent back', 'mag')); }
  if (R.isOverdue(t, S.today)) { chips.push(chip('Overdue · was due ' + R.fmtShort(t.DueDate), 'red')); }
  if (R.isCarried(t, S.today)) { chips.push(chip('Carried · from ' + R.fmtShort(t.PlannedDate), 'amb')); }
  if (t.Status === 'Waiting') { chips.push(chip('Waiting' + (t.WaitingOn ? ' on ' + t.WaitingOn : ''), 'blu')); }
  if (t.Status === 'In Progress' && !opts2.compact) { chips.push(chip('In Progress', 'blu')); }
  if (t.Status === 'Cancelled') { chips.push(chip('Cancelled', 'gry')); }
  if (opts2.showDate) { chips.push('<span class="meta">' + esc(R.fmtShort(R.effectiveDate(t, S.today, w))) + '</span>'); }
  if (opts2.showDone && t.CompletedAt) { chips.push('<span class="meta">Done ' + esc(fmtStamp(t.CompletedAt)) + '</span>'); }
  if (t.DueDate && !R.isOverdue(t, S.today) && R.isOpen(t)) { chips.push('<span class="meta">Due ' + esc(R.fmtShort(t.DueDate)) + '</span>'); }
  var cnt = R.countSubtasks(t.Subtasks); if (cnt.total) { chips.push('<span class="meta">' + cnt.done + '/' + cnt.total + '</span>'); }
  if (t.InviteSentAt) { chips.push('<span class="inv">Invite sent</span>'); }
  if (!t.SeenByOwner && t.AssignedByEmail && t.AssignedByEmail !== me && t.OwnerEmail === me && R.isOpen(t)) { chips.push(chip('New', 'mag')); }
  var priv = t.Visibility === 'Private';
  var flash = S.flash[t._id] ? ' flash' : '';
  var cb = (t.Kind === 'Call' || t.Kind === 'Block') ? '' :
    '<input type="checkbox" ' + (done ? 'checked ' : '') + (ro ? 'disabled ' : '') + 'data-act="toggle" data-id="' + esc(t._id) + '" aria-label="Complete ' + esc(titleOf(t)) + '">';
  return '<div class="r' + (done ? ' done' : '') + (ro && isPrivateFor(t) ? ' ro' : '') + flash + '" data-act="open" data-id="' + esc(t._id) + '"' + (S.flash[t._id] ? ' title="Updated by ' + esc(S.flash[t._id]) + '"' : '') + '>' + cb +
    '<span class="pdot ' + esc(t.Priority || 'Normal') + '" title="' + esc(t.Priority || 'Normal') + ' priority"></span>' +
    '<span class="ti">' + (priv ? '<span style="color:var(--gry-t);vertical-align:-2px">' + ICON.lock + '</span> ' : '') + esc(titleOf(t)) + '</span>' +
    '<span class="chips">' + chips.join('') + '</span>' + (S.flash[t._id] ? '<span class="meta">· ' + esc(S.flash[t._id]) + '</span>' : '') + '</div>';
}
function groupCards(tasks) {
  var groups = {}, order = [];
  tasks.forEach(function (t) { var g = t.Category || 'Other'; if (!groups[g]) { groups[g] = []; order.push(g); } groups[g].push(t); });
  var cats = prefsOf(tasks.length ? tasks[0].OwnerEmail : S.myEmail).Categories || [];
  order.sort(function (a, b) { var ia = cats.indexOf(a), ib = cats.indexOf(b); ia = ia < 0 ? 99 : ia; ib = ib < 0 ? 99 : ib; return ia - ib; });
  return order.map(function (g) {
    var list = groups[g].sort(sortTasks), d = list.filter(function (t) { return t.Status === 'Completed'; }).length;
    return { name: g, html: '<div class="card"><div class="gh">' + esc(g) + ' <span>' + d + ' / ' + list.length + '</span></div>' + list.map(function (t) { return taskRow(t, { compact: true }); }).join('') + '</div>', size: list.length };
  });
}
function sortTasks(a, b) {
  var pa = { High: 0, Normal: 1, Low: 2 }[a.Priority || 'Normal'], pb = { High: 0, Normal: 1, Low: 2 }[b.Priority || 'Normal'];
  if ((a.Status === 'Completed') !== (b.Status === 'Completed')) { return a.Status === 'Completed' ? 1 : -1; }
  return pa - pb || (a._id > b._id ? 1 : -1);
}

/* ================= day view ================= */
function dayView(email, day) {
  email = lc(email);
  var mine = email === S.myEmail, p = personBy(email), w = workOf(email), pr = prefsOf(email);
  var items = dayItems(email, day);
  var tasks = items.filter(function (t) { return t.Kind !== 'Call' && t.Kind !== 'Block'; });
  var sched = items.filter(function (t) { return t.Kind === 'Call' || t.Kind === 'Block'; });
  var assigned = tasks.filter(function (t) { return t.AssignedByEmail && t.AssignedByEmail !== email; });
  var rest = tasks.filter(function (t) { return assigned.indexOf(t) < 0; });
  var open = tasks.filter(R.isOpen).length, carried = tasks.filter(function (t) { return R.isCarried(t, S.today); }).length;
  var over = tasks.filter(function (t) { return R.isOverdue(t, S.today); }).length, done = tasks.filter(function (t) { return t.Status === 'Completed'; }).length;
  var theme = (pr.DayThemes || {})[R.dow(day)] || '';
  var off = !R.isWorkDay(w, day);
  var headerH = '<div style="display:flex;align-items:baseline;gap:10px;flex-wrap:wrap"><h1 class="pg">' + esc(mine ? (day === S.today ? 'Today · ' + R.fmtDate(day) : R.fmtDate(day)) : nameOf(email) + ' — ' + R.fmtDate(day)) + '</h1>' +
    (theme ? '<span class="theme">' + esc(theme) + '</span>' : '') + (off ? chip('Off day', 'gry') : '') + (!mine ? chip('Read-only view', 'gry') : '') + '</div>';
  var stats = '<div class="card stats"><div class="stat"><b style="color:var(--plum)">' + open + '</b> open</div><div class="stat"><b style="color:#8A5300">' + carried + '</b> carried</div>' +
    '<div class="stat"><b style="color:var(--red-t)">' + over + '</b> overdue</div><div class="stat"><b style="color:var(--grn-t)">' + done + '</b> done</div>' +
    (mine ? '<div class="quick"><label class="sr" for="quick">Quick add</label><input id="quick" placeholder="Quick add for ' + esc(R.fmtShort(day)) + ' — press Enter" data-act="quick"></div>' : '') + '</div>';
  var asg = assigned.length ? '<div class="card mg"><div class="gh mg">Assigned' + (mine ? ' to me' : '') + ' <span>' + assigned.filter(function (t) { return !t.SeenByOwner; }).length + ' new</span></div>' + assigned.sort(sortTasks).map(function (t) { return taskRow(t); }).join('') + '</div>' : '';
  var groups = groupCards(rest), big = [], small = [];
  groups.forEach(function (g) { (g.size > 4 ? big : small).push(g.html); });
  var dn = '';
  if (mine) {
    var key = S.myEmail + '|' + day, rec = S.dayNotes[key];
    dn = '<div class="card"><div class="gh">Notes / Follow-Up <span>Autosaves · ' + esc(R.fmtShort(day)) + '</span></div><label class="sr" for="daynote">Notes for ' + esc(R.fmtDate(day)) + '</label>' +
      '<textarea id="daynote" class="in" style="border:0;border-radius:0;min-height:76px" data-act="daynote" data-day="' + esc(day) + '" placeholder="Anything to remember or follow up on.">' + esc(rec ? rec.Text : '') + '</textarea>' +
      '<div style="padding:4px 12px 8px;display:flex;justify-content:flex-end"><button class="lnk" data-act="notetotask" data-day="' + esc(day) + '">Turn selected text into a task</button></div></div>';
  }
  var empty = !tasks.length ? '<div class="card"><div class="empty">' + (mine ? 'Nothing on this day yet. Use quick add, or set up your routine in Settings.' : 'Nothing on this day.') + '</div></div>' : '';
  return '<div class="cols"><section class="colL" aria-label="Tasks">' + headerH + stats + asg + big.join('') +
    (small.length ? '<div class="grid2">' + small.join('') + '</div>' : '') + empty + dn + '</section>' +
    '<aside class="colR" aria-label="Schedule">' + scheduleCards(sched, day, email) + loggedToday(day, email) + '</aside></div>';
}
function schedRow(t, day) {
  var now = R.nyNow(), past = false, st = '';
  if (t.Kind === 'Call') { st = R.callState(t, now); past = st !== 'Scheduled'; }
  var priv = t.Visibility === 'Private';
  var time = t.StartTime ? R.fmtTime(t.StartTime).replace(' AM', '').replace(' PM', '') : (t.AfterLabel || '—');
  var sub = [];
  if (priv && t.OwnerEmail === S.myEmail) { sub.push('Private · team sees “' + (t.PublicLabel || 'Private') + '”'); }
  else if (priv) { sub.push('Private'); }
  if (t.DurationMin) { sub.push(t.DurationMin + ' min'); }
  if (t.Kind === 'Block' && !t.StartTime && t.OwnerEmail === S.myEmail) { sub.push('start time not set'); }
  if (st === 'Not recorded') { sub.push('Not recorded'); } else if (st === 'Held') { sub.push('Held'); } else if (st === 'Missed') { sub.push('Missed'); }
  return '<div class="s' + (past ? ' past' : '') + (priv ? ' priv' : '') + '" data-act="open" data-id="' + esc(t._id) + '"><div class="t">' + esc(time) + '</div><div class="w"><b>' +
    (priv ? '<span style="vertical-align:-2px">' + ICON.lock + '</span> ' : '') + esc(titleOf(t)) + '</b><i>' + esc(sub.join(' · ')) + '</i></div></div>';
}
function scheduleCards(sched, day, email) {
  var calls = sched.filter(function (t) { return t.Kind === 'Call'; }).sort(byTime), blocks = sched.filter(function (t) { return t.Kind === 'Block'; }).sort(byTime);
  var now = R.nyNow(), html = '', placed = false;
  html += '<div class="card"><div class="gh dk">Calls <span>' + esc(R.fmtShort(day)) + '</span></div>';
  if (!calls.length) { html += '<div class="empty">No calls.</div>'; }
  calls.forEach(function (c) {
    var m = R.minutesOf(c.StartTime);
    if (day === S.today && !placed && m !== null && m > now.minutes) { html += '<div class="nowline"><span>' + esc(R.fmtTime(now.time)) + '</span></div>'; placed = true; }
    html += schedRow(c, day);
  });
  html += '</div><div class="card"><div class="gh">Work blocks</div>' + (blocks.length ? blocks.map(function (b) { return schedRow(b, day); }).join('') : '<div class="empty">No work blocks.</div>') + '</div>';
  return html;
}
function byTime(a, b) { var x = R.minutesOf(a.StartTime), y = R.minutesOf(b.StartTime); x = x === null ? 2000 : x; y = y === null ? 2000 : y; if (a.AfterLabel) { x = 1999; } if (b.AfterLabel) { y = 1999; } return x - y; }
function loggedToday(day, email) {
  if (email !== S.myEmail) { return ''; }
  var n = S.notes.concat(S.shared).filter(function (x) { return x.OwnerEmail === S.myEmail && x.ConvDate === day && !x.Archived; }).length;
  return '<div class="card" style="padding:8px 12px;display:flex;justify-content:space-between;align-items:center;font-size:13px"><span><b style="color:var(--plum)">' + n + '</b> conversation' + (n === 1 ? '' : 's') + ' logged</span><button class="lnk" data-act="view" data-v="log">Open log</button></div>';
}

/* ================= lists ================= */
function listView(title, tasks, emptyText, showOwner, showDate, showDone) {
  tasks = tasks.slice().sort(function (a, b) {
    if (showDone) { return (b.CompletedAt || '') > (a.CompletedAt || '') ? 1 : -1; }
    var da = R.effectiveDate(a, S.today, workOf(a.OwnerEmail)), db = R.effectiveDate(b, S.today, workOf(b.OwnerEmail));
    return da < db ? -1 : da > db ? 1 : sortTasks(a, b);
  });
  return '<div style="display:flex;flex-direction:column;gap:10px"><h1 class="pg">' + esc(title) + '</h1><div class="card">' +
    (tasks.length ? tasks.map(function (t) { return taskRow(t, { showOwner: showOwner, showDate: showDate || showOwner || !showDone, showDone: showDone }); }).join('') : '<div class="empty">' + esc(emptyText) + '</div>') + '</div></div>';
}
function searchView() {
  var q = lc(S.search);
  function hit() { for (var i = 0; i < arguments.length; i++) { if (lc(arguments[i]).indexOf(q) >= 0) { return true; } } return false; }
  var ts = allTasks().filter(function (t) { return !isPrivateFor(t) && hit(titleOf(t), t.Description, t.Category, t.Stores, JSON.stringify(t.WithPeople), JSON.stringify(t.Subtasks)); }).slice(0, 60);
  var ns = S.notes.concat(S.shared).filter(function (n) { return hit(JSON.stringify(n.People), n.Title, n.Discussion, n.Outcome, n.Stores, n.NextAction, n.Roles); }).slice(0, 40);
  var cs = S.contacts.filter(function (c) { return hit(c.Title, c.NTID, c.Stores, c.Role, c.Email); }).slice(0, 20);
  return '<div style="display:flex;flex-direction:column;gap:10px"><h1 class="pg">Search: “' + esc(S.search) + '”</h1>' +
    '<div class="card"><div class="gh">Tasks <span>' + ts.length + '</span></div>' + (ts.length ? ts.map(function (t) { return taskRow(t, { showOwner: true, showDate: true }); }).join('') : '<div class="empty">No tasks match.</div>') + '</div>' +
    '<div class="card"><div class="gh">Conversations <span>' + ns.length + '</span></div>' + (ns.length ? ns.map(noteRow).join('') : '<div class="empty">No conversations match.</div>') + '</div>' +
    '<div class="card"><div class="gh">Contacts <span>' + cs.length + '</span></div>' + (cs.length ? cs.map(function (c) { return '<div class="r ro">' + whoChip({ name: c.Title, role: c.Role, ntid: c.NTID }) + '<span class="meta">' + esc(c.Stores || '') + '</span></div>'; }).join('') : '<div class="empty">No contacts match.</div>') + '</div></div>';
}

/* ================= week ================= */
function weekView() {
  var email = S.viewing || S.myEmail, w = workOf(email), cols = '', i;
  for (i = 0; i < 7; i++) {
    var d = R.addDays(S.weekStart, i), items = dayItems(email, d), off = !R.isWorkDay(w, d);
    var theme = (prefsOf(email).DayThemes || {})[R.dow(d)] || '';
    var open = items.filter(function (t) { return t.Kind !== 'Call' && t.Kind !== 'Block' && R.isOpen(t); }).length;
    items.sort(function (a, b) { var ka = (a.Kind === 'Call' || a.Kind === 'Block') ? 0 : 1, kb = (b.Kind === 'Call' || b.Kind === 'Block') ? 0 : 1; return ka - kb || byTime(a, b); });
    cols += '<div class="wcol' + (off ? ' off' : '') + (d === S.today ? ' today' : '') + '"><div class="dh" data-act="gotoday" data-day="' + esc(d) + '" role="button" tabindex="0"><b>' + esc(R.fmtShort(d)) + (d === S.today ? ' · Today' : '') + '</b>' +
      '<div>' + esc(off ? 'Off day' : (theme || (open + ' open'))) + '</div></div>' +
      items.slice(0, 18).map(function (t) {
        var cls = t.Kind === 'Call' ? 'call' : t.Kind === 'Block' ? 'blk' : (R.isCarried(t, S.today) ? 'cf' : '');
        if (t.Visibility === 'Private') { cls = 'pv'; }
        if (t.Status === 'Completed') { cls += ' dn'; }
        var tt = t.StartTime ? R.fmtTime(t.StartTime) : (t.AfterLabel || (t.Kind === 'Task' ? (t.Category || 'Task') : 'Any time'));
        return '<div class="wit ' + cls + '" data-act="open" data-id="' + esc(t._id) + '"><span class="tt">' + esc(tt) + '</span>' + esc(titleOf(t)) + '</div>';
      }).join('') + (items.length > 18 ? '<div class="wit" data-act="gotoday" data-day="' + esc(d) + '">+' + (items.length - 18) + ' more</div>' : '') + '<div style="height:6px"></div></div>';
  }
  return '<div style="display:flex;flex-direction:column;gap:10px"><div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px"><h1 class="pg">' + esc(email === S.myEmail ? 'My week' : nameOf(email) + '’s week') + '</h1>' +
    '<span class="meta">Off days shaded · unfinished work rolls to the next work day</span></div><div class="scrollx"><div class="wkgrid">' + cols + '</div></div></div>';
}

/* ================= team ================= */
function teamView() {
  var people = activePeople(), sel = S.teamSel || (people[0] && people[0].Email);
  var roots = people.filter(function (p) { return !p.ReportsTo || !personBy(p.ReportsTo); });
  function node(p) {
    var open = tasksOf(p.Email).filter(function (t) { return R.isOpen(t) && R.showsOnDay(t, S.today, S.today, workOf(p.Email)); }).length;
    var late = tasksOf(p.Email).filter(function (t) { return R.isOverdue(t, S.today); }).length;
    var off = !R.isWorkDay(workOf(p.Email), S.today);
    var kids = people.filter(function (k) { return k.ReportsTo === p.Email; });
    return '<button class="node' + (sel === p.Email ? ' on' : '') + '" data-act="teamsel" data-email="' + esc(p.Email) + '"><div class="av"' + (p.Access === 'Executive' ? ' style="background:var(--plum);color:#fff"' : '') + '>' + esc(initials(p.Title)) + '</div>' +
      '<div class="nm"><b>' + esc(p.Title) + (p.Email === S.myEmail ? ' (me)' : '') + '</b><i>' + esc((p.JobTitle || '') + ' · ' + (p.Access || 'Member')) + '</i></div>' +
      (off ? chip('Off', 'gry') : late ? chip(late + ' late', 'red') : chip(String(open))) + '</button>' +
      (kids.length ? '<div class="br">' + kids.map(node).join('') + '</div>' : '');
  }
  var mgrs = isExec() ? people.filter(function (p) { return reportsOf(p.Email).length; }) : (S.me && reportsOf(S.myEmail).length ? [S.me] : []);
  var rollups = mgrs.map(function (m) {
    var team = reportsOf(m.Email, true), ts = [];
    team.forEach(function (e) { ts = ts.concat(tasksOf(e)); });
    var wk0 = R.sundayOf(S.today);
    var open = ts.filter(function (t) { return R.isOpen(t) && R.effectiveDate(t, S.today, workOf(t.OwnerEmail)) === S.today; }).length;
    var car = ts.filter(function (t) { return R.isCarried(t, S.today); }).length, ov = ts.filter(function (t) { return R.isOverdue(t, S.today); }).length;
    var sb = ts.filter(function (t) { return R.isOpen(t) && t.SendBack && t.SendBack.length && t.SendBack[t.SendBack.length - 1].by !== t.OwnerEmail; }).length;
    var wkAll = ts.filter(function (t) { return t.PlannedDate >= wk0 && t.PlannedDate <= S.today && t.Status !== 'Cancelled'; });
    var pct = wkAll.length ? Math.round(100 * wkAll.filter(function (t) { return t.Status === 'Completed'; }).length / wkAll.length) : 0;
    function st(n, l, c) { return '<div style="text-align:center;padding:8px 4px"><b style="display:block;font-size:18px;color:' + c + '">' + n + '</b><span class="meta">' + l + '</span></div>'; }
    return '<div class="card"><div class="gh">' + esc(m.Email === S.myEmail ? 'My team' : m.Title + '’s team') + ' <span>' + team.length + ' people</span></div><div style="display:grid;grid-template-columns:repeat(5,minmax(0,1fr))">' +
      st(open, 'open today', 'var(--plum)') + st(car, 'carried', '#8A5300') + st(ov, 'overdue', 'var(--red-t)') + st(sb, 'sent back', 'var(--mag-d)') + st(pct + '%', 'done this week', 'var(--grn-t)') + '</div></div>';
  }).join('');
  var selP = personBy(sel);
  var detail = selP ? '<div class="card" style="padding:10px 12px;display:flex;flex-wrap:wrap;gap:8px;justify-content:space-between;align-items:center"><div><div class="meta" style="font-weight:700">' +
    esc((selP.JobTitle || '') + (selP.ReportsTo ? ' · reports to ' + nameOf(selP.ReportsTo) : '')) + '</div><div style="font-size:18px;font-weight:700;color:var(--plum)">' + esc(selP.Title) + '</div></div>' +
    '<div style="display:flex;gap:6px;flex-wrap:wrap"><button class="btn sm" data-act="viewweek" data-email="' + esc(selP.Email) + '">Their week</button>' +
    (selP.Email !== S.myEmail ? '<button class="btn sm p" data-act="newtask" data-owner="' + esc(selP.Email) + '">Assign to ' + esc(firstName(selP.Email)) + '</button>' : '') + '</div></div>' +
    dayView(selP.Email, S.today) : '<div class="empty">Pick someone.</div>';
  return '<div class="cols"><section class="card" style="flex:1 1 260px;max-width:320px" aria-label="Org chart"><div class="gh">Team · ' + esc(R.fmtShort(S.today)) + ' <span>Org chart</span></div><div style="padding:6px">' +
    (roots.length ? roots.map(node).join('') : '<div class="empty">No team members yet. An admin adds people in Settings.</div>') + '</div></section>' +
    '<div class="colL">' + rollups + detail + '</div></div>';
}
