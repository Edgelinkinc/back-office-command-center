/* Core: config, auth, store, sync, autosave. ES5 only. */
var CONFIG = {
  appName: 'Back Office Command Center',
  tenantId: 'ebc8d7ee-ee3a-4821-b739-b0b060e7357f',
  clientId: '__CLIENT_ID__',
  spHost: 'https://evolutionwirelessinc.sharepoint.com',
  sitePath: '/sites/BackOfficeCC',
  pollMs: 10000,
  accessPingMs: 120000,
  taskWindowDays: 60,
  materializeBackDays: 14
};
var R = BOCCRules;

/* ---------------- helpers ---------------- */
function esc(s) {
  return String(s === undefined || s === null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
function lc(s) { return String(s || '').toLowerCase(); }
function nowIso() { return new Date().toISOString(); }
function initials(n) { var p = String(n || '?').split(/\s+/); return ((p[0] || '').charAt(0) + (p.length > 1 ? p[p.length - 1].charAt(0) : '')).toUpperCase(); }
function byId(id) { return document.getElementById(id); }
function jparse(s, d) { if (!s) { return d; } try { return JSON.parse(s); } catch (e) { return d; } }
function copy(o) { return JSON.parse(JSON.stringify(o)); }
function fmtStamp(iso) {
  if (!iso) { return ''; }
  var n = R.nyNow(new Date(iso)), today = R.nyNow().date;
  var t = R.fmtTime(n.time);
  if (n.date === today) { return t; }
  return R.fmtShort(n.date) + ' ' + t;
}
function debounce(fn, ms) { var h; return function () { var a = arguments, me = this; clearTimeout(h); h = setTimeout(function () { fn.apply(me, a); }, ms); }; }
function download(name, text, type) {
  var blob = new Blob([text], { type: type || 'text/plain' });
  var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name;
  document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.parentNode.removeChild(a); }, 500);
}
function csv(rows) {
  return rows.map(function (r) {
    return r.map(function (v) { v = v === undefined || v === null ? '' : String(v); return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; }).join(',');
  }).join('\r\n');
}
function parseCsv(text) {
  var rows = [], row = [], f = '', q = false, i, c;
  for (i = 0; i < text.length; i++) {
    c = text.charAt(i);
    if (q) { if (c === '"') { if (text.charAt(i + 1) === '"') { f += '"'; i++; } else { q = false; } } else { f += c; } }
    else if (c === '"') { q = true; }
    else if (c === ',') { row.push(f); f = ''; }
    else if (c === '\n' || c === '\r') { if (c === '\r' && text.charAt(i + 1) === '\n') { i++; } row.push(f); rows.push(row); row = []; f = ''; }
    else { f += c; }
  }
  if (f !== '' || row.length) { row.push(f); rows.push(row); }
  return rows.filter(function (r) { return r.join('').trim() !== ''; });
}
function device() {
  var u = navigator.userAgent;
  if (/iPad/.test(u) || (/Macintosh/.test(u) && navigator.maxTouchPoints > 1)) { return 'iPad'; }
  if (/iPhone/.test(u)) { return 'iPhone'; }
  if (/Android/.test(u)) { return /Mobile/.test(u) ? 'Android phone' : 'Android tablet'; }
  return 'PC';
}
function browser() {
  var u = navigator.userAgent;
  if (/Edg\//.test(u)) { return 'Edge'; } if (/CriOS|Chrome\//.test(u)) { return 'Chrome'; }
  if (/FxiOS|Firefox\//.test(u)) { return 'Firefox'; } if (/Safari\//.test(u)) { return 'Safari'; } return 'Other';
}

/* ---------------- auth ---------------- */
var AUTH = (function () {
  var app = null, account = null;
  var SCOPES = [CONFIG.spHost + '/AllSites.Manage'];
  function init() {
    app = new msal.PublicClientApplication({
      auth: { clientId: CONFIG.clientId, authority: 'https://login.microsoftonline.com/' + CONFIG.tenantId, redirectUri: location.origin + location.pathname },
      cache: { cacheLocation: 'localStorage', storeAuthStateInCookie: false }
    });
    return app.handleRedirectPromise().then(function (res) {
      if (res && res.account) { account = res.account; }
      if (!account) { var all = app.getAllAccounts(); if (all.length) { account = all[0]; } }
      if (account) { app.setActiveAccount(account); }
      return account;
    });
  }
  function login() { return app.loginRedirect({ scopes: SCOPES, prompt: 'select_account' }); }
  function logout() { return app.logoutRedirect({ account: account }); }
  function token(scopes) {
    scopes = scopes || SCOPES;
    return app.acquireTokenSilent({ scopes: scopes, account: account }).then(function (r) { return r.accessToken; }, function (e) {
      if (e && (e.name === 'InteractionRequiredAuthError' || /interaction_required|login_required|consent_required/.test(e.errorCode || ''))) {
        app.acquireTokenRedirect({ scopes: scopes, account: account }); return new Promise(function () {});
      }
      throw e;
    });
  }
  return { init: init, login: login, logout: logout, token: token, account: function () { return account; } };
}());

/* ---------------- store ---------------- */
var JSON_FIELDS = { Subtasks: [], WithPeople: [], SendBack: [], Comments: [], Items: [], Skips: [], People: [], TimeOff: [], DayThemes: {}, Categories: [], History: [] };
var NUM_FIELDS = { DurationMin: 1, SortOrder: 1 };
var BOOL_FIELDS = { Active: 1, Archived: 1, WantsFollowUp: 1, Private: 1, SeenByOwner: 1 };
function fromSP(row) {
  var o = { _id: row.Id || row.ID, _etag: row['odata.etag'], _editor: lc(row.Editor && row.Editor.EMail), _editorName: row.Editor && row.Editor.Title,
    _author: lc(row.Author && row.Author.EMail), _modified: row.Modified, _created: row.Created, Title: row.Title || '' };
  var k;
  for (k in row) {
    if (!row.hasOwnProperty(k) || /^(odata|__|Editor|Author|FileSystemObjectType|ServerRedirectedEmbed|ContentTypeId|ComplianceAssetId|OData__)/.test(k)) { continue; }
    if (k === 'Id' || k === 'ID' || k === 'Title' || k === 'Modified' || k === 'Created' || k === 'GUID' || k === 'EditorId' || k === 'AuthorId' || k === 'Attachments') { continue; }
    var v = row[k];
    if (JSON_FIELDS.hasOwnProperty(k)) { v = jparse(v, copy(JSON_FIELDS[k])); }
    else if (BOOL_FIELDS[k]) { v = !!v; }
    else if (v === null) { v = NUM_FIELDS[k] ? null : ''; }
    o[k] = v;
  }
  if (row.Attachments !== undefined) { o._attachments = row.Attachments; }
  ['OwnerEmail', 'AssignedByEmail', 'Email', 'ReportsTo', 'UserEmail', 'CompletedBy'].forEach(function (f) { if (o[f]) { o[f] = lc(o[f]); } });
  o._base = baseCopy(o);
  return o;
}
function baseCopy(o) { var b = {}, k; for (k in o) { if (o.hasOwnProperty(k) && k.charAt(0) !== '_') { b[k] = copy(o[k] === undefined ? null : o[k]); } } return b; }
function toSP(fields) {
  var out = {}, k;
  for (k in fields) {
    if (!fields.hasOwnProperty(k) || k.charAt(0) === '_' || k === 'Id' || k === 'Virtual') { continue; }
    var v = fields[k];
    if (JSON_FIELDS.hasOwnProperty(k)) { v = JSON.stringify(v || JSON_FIELDS[k]); }
    else if (NUM_FIELDS[k]) { v = (v === '' || v === null || v === undefined) ? null : +v; }
    else if (BOOL_FIELDS[k]) { v = !!v; }
    else if (v === undefined || v === null) { v = ''; }
    else { v = typeof v === 'string' ? v : String(v); }
    out[k] = v;
  }
  return out;
}

var S = {
  ready: false, me: null, myEmail: '', admin: false, canRaises: false,
  people: [], prefs: {}, tasks: {}, templates: [], privateMap: {}, notes: [], shared: [], dayNotes: {}, contacts: [], raises: [], access: [],
  today: R.nyNow().date, day: R.nyNow().date, weekStart: R.sundayOf(R.nyNow().date), view: 'today', viewing: '', teamSel: '',
  search: '', drawer: null, modal: null, toast: null, lastSync: null, saving: 0, saveErr: '', savedAt: '', flash: {}, navOpen: false
};

/* ---------------- people & prefs ---------------- */
function personBy(email) { email = lc(email); for (var i = 0; i < S.people.length; i++) { if (S.people[i].Email === email) { return S.people[i]; } } return null; }
function nameOf(email) { var p = personBy(email); return p ? p.Title : (email || ''); }
function firstName(email) { return String(nameOf(email)).split(' ')[0]; }
function prefsOf(email) { return S.prefs[lc(email)] || { WorkDays: R.DEFAULT_WORKDAYS, TimeOff: [], DayThemes: {}, Categories: [] }; }
function workOf(email) { var p = prefsOf(email); return { days: p.WorkDays || R.DEFAULT_WORKDAYS, off: p.TimeOff || [] }; }
function activePeople() { return S.people.filter(function (p) { return p.Active !== false; }).sort(function (a, b) { return (a.SortOrder || 99) - (b.SortOrder || 99) || (a.Title < b.Title ? -1 : 1); }); }
function reportsOf(email, deep) {
  email = lc(email); var out = [];
  activePeople().forEach(function (p) { if (p.ReportsTo === email) { out.push(p.Email); if (deep) { out = out.concat(reportsOf(p.Email, true)); } } });
  return out;
}
function isExec() { return S.me && S.me.Access === 'Executive'; }
function isMgr() { return S.me && (S.me.Access === 'Manager' || S.me.Access === 'Executive'); }
function canEditTask(t) {
  if (!t) { return false; }
  var me = S.myEmail;
  if (t.OwnerEmail === me || t.AssignedByEmail === me || isExec()) { return true; }
  return S.me && S.me.Access === 'Manager' && reportsOf(me, true).indexOf(t.OwnerEmail) >= 0;
}
function isPrivateFor(t) { return t.Visibility === 'Private' && t.OwnerEmail !== S.myEmail; }
function titleOf(t) {
  if (t.Visibility === 'Private') {
    if (t.OwnerEmail !== S.myEmail) { return t.PublicLabel || 'Private'; }
    var pv = S.privateMap['task|' + t.TaskKey] || (t.TemplateId && S.privateMap['tpl|' + t.TemplateId]);
    return (pv && pv.RealTitle) || t.Title;
  }
  return t.Title;
}
function myCategories() {
  var p = prefsOf(S.myEmail), list = (p.Categories || []).slice(), seen = {};
  list.forEach(function (c) { seen[c] = 1; });
  Object.keys(S.tasks).forEach(function (id) { var t = S.tasks[id]; if (t.OwnerEmail === S.myEmail && t.Category && !seen[t.Category]) { seen[t.Category] = 1; list.push(t.Category); } });
  return list;
}

/* ---------------- save state ---------------- */
function setSaving(delta, err) {
  S.saving = Math.max(0, S.saving + delta);
  if (err) { S.saveErr = err; }
  if (S.saving === 0 && !err) { S.saveErr = ''; S.savedAt = R.fmtTime(R.nyNow().time); }
  paintSave();
}
function paintSave() {
  var el = byId('saveState'); if (!el) { return; }
  if (S.saveErr) { el.className = 'save err'; el.textContent = 'Not saved — retrying'; el.title = S.saveErr; }
  else if (S.saving) { el.className = 'save ing'; el.textContent = 'Saving…'; el.title = ''; }
  else { el.className = 'save'; el.textContent = S.savedAt ? 'Saved ' + S.savedAt : 'All saved'; el.title = ''; }
}

/* Autosave queue: field changes per record, debounced, ETag-checked, merged on conflict. */
var Q = (function () {
  var pending = {}; // key -> {list, rec, timer, tries}
  function key(list, rec) { return list + ':' + rec._id; }
  function change(list, rec, fields, delay) {
    var k; for (k in fields) { if (fields.hasOwnProperty(k)) { rec[k] = fields[k]; } }
    var kk = key(list, rec), p = pending[kk];
    if (!p) { p = pending[kk] = { list: list, rec: rec, timer: null, tries: 0, fields: {} }; setSaving(1); }
    for (k in fields) { if (fields.hasOwnProperty(k)) { p.fields[k] = true; } }
    clearTimeout(p.timer);
    p.timer = setTimeout(function () { flush(kk); }, delay === undefined ? 700 : delay);
    try { localStorage.setItem('bocc-pending', JSON.stringify(snapshot())); } catch (e) {}
  }
  function snapshot() {
    var out = [], k; for (k in pending) { if (pending.hasOwnProperty(k)) { var p = pending[k], f = {}, x; for (x in p.fields) { if (p.fields.hasOwnProperty(x)) { f[x] = p.rec[x]; } } out.push({ list: p.list, id: p.rec._id, fields: f }); } }
    return out;
  }
  function flush(kk) {
    var p = pending[kk]; if (!p || p.busy) { return; }
    p.busy = true;
    var send = {}, f;
    for (f in p.fields) { if (p.fields.hasOwnProperty(f)) { send[f] = p.rec[f]; } }
    var sentFields = p.fields; p.fields = {};
    SP.update(p.list, p.rec._id, toSP(send), p.rec._etag).then(function (row) {
      var fresh = fromSP(row);
      applyFresh(p.rec, fresh, p.fields);
      p.busy = false;
      if (Object.keys(p.fields).length) { p.timer = setTimeout(function () { flush(kk); }, 300); return; }
      delete pending[kk]; S.saveErr = ''; setSaving(-1);
      try { localStorage.setItem('bocc-pending', JSON.stringify(snapshot())); } catch (e) {}
    }, function (e) {
      p.busy = false;
      var x; for (x in sentFields) { if (sentFields.hasOwnProperty(x)) { p.fields[x] = true; } }
      if (e.status === 412) {
        // someone else saved first: merge field by field
        SP.getItem(p.list, p.rec._id).then(function (row) {
          var theirs = fromSP(row), mine = baseCopy(p.rec);
          var m = R.mergeRecord(p.rec._base || {}, mine, baseCopy(theirs));
          var k2; for (k2 in m.merged) { if (m.merged.hasOwnProperty(k2)) { p.rec[k2] = m.merged[k2]; } }
          p.rec._etag = theirs._etag; p.rec._base = baseCopy(theirs);
          if (m.conflicts.length) {
            m.conflicts.forEach(function (c) { delete p.fields[c]; });
            p.rec._conflict = { fields: m.conflicts, by: theirs._editorName || theirs._editor, mine: mine };
            toast('Changed by ' + (theirs._editorName || 'someone else') + ' — your text is kept below for review.');
          }
          render();
          p.timer = setTimeout(function () { flush(kk); }, 100);
        }, function () { retry(kk, e); });
        return;
      }
      retry(kk, e);
    });
  }
  function retry(kk, e) {
    var p = pending[kk]; if (!p) { return; }
    p.tries++;
    setSaving(0, e.message || 'Save failed');
    p.timer = setTimeout(function () { flush(kk); }, Math.min(30000, 1500 * Math.pow(2, Math.min(p.tries, 5))));
  }
  function applyFresh(rec, fresh, stillDirty) {
    var k; for (k in fresh) { if (fresh.hasOwnProperty(k) && !(stillDirty && stillDirty[k])) { rec[k] = fresh[k]; } }
    rec._etag = fresh._etag; rec._base = fresh._base; rec._modified = fresh._modified; rec._editor = fresh._editor;
  }
  function isDirty(list, id) { return !!pending[list + ':' + id]; }
  function any() { return Object.keys(pending).length > 0; }
  function flushAll() { var k; for (k in pending) { if (pending.hasOwnProperty(k)) { clearTimeout(pending[k].timer); flush(k); } } }
  return { change: change, isDirty: isDirty, any: any, flushAll: flushAll };
}());
window.addEventListener('beforeunload', function (e) { if (Q.any()) { Q.flushAll(); e.preventDefault(); e.returnValue = ''; } });

function createRec(list, fields, keyField) {
  setSaving(1);
  var p = keyField ? SP.createOnce(list, keyField, toSP(fields)) : SP.create(list, toSP(fields));
  return p.then(function (row) { setSaving(-1); return fromSP(row); }, function (e) { setSaving(-1, e.message); setTimeout(function () { S.saveErr = ''; paintSave(); }, 4000); throw e; });
}
function logActivity(t, action, detail) {
  if (!t || !t.TaskKey) { return; }
  createRec('BOCC_Activity', { Title: action, TaskKey: t.TaskKey, Actor: S.myEmail, At: nowIso(), Action: action, Detail: detail || '' }).catch(function () {});
}

/* ---------------- loading & sync ---------------- */
function putTask(rec) {
  var old = S.tasks[rec._id];
  if (old && Q.isDirty('BOCC_Tasks', rec._id)) { return; }
  if (old && rec._editor && rec._editor !== S.myEmail && old._modified !== rec._modified) { S.flash[rec._id] = rec._editorName || rec._editor; }
  S.tasks[rec._id] = rec;
}
function upsertArr(arr, rec, keyName, list) {
  var i; for (i = 0; i < arr.length; i++) {
    if (arr[i]._id === rec._id) { if (list && Q.isDirty(list, rec._id)) { return; } arr[i] = rec; return; }
  }
  arr.push(rec);
}
function loadAll() {
  var today = S.today, since = R.addDays(today, -CONFIG.taskWindowDays);
  var openF = "Status eq 'Not Started' or Status eq 'In Progress' or Status eq 'Waiting'";
  return Promise.all([
    SP.getAll('BOCC_People'), SP.getAll('BOCC_Prefs'),
    SP.getAll('BOCC_Tasks', "PlannedDate ge '" + since + "'"), SP.getAll('BOCC_Tasks', openF),
    SP.getAll('BOCC_Templates'), SP.getAll('BOCC_Private'), SP.getAll('BOCC_Notes'), SP.getAll('BOCC_SharedNotes'),
    SP.getAll('BOCC_DayNotes', "Day ge '" + R.addDays(today, -45) + "'"), SP.getAll('BOCC_Contacts'),
    SP.canRead('BOCC_Raises')
  ]).then(function (r) {
    S.people = r[0].map(fromSP);
    S.prefs = {}; r[1].map(fromSP).forEach(function (p) { S.prefs[p.Email] = p; });
    S.tasks = {}; r[2].concat(r[3]).map(fromSP).forEach(function (t) { S.tasks[t._id] = t; });
    S.templates = r[4].map(fromSP);
    S.privateMap = {}; r[5].map(fromSP).forEach(function (p) { S.privateMap[p.Key] = p; });
    S.notes = r[6].map(fromSP); S.shared = r[7].map(fromSP);
    S.dayNotes = {}; r[8].map(fromSP).forEach(function (d) { S.dayNotes[d.Key] = d; });
    S.contacts = r[9].map(fromSP);
    S.canRaises = r[10];
    S.lastSync = new Date(Date.now() - 2000).toISOString();
    return S.canRaises ? SP.getAll('BOCC_Raises').then(function (x) { S.raises = x.map(fromSP); }) : null;
  });
}
var syncing = false;
function sync() {
  if (syncing || !S.ready || document.hidden) { return; }
  syncing = true;
  var since = new Date(new Date(S.lastSync).getTime() - 15000).toISOString();
  var f = "Modified ge datetime'" + since + "'";
  var started = new Date(Date.now() - 1000).toISOString();
  var lists = ['BOCC_Tasks', 'BOCC_Templates', 'BOCC_People', 'BOCC_Prefs', 'BOCC_Contacts', 'BOCC_SharedNotes', 'BOCC_Notes', 'BOCC_Private'];
  if (S.canRaises) { lists.push('BOCC_Raises'); }
  Promise.all(lists.map(function (l) { return SP.getAll(l, f, 500); })).then(function (res) {
    var changed = false;
    res.forEach(function (rows, i) {
      var list = lists[i];
      rows.map(fromSP).forEach(function (rec) {
        changed = true;
        if (list === 'BOCC_Tasks') { putTask(rec); }
        else if (list === 'BOCC_Templates') { upsertArr(S.templates, rec, '_id', list); }
        else if (list === 'BOCC_People') { upsertArr(S.people, rec, '_id', list); }
        else if (list === 'BOCC_Prefs') { if (!Q.isDirty(list, rec._id)) { S.prefs[rec.Email] = rec; } }
        else if (list === 'BOCC_Contacts') { upsertArr(S.contacts, rec, '_id', list); }
        else if (list === 'BOCC_SharedNotes') { upsertArr(S.shared, rec, '_id', list); }
        else if (list === 'BOCC_Notes') { upsertArr(S.notes, rec, '_id', list); }
        else if (list === 'BOCC_Private') { if (!Q.isDirty(list, rec._id)) { S.privateMap[rec.Key] = rec; } }
        else if (list === 'BOCC_Raises') { upsertArr(S.raises, rec, '_id', list); }
      });
    });
    S.lastSync = started; syncing = false;
    if (changed) { softRender(); }
  }, function () { syncing = false; });
}
// Avoid re-rendering under someone's cursor: defer while typing in a field.
var renderDeferred = false;
function softRender() {
  var a = document.activeElement;
  if (a && /INPUT|TEXTAREA|SELECT/.test(a.tagName) && !/^(search)$/.test(a.id)) { renderDeferred = true; return; }
  render();
}
document.addEventListener('focusout', function () { setTimeout(function () { if (renderDeferred) { var a = document.activeElement; if (!a || !/INPUT|TEXTAREA|SELECT/.test(a.tagName)) { renderDeferred = false; render(); } } }, 150); });

/* ---------------- recurrence materialization ---------------- */
function tasksOf(email) { var out = [], k; for (k in S.tasks) { if (S.tasks.hasOwnProperty(k) && S.tasks[k].OwnerEmail === lc(email)) { out.push(S.tasks[k]); } } return out; }
function allTasks() { var out = [], k; for (k in S.tasks) { if (S.tasks.hasOwnProperty(k)) { out.push(S.tasks[k]); } } return out; }
function templatesOf(email) { return S.templates.filter(function (t) { return t.OwnerEmail === lc(email) && t.Active !== false; }); }
var materializing = false;
function materialize() {
  if (materializing || !S.me) { return Promise.resolve(); }
  materializing = true;
  var tps = templatesForRules(S.myEmail).filter(function (t) { return (t.Kind || 'Task') === 'Task'; });
  var from = R.addDays(S.today, -CONFIG.materializeBackDays);
  var plan = R.planOccurrences(tps, S.myEmail, from, S.today, tasksOf(S.myEmail));
  var chain = Promise.resolve();
  plan.forEach(function (occ) {
    if (occ.PlannedDate < S.today && !R.isWorkDay(workOf(S.myEmail), occ.PlannedDate)) { /* still create: it carries */ }
    occ.Title = occ.Visibility === 'Private' ? (occ.PublicLabel || 'Private') : occ.Title;
    chain = chain.then(function () {
      return createRec('BOCC_Tasks', occ, 'TaskKey').then(function (rec) { S.tasks[rec._id] = rec; }, function () {});
    });
  });
  // reconcile follow-ups whose task creation didn't finish
  S.notes.concat(S.shared).forEach(function (n) {
    if (n.WantsFollowUp && !n.FollowUpTaskKey && n.OwnerEmail === S.myEmail && !n.Archived) {
      chain = chain.then(function () { return createFollowUp(n).catch(function () {}); });
    }
  });
  return chain.then(function () { materializing = false; render(); }, function () { materializing = false; });
}
function materializeVirtual(v) {
  // turn a preview occurrence into a saved record (on first edit / log / mark held)
  var fields = copy(v); delete fields.Id; delete fields.Virtual;
  if (fields.Visibility === 'Private') { fields.Title = fields.PublicLabel || 'Private'; }
  return createRec('BOCC_Tasks', fields, 'TaskKey').then(function (rec) { S.tasks[rec._id] = rec; return rec; });
}

/* items for a person's day: saved + previews from routines */
function dayItems(email, day) {
  email = lc(email);
  var w = workOf(email), saved = tasksOf(email).filter(function (t) { return R.showsOnDay(t, day, S.today, w); });
  var virt = R.virtualOccurrences(templatesForRules(email), email, day, tasksOf(email));
  if (day <= S.today && email === S.myEmail) { virt = virt.filter(function (v) { return v.Kind === 'Call' || v.Kind === 'Block'; }); }
  virt.forEach(function (v) { v._id = v.Id; });
  return saved.concat(virt);
}
function findTask(id) {
  if (S.tasks[id]) { return S.tasks[id]; }
  if (String(id).indexOf('v:') === 0) {
    var key = String(id).slice(2), parts = key.split('|'), email = parts[1], tpId = parts[2], d = parts[3];
    var tp = null; S.templates.forEach(function (t) { if (t.TemplateId === tpId) { tp = t; } });
    if (!tp) { return null; }
    var occ = R.occurrenceFromTemplate(asRuleTpl(tp), d, email); occ.Id = id; occ.Virtual = true; occ._id = id;
    return occ;
  }
  return null;
}
// Rules use .Id for template ids; saved templates carry it as TemplateId.
function asRuleTpl(t) {
  var o = copy(baseCopy(t)); o.Id = t.TemplateId;
  if (t.Private) { var pv = S.privateMap['tpl|' + t.TemplateId]; o.Title = (t.OwnerEmail === S.myEmail && pv && pv.RealTitle) || t.PublicLabel || 'Private'; }
  return o;
}
function templatesForRules(email) { return templatesOf(email).map(asRuleTpl); }
