# Back Office Command Center

Private, signed-in task, routine and conversation-log app for the EdgeLink back office team.
One ES5 HTML file on GitHub Pages; Microsoft sign-in (MSAL); all data in SharePoint lists.

## What's in here
| Path | What it is |
|---|---|
| `dist/index.html` | The app — the only file that gets published |
| `src/rules.js` | Business rules (dates, rollover, recurrence, merge) — no UI, fully tested |
| `src/sp.js` | SharePoint REST data layer, list schema and the Setup/provisioning code |
| `src/core.js` `views.js` `views2.js` `actions.js` `app.css` `shell.html` | App source |
| `build.js` | `node build.js <clientId>` → `dist/index.html` |
| `test/rules.test.js` | `node test/rules.test.js` — rule tests |
| `test/e2e.py` + `test/fake-sp.js` | `python3 test/e2e.py` — browser tests against a stand-in SharePoint |
| `seed/` | Cheryl's routine (JSON) and contacts (CSV) for import. **Never publish this folder** — it has employee data. |

## Setup (one time)
1. **SharePoint site**: `https://evolutionwirelessinc.sharepoint.com/sites/BackOfficeCC` (Team site, no group). Cheryl = owner.
2. **Azure app** "Back Office Command Center" — single tenant, platform **Single-page application**,
   redirect URI = the GitHub Pages URL of `index.html`. API permission: **SharePoint › Delegated › AllSites.Manage** → Grant admin consent.
3. `node build.js <Application (client) ID>` and publish `dist/index.html` to GitHub Pages.
4. Sign in as Cheryl → **Setup** → *Create / repair lists* (safe to re-run).
5. Settings → Team & access: add James, Joel, Ariel, Sasha (Reports to, Access, Raises role).
6. Setup → *Apply raise access* (locks Raise Requests to HR + CEO) → *Grant site access*.
7. Settings → My routines → Import JSON (`seed/cheryl-routine.json`); Contacts → Import CSV (`seed/contacts.csv`).

## How it works
- **Rollover**: one record per task. Unfinished work shows on your next *work day* (your own off days and time off are skipped). Original planned/due dates are kept; "Overdue" only when an explicit due date has passed.
- **Routines**: each occurrence has a unique key (`owner|routine|date`) enforced by a SharePoint unique index, so two devices can't duplicate it. Carried routines keep one open copy; payroll items are new each cycle and tied to that week's payroll cycle. Calls never roll — a missed call stays on its day as *Not recorded*.
- **Autosave**: every change saves to SharePoint (ETag-checked). Two people editing different fields merge; the same text edited twice shows a "changed by…" review instead of overwriting. "Saved" only shows after SharePoint confirms.
- **Live updates**: each open screen checks SharePoint for changes every 10 s and when you return to the tab.
- **Privacy**: private tasks/routines keep only their public label in the team list; real titles live in an owner-only list. Conversation notes are owner-only unless marked Shared. Raise Requests are locked to HR + CEO. Access Log is site-owner only.
- **Nothing is sent**: completing tasks, logging notes or marking "Teams invite sent" never emails or messages anyone.

## Backup
Settings → Backup: JSON (tasks with history, routines, conversations, day notes, contacts) or CSV (tasks / notes).
