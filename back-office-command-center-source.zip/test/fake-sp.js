/* Test double: fake MSAL + in-browser fake SharePoint REST (shared via localStorage so two tabs see one DB). */
(function () {
  var USER = JSON.parse(localStorage.getItem('FAKE_USER') || '{"username":"cheryl@edgelinkinc.com","name":"Cheryl Birchfield"}');
  var ADMINS = ['cheryl@edgelinkinc.com'];
  window.msal = { PublicClientApplication: function () {
    this.handleRedirectPromise = function () { return Promise.resolve(null); };
    this.getAllAccounts = function () { return localStorage.getItem('FAKE_SIGNEDOUT') ? [] : [USER]; };
    this.setActiveAccount = function () {};
    this.loginRedirect = function () { localStorage.removeItem('FAKE_SIGNEDOUT'); location.reload(); };
    this.logoutRedirect = function () { localStorage.setItem('FAKE_SIGNEDOUT', '1'); location.reload(); };
    this.acquireTokenSilent = function () { return Promise.resolve({ accessToken: 'fake' }); };
  } };
  function db() { return JSON.parse(localStorage.getItem('FAKE_DB') || '{"lists":{},"seq":1}'); }
  function save(d) { localStorage.setItem('FAKE_DB', JSON.stringify(d)); }
  window.FAKE = { db: db, save: save, failNext: 0, failCreates: 0 };
  var UNIQUE = { BOCC_People: 'Email', BOCC_Prefs: 'Email', BOCC_Tasks: 'TaskKey', BOCC_Templates: 'TemplateId', BOCC_SharedNotes: 'RequestKey', BOCC_Raises: 'RequestKey' };
  var OWN = { BOCC_Private: 1, BOCC_Notes: 1, BOCC_DayNotes: 1, BOCC_Drafts: 1, BOCC_Access: 1 };
  var RAISE_ALLOWED = ['cheryl@edgelinkinc.com', 'james@edgelinkinc.com'];
  function me() { return USER.username.toLowerCase(); }
  function visible(list, it) {
    if (list === 'BOCC_Raises' && RAISE_ALLOWED.indexOf(me()) < 0) { return false; }
    if (OWN[list] && ADMINS.indexOf(me()) < 0) { return it.Author.EMail === me(); }
    return true;
  }
  function evalFilter(f, it) {
    if (!f) { return true; }
    var ors = f.split(' or ');
    return ors.some(function (part) {
      var m = /^(\w+) (eq|ge|le|ne) (datetime)?'(.*)'$/.exec(part.trim());
      if (!m) { throw new Error('fake filter unsupported: ' + part); }
      var v = it[m[1]] === undefined || it[m[1]] === null ? '' : String(it[m[1]]), x = m[4].replace(/''/g, "'");
      if (m[3]) { v = new Date(v).getTime(); x = new Date(x).getTime(); }
      if (m[2] === 'eq') { return v === x; } if (m[2] === 'ne') { return v !== x; } if (m[2] === 'ge') { return v >= x; } return v <= x;
    });
  }
  function respond(x, status, body, headers) {
    x.status = status; x.responseText = body === undefined ? '' : JSON.stringify(body); x._h = headers || {};
    setTimeout(function () { x.onload && x.onload(); }, 5 + Math.random() * 15);
  }
  function FakeXHR() { this.headers = {}; }
  FakeXHR.prototype.open = function (m, u) { this.method = m; this.url = decodeURIComponent(u); };
  FakeXHR.prototype.setRequestHeader = function (k, v) { this.headers[k.toUpperCase()] = v; };
  FakeXHR.prototype.getResponseHeader = function (k) { return (this._h || {})[k] || null; };
  FakeXHR.prototype.send = function (body) {
    var x = this, u = x.url, d = db(), method = x.headers['X-HTTP-METHOD'] || x.method;
    if (FAKE.failNext > 0 && method !== 'GET') { FAKE.failNext--; setTimeout(function () { x.status = 0; x.onerror && x.onerror(); }, 5); return; }
    if (/\/_api\/web\?\$select=Title/.test(u)) { return respond(x, 200, { Title: 'BOCC' }); }
    if (/effectivebasepermissions/.test(u)) { return respond(x, 200, ADMINS.indexOf(me()) >= 0 ? { High: '2147483647', Low: '4294967295' } : { High: '432', Low: '1011030767' }); }
    var lm = /getbytitle\('([^']+)'\)(.*)$/.exec(u);
    if (!lm) { return respond(x, 404, { error: { message: { value: 'not found ' + u } } }); }
    var list = lm[1], rest = lm[2], L = d.lists[list];
    if (!L) { return respond(x, 404, { error: { message: { value: 'List does not exist' } } }); }
    if (list === 'BOCC_Raises' && RAISE_ALLOWED.indexOf(me()) < 0) { return respond(x, 403, { error: { message: { value: 'Access denied' } } }); }
    if (/^\?\$select=ListItemEntityTypeFullName/.test(rest)) { return respond(x, 200, { ListItemEntityTypeFullName: 'SP.Data.' + list + 'ListItem' }); }
    var im = /^\/items\((\d+)\)/.exec(rest);
    if (method === 'GET' && /^\/items\?/.test(rest)) {
      var fm = /\$filter=([^&]*)/.exec(rest), tm = /\$top=(\d+)/.exec(rest);
      var rows = L.items.filter(function (it) { return visible(list, it) && evalFilter(fm && fm[1], it); });
      return respond(x, 200, { value: rows.slice(0, tm ? +tm[1] : 5000) });
    }
    if (method === 'GET' && im) {
      var it = L.items.filter(function (i) { return i.Id === +im[1]; })[0];
      if (!/AttachmentFiles/.test(rest)) { return it ? respond(x, 200, it) : respond(x, 404, { error: { message: { value: 'Item does not exist' } } }); }
      return respond(x, 200, { value: [] });
    }
    if (method === 'POST' && /^\/items$/.test(rest)) {
      if (FAKE.failCreates > 0) { FAKE.failCreates--; return respond(x, 500, { error: { message: { value: 'Server busy' } } }); }
      var b = JSON.parse(body), key = UNIQUE[list];
      if (key && b[key] && L.items.some(function (i) { return i[key] === b[key]; })) { return respond(x, 500, { 'odata.error': { message: { value: 'The list item could not be added or updated because duplicate values were found in the following field(s) in the list: [' + key + '].' } } }); }
      delete b.__metadata;
      var now = new Date().toISOString(), id = d.seq++;
      b.Id = id; b.ID = id; b.Created = now; b.Modified = now; b['odata.etag'] = '"1"';
      b.Author = { EMail: me(), Title: USER.name }; b.Editor = { EMail: me(), Title: USER.name };
      L.items.push(b); save(d);
      return respond(x, 201, { Id: id });
    }
    if (method === 'MERGE' && im) {
      var cur = L.items.filter(function (i) { return i.Id === +im[1]; })[0];
      if (!cur) { return respond(x, 404, {}); }
      var etag = x.headers['IF-MATCH'];
      if (etag && etag !== '*' && etag !== cur['odata.etag']) { return respond(x, 412, { 'odata.error': { message: { value: 'The version of the item you are trying to update has changed.' } } }); }
      var bb = JSON.parse(body); delete bb.__metadata;
      var k2; for (k2 in bb) { if (bb.hasOwnProperty(k2)) { cur[k2] = bb[k2]; } }
      var n = parseInt(cur['odata.etag'].replace(/"/g, ''), 10) + 1;
      cur['odata.etag'] = '"' + n + '"'; cur.Modified = new Date().toISOString(); cur.Editor = { EMail: me(), Title: USER.name };
      save(d); return respond(x, 204);
    }
    if (method === 'DELETE' && im) { L.items = L.items.filter(function (i) { return i.Id !== +im[1]; }); save(d); return respond(x, 200); }
    return respond(x, 400, { error: { message: { value: 'fake: unsupported ' + method + ' ' + rest } } });
  };
  window.XMLHttpRequest = FakeXHR;
}());
