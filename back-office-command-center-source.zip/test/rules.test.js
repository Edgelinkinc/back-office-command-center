/* node test/rules.test.js */
var R = require('../src/rules.js');
var pass = 0, fail = 0, results = [];
function t(name, fn) {
  try { fn(); pass++; results.push('PASS  ' + name); }
  catch (e) { fail++; results.push('FAIL  ' + name + '\n      ' + e.message); }
}
function eq(a, b, m) { if (JSON.stringify(a) !== JSON.stringify(b)) { throw new Error((m || '') + ' expected ' + JSON.stringify(b) + ' got ' + JSON.stringify(a)); } }
function ok(v, m) { if (!v) { throw new Error(m || 'expected truthy'); } }

var WD = '0111110'; // Mon-Fri
function task(o) {
  var b = { Title: 'x', Kind: 'Task', Status: 'Not Started', PlannedDate: '2026-10-05', Rollover: 'Roll', OwnerEmail: 'cheryl@x.com' };
  for (var k in o) { b[k] = o[k]; } return b;
}

// --- dates & time zone (check 11) ---
t('NY business date just before midnight EDT', function () {
  eq(R.nyNow(new Date('2026-10-06T03:59:00Z')).date, '2026-10-05');
  eq(R.nyNow(new Date('2026-10-06T04:00:00Z')).date, '2026-10-06');
});
t('NY business date across DST end (Nov 1 2026)', function () {
  eq(R.nyNow(new Date('2026-11-02T04:59:00Z')).date, '2026-11-01'); // EST -5
  eq(R.nyNow(new Date('2026-11-02T05:00:00Z')).date, '2026-11-02');
});
t('NY business date across DST start (Mar 8 2026)', function () {
  eq(R.nyNow(new Date('2026-03-09T03:59:00Z')).date, '2026-03-08');
  eq(R.nyNow(new Date('2026-03-09T04:00:00Z')).date, '2026-03-09');
});
t('addDays is date-only (no UTC midnight drift across DST)', function () {
  eq(R.addDays('2026-11-01', 1), '2026-11-02');
  eq(R.addDays('2026-03-07', 2), '2026-03-09');
});
t('9:45 call stays 9:45 local on both sides of DST', function () {
  var call = task({ Kind: 'Call', StartTime: '09:45', PlannedDate: '2026-10-30' });
  eq(R.callState(call, { date: '2026-10-30', minutes: 9 * 60 + 40 }), 'Scheduled');
  call.PlannedDate = '2026-11-02';
  eq(R.callState(call, { date: '2026-11-02', minutes: 9 * 60 + 50 }), 'Not recorded');
});

// --- rollover (checks 2,3,4,7) ---
t('future task does not show on Today before its date', function () {
  var x = task({ PlannedDate: '2026-10-08' });
  ok(!R.showsOnDay(x, '2026-10-05', '2026-10-05', WD));
  ok(R.showsOnDay(x, '2026-10-08', '2026-10-05', WD));
});
t('unfinished Monday task shows Tuesday on same record, carried', function () {
  var x = task({ PlannedDate: '2026-10-05', Subtasks: [{ id: 'a', title: 's', done: true }] });
  eq(R.effectiveDate(x, '2026-10-06', WD), '2026-10-06');
  ok(R.isCarried(x, '2026-10-06'));
  eq(x.PlannedDate, '2026-10-05', 'original planned date preserved');
  eq(x.Subtasks.length, 1);
});
t('Friday work appears Monday (Sat/Sun off)', function () {
  var x = task({ PlannedDate: '2026-10-09' });
  eq(R.effectiveDate(x, '2026-10-10', WD), '2026-10-12');
  ok(!R.showsOnDay(x, '2026-10-10', '2026-10-10', WD));
  ok(R.showsOnDay(x, '2026-10-12', '2026-10-10', WD));
});
t('Friday work appears Saturday for a Tue-Sat worker', function () {
  var x = task({ PlannedDate: '2026-10-09' });
  eq(R.effectiveDate(x, '2026-10-10', '0011111'), '2026-10-10');
});
t('time off days are skipped by rollover', function () {
  var x = task({ PlannedDate: '2026-10-09' });
  eq(R.effectiveDate(x, '2026-10-10', { days: WD, off: ['2026-10-12'] }), '2026-10-13');
});
t('rollover after several days away lands on today once', function () {
  var x = task({ PlannedDate: '2026-09-28' });
  eq(R.effectiveDate(x, '2026-10-05', WD), '2026-10-05');
});
t('original due date stays; overdue only with explicit due date', function () {
  var a = task({ PlannedDate: '2026-10-02', DueDate: '2026-10-02' });
  var b = task({ PlannedDate: '2026-10-02' });
  ok(R.isOverdue(a, '2026-10-05')); eq(a.DueDate, '2026-10-02');
  ok(!R.isOverdue(b, '2026-10-05')); ok(R.isCarried(b, '2026-10-05'));
});
t('completed / cancelled tasks do not roll', function () {
  var a = task({ PlannedDate: '2026-10-02', Status: 'Completed', CompletedAt: '2026-10-02T18:00:00Z' });
  var c = task({ PlannedDate: '2026-10-02', Status: 'Cancelled' });
  ok(!R.showsOnDay(a, '2026-10-05', '2026-10-05', WD));
  ok(!R.showsOnDay(c, '2026-10-05', '2026-10-05', WD));
});
t('rescheduled task shows on new date only', function () {
  var x = task({ PlannedDate: '2026-10-09', OriginalPlannedDate: '2026-10-02' });
  ok(!R.showsOnDay(x, '2026-10-05', '2026-10-05', WD));
  ok(R.showsOnDay(x, '2026-10-09', '2026-10-05', WD));
});
t('Waiting keeps status and stays off Today until follow-up date', function () {
  var x = task({ Status: 'Waiting', WaitingOn: 'Coach', PlannedDate: '2026-10-01', FollowUpDate: '2026-10-07' });
  ok(!R.showsOnDay(x, '2026-10-05', '2026-10-05', WD));
  ok(R.showsOnDay(x, '2026-10-07', '2026-10-05', WD));
  eq(x.Status, 'Waiting');
  eq(R.effectiveDate(x, '2026-10-08', WD), '2026-10-08');
});

// --- meetings (checks 8,9) ---
t('missed call stays on its date as Not recorded and never rolls', function () {
  var c = task({ Kind: 'Call', Rollover: 'Stay', StartTime: '09:45', PlannedDate: '2026-10-02' });
  eq(R.callState(c, { date: '2026-10-05', minutes: 600 }), 'Not recorded');
  ok(!R.showsOnDay(c, '2026-10-05', '2026-10-05', WD));
  ok(R.showsOnDay(c, '2026-10-02', '2026-10-05', WD));
});
var tpl = [
  { Id: 'TPL-AM', OwnerEmail: 'cheryl@x.com', Title: 'Morning call', Kind: 'Call', Days: '0111110', StartTime: '09:45', StartDate: '2026-10-01' },
  { Id: 'TPL-COACH', OwnerEmail: 'cheryl@x.com', Title: 'Coach call', Kind: 'Call', Days: '0111110', StartTime: '14:00', StartDate: '2026-10-01' },
  { Id: 'TPL-AMANDA', OwnerEmail: 'cheryl@x.com', Title: 'Amanda — RDM', Kind: 'Call', Days: '0010000', StartTime: '13:30', StartDate: '2026-10-01' },
  { Id: 'TPL-NHO', OwnerEmail: 'cheryl@x.com', Title: 'New Hire Orientation', Kind: 'Call', Days: '0001000', StartTime: '12:00', StartDate: '2026-10-01' },
  { Id: 'TPL-EMAIL', OwnerEmail: 'cheryl@x.com', Title: 'Review emails', Kind: 'Block', Days: '0111110', DurationMin: 30, StartDate: '2026-10-01' },
  { Id: 'TPL-DASH', OwnerEmail: 'cheryl@x.com', Title: 'Dashboards', Kind: 'Block', Days: '0111110', StartTime: '17:00', AfterLabel: 'After 5 PM call', StartDate: '2026-10-01' },
  { Id: 'TPL-HRF', OwnerEmail: 'cheryl@x.com', Title: 'HR Follow-Up', Kind: 'Task', Days: '0100000', Rollover: 'Carry', StartDate: '2026-10-01',
    Items: [{ title: 'Review outstanding HR requests' }, { title: 'Follow up on employee documentation', required: true }] },
  { Id: 'TPL-PAYREV', OwnerEmail: 'cheryl@x.com', Title: 'Payroll Review', Kind: 'Task', Days: '0010000', Rollover: 'Independent', Cycle: 'payroll', StartDate: '2026-10-01' },
  { Id: 'TPL-PAYSUB', OwnerEmail: 'cheryl@x.com', Title: 'Process & submit payroll', Kind: 'Task', Days: '0000100', Rollover: 'Independent', Cycle: 'payroll', StartDate: '2026-10-01' }
];
t('Amanda Tue 1:30, orientation Wed noon, coach calls weekdays 2 PM', function () {
  var week = R.planOccurrences(tpl, 'cheryl@x.com', '2026-10-04', '2026-10-10', []);
  function on(title) { return week.filter(function (x) { return x.Title === title; }).map(function (x) { return x.PlannedDate + ' ' + x.StartTime; }); }
  eq(on('Amanda — RDM'), ['2026-10-06 13:30']);
  eq(on('New Hire Orientation'), ['2026-10-07 12:00']);
  eq(on('Coach call').length, 5);
  ok(on('Coach call').every(function (s) { return /14:00$/.test(s); }));
});
t('email block is 30 min; unknown durations stay blank', function () {
  var d = R.planOccurrences(tpl, 'cheryl@x.com', '2026-10-05', '2026-10-05', []);
  var em = d.filter(function (x) { return x.Title === 'Review emails'; })[0];
  var call = d.filter(function (x) { return x.Title === 'Morning call'; })[0];
  eq(em.DurationMin, 30); eq(em.StartTime, '');
  eq(call.DurationMin, null);
  eq(em.Rollover, 'Stay'); eq(call.Rollover, 'Stay');
});

// --- recurrence de-dup (checks 5,10,12) ---
t('repeated reconciliation creates no duplicates', function () {
  var first = R.planOccurrences(tpl, 'cheryl@x.com', '2026-10-05', '2026-10-05', []);
  var again = R.planOccurrences(tpl, 'cheryl@x.com', '2026-10-05', '2026-10-05', first);
  eq(again.length, 0);
  var keys = first.map(function (x) { return x.TaskKey; });
  eq(keys.length, Object.keys(keys.reduce(function (m, k) { m[k] = 1; return m; }, {})).length, 'unique keys');
});
t('two devices produce identical keys (DB unique index blocks the second)', function () {
  var a = R.planOccurrences(tpl, 'cheryl@x.com', '2026-10-05', '2026-10-05', []);
  var b = R.planOccurrences(tpl, 'CHERYL@x.com', '2026-10-05', '2026-10-05', []);
  eq(a.map(function (x) { return x.TaskKey; }), b.map(function (x) { return x.TaskKey; }));
});
t('carry template: open occurrence suppresses next week duplicate', function () {
  var w1 = R.planOccurrences(tpl, 'cheryl@x.com', '2026-10-05', '2026-10-05', []);
  var hrf = w1.filter(function (x) { return x.TemplateId === 'TPL-HRF'; });
  eq(hrf.length, 1);
  var w2 = R.planOccurrences(tpl, 'cheryl@x.com', '2026-10-12', '2026-10-12', w1);
  eq(w2.filter(function (x) { return x.TemplateId === 'TPL-HRF'; }).length, 0);
  hrf[0].Status = 'Completed';
  var w3 = R.planOccurrences(tpl, 'cheryl@x.com', '2026-10-12', '2026-10-12', w1);
  eq(w3.filter(function (x) { return x.TemplateId === 'TPL-HRF'; }).length, 1);
});
t('first run after time away creates only the latest carried occurrence', function () {
  var x = R.planOccurrences(tpl, 'cheryl@x.com', '2026-09-21', '2026-10-07', []);
  eq(x.filter(function (o) { return o.TemplateId === 'TPL-HRF'; }).map(function (o) { return o.PlannedDate; }), ['2026-10-05']);
});
t('completed latest occurrence does not resurrect an older one', function () {
  var done = R.planOccurrences(tpl, 'cheryl@x.com', '2026-10-05', '2026-10-05', []);
  done.forEach(function (o) { o.Status = 'Completed'; });
  var again = R.planOccurrences(tpl, 'cheryl@x.com', '2026-09-21', '2026-10-06', done);
  eq(again.filter(function (o) { return o.TemplateId === 'TPL-HRF'; }).length, 0);
});
t('completing one occurrence does not complete others', function () {
  var w = R.planOccurrences(tpl, 'cheryl@x.com', '2026-10-05', '2026-10-09', []);
  var calls = w.filter(function (x) { return x.TemplateId === 'TPL-AM'; });
  calls[0].Status = 'Completed';
  eq(calls.filter(function (x) { return x.Status === 'Completed'; }).length, 1);
});
t('payroll cycles stay distinct week to week; prep and submit share a cycle', function () {
  var w1 = R.planOccurrences(tpl, 'cheryl@x.com', '2026-10-05', '2026-10-09', []);
  var w2 = R.planOccurrences(tpl, 'cheryl@x.com', '2026-10-12', '2026-10-16', w1);
  var rev1 = w1.filter(function (x) { return x.TemplateId === 'TPL-PAYREV'; })[0];
  var sub1 = w1.filter(function (x) { return x.TemplateId === 'TPL-PAYSUB'; })[0];
  var rev2 = w2.filter(function (x) { return x.TemplateId === 'TPL-PAYREV'; })[0];
  eq(rev1.CycleId, 'PAY-2026-10-05'); eq(sub1.CycleId, 'PAY-2026-10-05');
  eq(rev2.CycleId, 'PAY-2026-10-12');
  ok(R.isOpen(rev1) && rev2, 'last week open does not suppress this week');
});
t('this-and-future edit keeps completed history and no duplicate future keys', function () {
  var w1 = R.planOccurrences(tpl, 'cheryl@x.com', '2026-10-05', '2026-10-05', []);
  w1.forEach(function (x) { x.Status = 'Completed'; });
  var sp = R.splitTemplate(tpl[0], '2026-10-06', { StartTime: '10:00' }, 'TPL-AM2');
  var t2 = tpl.slice(1).concat([sp.oldTemplate, sp.newTemplate]);
  var later = R.planOccurrences(t2, 'cheryl@x.com', '2026-10-05', '2026-10-07', w1);
  var am = later.filter(function (x) { return /Morning/.test(x.Title); });
  eq(am.map(function (x) { return x.PlannedDate + ' ' + x.StartTime; }), ['2026-10-06 10:00', '2026-10-07 10:00']);
  eq(w1.filter(function (x) { return x.TemplateId === 'TPL-AM'; })[0].StartTime, '09:45', 'history untouched');
});
t('only the owner gets occurrences from their templates', function () {
  eq(R.planOccurrences(tpl, 'ariel@x.com', '2026-10-05', '2026-10-05', []).length, 0);
});

// --- subtasks (check 13) ---
t('required subtasks block completion unless overridden', function () {
  var x = task({ Subtasks: [{ id: 'a', title: 'A', required: true, done: false, children: [{ id: 'a1', title: 'A1', required: true, done: false }] }, { id: 'b', title: 'B', done: false }] });
  var c = R.canComplete(x);
  ok(!c.ok); eq(c.openRequired, ['A', 'A1']);
  R.completeAll(x.Subtasks, 'cheryl', '2026-10-05T15:00:00Z');
  ok(R.canComplete(x).ok);
  eq(R.countSubtasks(x.Subtasks), { total: 3, done: 3 });
});

// --- merge / concurrency (check 14) ---
t('different fields from two tabs merge without loss', function () {
  var base = { Status: 'Not Started', DueDate: '', Description: 'a' };
  var mine = { Status: 'In Progress', DueDate: '', Description: 'a' };
  var theirs = { Status: 'Not Started', DueDate: '2026-10-09', Description: 'a' };
  var m = R.mergeRecord(base, mine, theirs);
  eq(m.merged.Status, 'In Progress'); eq(m.merged.DueDate, '2026-10-09'); eq(m.conflicts, []);
});
t('same note edited in two tabs is a conflict, not a silent overwrite', function () {
  var m = R.mergeRecord({ Description: 'a' }, { Description: 'mine' }, { Description: 'theirs' });
  eq(m.conflicts, ['Description']); eq(m.merged.Description, 'theirs');
});
t('subtask edits from both sides merge by id', function () {
  var base = { Subtasks: [{ id: 'a', title: 'A', done: false }, { id: 'b', title: 'B', done: false }] };
  var mine = { Subtasks: [{ id: 'a', title: 'A', done: true }, { id: 'b', title: 'B', done: false }, { id: 'c', title: 'C', done: false }] };
  var theirs = { Subtasks: [{ id: 'a', title: 'A', done: false }, { id: 'b', title: 'B2', done: false }] };
  var m = R.mergeRecord(base, mine, theirs).merged.Subtasks;
  eq(m.map(function (n) { return n.id + ':' + n.title + ':' + n.done; }), ['a:A:true', 'b:B2:false', 'c:C:false']);
});

// --- misc ---
t('raise change $ and %', function () { eq(R.raiseChange('16.00', '17.00'), { amount: 1, pct: 6.3 }); });

console.log(results.join('\n'));
console.log('\n' + pass + ' passed, ' + fail + ' failed');
process.exit(fail ? 1 : 0);
