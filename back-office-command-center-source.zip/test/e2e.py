"""Browser smoke/acceptance tests against a fake SharePoint. python3 test/e2e.py"""
import json, os, re, sys, time
from playwright.sync_api import sync_playwright

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
html = open(os.path.join(ROOT, 'dist', 'index.html')).read()
fake = open(os.path.join(ROOT, 'test', 'fake-sp.js')).read()
html = re.sub(r'<script src="https://alcdn[^>]*></script>', '<script>' + fake.replace('\\', '\\\\') + '</script>', html)
html = html.replace('__CLIENT_ID__', 'test-client')
harness = os.path.join(ROOT, 'test', 'harness.html')
open(harness, 'w').write(html)
URL = 'file://' + harness

LISTS = ['BOCC_People', 'BOCC_Prefs', 'BOCC_Tasks', 'BOCC_Private', 'BOCC_Templates', 'BOCC_Notes', 'BOCC_SharedNotes', 'BOCC_DayNotes',
         'BOCC_Drafts', 'BOCC_Contacts', 'BOCC_Raises', 'BOCC_Access', 'BOCC_Activity']
seq = [1]
def item(o, by='cheryl@edgelinkinc.com'):
    i = seq[0]; seq[0] += 1
    o.update({'Id': i, 'ID': i, 'Created': '2026-10-01T12:00:00Z', 'Modified': '2026-10-01T12:00:00Z', 'odata.etag': '"1"',
              'Author': {'EMail': by, 'Title': by}, 'Editor': {'EMail': by, 'Title': by}})
    return o
db = {'lists': {l: {'items': []} for l in LISTS}}
P = db['lists']['BOCC_People']['items']
for n, e, j, r, a, x, s in [('James Jackson', 'james@edgelinkinc.com', 'CEO', '', 'Executive', 'Approve', 1),
                            ('Cheryl Birchfield', 'cheryl@edgelinkinc.com', 'HR', 'james@edgelinkinc.com', 'Executive', 'Submit', 2),
                            ('Joel Montero', 'joel@edgelinkinc.com', 'Operations Director', 'james@edgelinkinc.com', 'Manager', '', 3),
                            ('Ariel Cabrerra', 'ariel@edgelinkinc.com', 'Operations', 'joel@edgelinkinc.com', 'Member', '', 4),
                            ('Sasha Melendez-Wright', 'sasha@edgelinkinc.com', 'Operations', 'joel@edgelinkinc.com', 'Member', '', 5)]:
    P.append(item({'Title': n, 'Email': e, 'JobTitle': j, 'ReportsTo': r, 'Access': a, 'Raises': x, 'Active': True, 'SortOrder': s}))
db['lists']['BOCC_Prefs']['items'].append(item({'Title': 'c', 'Email': 'cheryl@edgelinkinc.com', 'WorkDays': '0111110', 'TimeOff': '[]',
    'DayThemes': json.dumps({'1': 'HR + Recruiting', '2': 'Payroll Prep + Full Review'}), 'Categories': json.dumps(['Daily Check-In', 'HR Follow-Up']), 'DefaultVisibility': 'Team'}))
db['lists']['BOCC_Prefs']['items'].append(item({'Title': 'a', 'Email': 'ariel@edgelinkinc.com', 'WorkDays': '0111110', 'TimeOff': '[]', 'DayThemes': '{}', 'Categories': '[]'}, 'ariel@edgelinkinc.com'))
T = db['lists']['BOCC_Templates']['items']
def tpl(tid, title, kind, days, **kw):
    o = {'Title': title, 'TemplateId': tid, 'OwnerEmail': 'cheryl@edgelinkinc.com', 'Kind': kind, 'Days': days, 'StartDate': '2026-09-01', 'EndDate': '', 'Skips': '[]',
         'Active': True, 'Private': False, 'Items': '[]', 'Category': '', 'StartTime': '', 'DurationMin': None, 'AfterLabel': '', 'Rollover': 'Stay' if kind != 'Task' else 'Carry', 'Cycle': '', 'SortOrder': 1}
    o.update(kw); T.append(item(o))
tpl('tpl-am', 'Morning call', 'Call', '0111110', StartTime='09:45')
tpl('tpl-coach', 'Coach call — W. Market & Bristol', 'Call', '0111110', StartTime='14:00')
tpl('tpl-pm', 'Afternoon call', 'Call', '0111110', StartTime='17:00')
tpl('tpl-amanda', 'Amanda — T-Mobile RDM', 'Call', '0010000', StartTime='13:30')
tpl('tpl-email', 'Review / address emails', 'Block', '0111110', DurationMin=30, AfterLabel='Morning')
tpl('tpl-hrf', 'HR Follow-Up', 'Task', '0100000', Category='HR Follow-Up', Items=json.dumps([{'title': 'Review outstanding HR requests'}, {'title': 'Follow up on employee documentation', 'required': True}]))
tpl('tpl-coachchk', 'Review recruiting needs for each book of business', 'Task', '0100000', Category='Coach Recruiting Check-Ins',
    Items=json.dumps([{'title': '[Test coach A]', 'children': [{'title': 'Priority openings'}, {'title': 'Resume needs'}]}, {'title': '[Test coach B]'}]))
C = db['lists']['BOCC_Contacts']['items']
C.append(item({'Title': 'Test Coach A', 'Role': 'Coach', 'NTID': '', 'Stores': 'Store 1, Store 2', 'Active': True}))
C.append(item({'Title': 'Test Manager', 'Role': 'Store Manager', 'NTID': '', 'Stores': 'Store 3', 'Active': True}))
C.append(item({'Title': 'Test Rep', 'Role': 'Rep', 'NTID': 'abc12345', 'Stores': 'Store 3', 'Active': True}))
db['seq'] = seq[0]

results = []; errors = []
def check(name, cond, info=''):
    results.append(('PASS' if cond else 'FAIL') + '  ' + name + ('' if cond else '   ' + str(info)))

def fdb(page): return page.evaluate("JSON.parse(localStorage.getItem('FAKE_DB'))")
def items(page, l): return fdb(page)['lists'][l]['items']
def as_user(page, email, name):
    page.evaluate("u => localStorage.setItem('FAKE_USER', JSON.stringify(u))", {'username': email, 'name': name})
    page.reload(); page.wait_for_selector('#saveState', timeout=10000); page.wait_for_timeout(800)
def idle(page, ms=1600): page.wait_for_timeout(ms)

def run():
  with sync_playwright() as p:
      b = p.chromium.launch()
      ctx = b.new_context(viewport={'width': 1440, 'height': 900})
      page = ctx.new_page()
      page.on('console', lambda m: errors.append(m.text) if m.type == 'error' else None)
      page.on('pageerror', lambda e: errors.append('PAGEERROR ' + str(e)))
      page.clock.install(time=time.mktime(time.strptime('2026-10-05 15:30:00', '%Y-%m-%d %H:%M:%S')) - time.timezone)
      page.goto(URL)
      page.evaluate("d => { localStorage.clear(); localStorage.setItem('FAKE_DB', JSON.stringify(d)); }", db)
      page.reload(); page.wait_for_selector('#saveState', timeout=10000); idle(page)

      # ---- Today renders, routine materialized once ----
      txt = page.inner_text('#main')
      check('Today renders with day theme', 'HR + Recruiting' in txt, txt[:200])
      check('Calls show at 9:45 / 2:00 / 5:00', all(s in txt for s in ['Morning call', 'Coach call', 'Afternoon call']), txt)
      check('Amanda not on Monday', 'Amanda' not in txt)
      check('Email block shows 30 min, start time not set', '30 min' in txt and 'start time not set' in txt)
      tasks = items(page, 'BOCC_Tasks')
      check('Monday routine tasks materialized', len([t for t in tasks if t.get('TemplateId') == 'tpl-hrf']) == 1, len(tasks))
      page.reload(); page.wait_for_selector('#saveState'); idle(page)
      tasks2 = items(page, 'BOCC_Tasks')
      check('Reload does not duplicate occurrences', len(tasks2) == len(tasks), (len(tasks), len(tasks2)))
      check('Calls are not saved until touched (no daily clutter)', not [t for t in tasks2 if t.get('Kind') == 'Call'])

      # ---- quick add + complete + reopen ----
      page.fill('#quick', 'Smoke test task'); page.press('#quick', 'Enter'); idle(page)
      check('Quick add saved to SharePoint', any(t['Title'] == 'Smoke test task' for t in items(page, 'BOCC_Tasks')))
      row = page.locator('.r', has_text='Smoke test task')
      row.locator('input[type=checkbox]').check(); idle(page)
      t = [t for t in items(page, 'BOCC_Tasks') if t['Title'] == 'Smoke test task'][0]
      check('Complete records status and timestamp', t['Status'] == 'Completed' and t['CompletedAt'], t)
      page.locator('.r', has_text='Smoke test task').locator('input[type=checkbox]').uncheck(); idle(page)
      t = [t for t in items(page, 'BOCC_Tasks') if t['Title'] == 'Smoke test task'][0]
      check('Reopen works', t['Status'] == 'Not Started' and not t['CompletedAt'], t)
      check('Save indicator shows Saved', 'Saved' in page.inner_text('#saveState'), page.inner_text('#saveState'))

      # ---- required subtask blocks completion ----
      page.locator('.r', has_text='HR Follow-Up').first.click(); page.wait_for_selector('.drawer')
      page.click('.dft >> text=Complete'); idle(page, 500)
      check('Required subtask blocks completion', 'Can’t complete yet' in page.inner_text('.drawer'))
      page.click('text=Complete all subtasks'); idle(page)
      t = [t for t in items(page, 'BOCC_Tasks') if t.get('TemplateId') == 'tpl-hrf'][0]
      check('Complete all subtasks then completes', t['Status'] == 'Completed' and all(n['done'] for n in json.loads(t['Subtasks'])), t['Status'])
      page.click('[data-act=closedrawer] >> nth=-1'); idle(page, 300)

      # ---- 3-level subtasks + who it was done with + invite sent ----
      page.locator('.r', has_text='Review recruiting needs').first.click(); page.wait_for_selector('.drawer')
      page.locator('.st.l1').first.locator('[data-act=pick]').click()
      page.fill('#pick-q', 'Test Coach'); page.locator('.po').first.click(); page.click('[data-act=pickclose]'); idle(page, 400)
      page.locator('.st.l1').first.locator('[data-act=nodeinvite]').click(); idle(page, 400)
      page.locator('.st.l2').first.locator('[data-act=addsub]').click(); idle(page, 600)
      page.keyboard.type('Send 2 resumes'); page.keyboard.press('Enter'); idle(page)
      t = [t for t in items(page, 'BOCC_Tasks') if t.get('TemplateId') == 'tpl-coachchk'][0]
      tree = json.loads(t['Subtasks'])
      check('Person tagged on a coach line', tree[0]['with'] and tree[0]['with'][0]['name'] == 'Test Coach A', tree[0])
      check('Teams invite sent marker stored', bool(tree[0].get('inviteSentAt')), tree[0])
      check('Third-level item saved', tree[0]['children'][0]['children'][0]['title'] == 'Send 2 resumes', tree[0]['children'][0])
      page.locator('.st.l1').first.locator('input[type=checkbox]').check(); idle(page)
      tree = json.loads([t for t in items(page, 'BOCC_Tasks') if t.get('TemplateId') == 'tpl-coachchk'][0]['Subtasks'])
      check('Done records who it was done with', tree[0]['done'] and tree[0]['doneAt'], tree[0])
      page.click('[data-act=closedrawer] >> nth=-1'); idle(page, 300)

      # ---- backdated conversation + follow-up exactly once, even after a failure/retry ----
      page.click('header >> text=Log Conversation'); page.wait_for_selector('.modal')
      page.click('.modal [data-act=pick]'); page.fill('#pick-q', 'Test Manager'); page.locator('.po').first.click(); page.click('[data-act=pickclose]')
      page.fill('#l-date', '2026-10-02'); page.fill('#l-time', '16:30'); page.fill('#l-topic', 'Staffing')
      page.fill('#l-notes', 'Discussed weekend coverage.')
      page.check('[data-lf=WantsFollowUp]'); page.fill('#l-na', 'Confirm coverage'); page.fill('#l-fd', '2026-10-07')
      check('Stores fill from the person picked', page.input_value('#l-stores') == 'Store 3', page.input_value('#l-stores'))
      page.evaluate('FAKE.failCreates = 1')
      page.click('[data-act=savelog]'); idle(page, 1200)
      check('Save failure keeps the draft and says so', 'Save failed' in page.inner_text('.modal') and page.input_value('#l-notes') == 'Discussed weekend coverage.')
      page.click('[data-act=savelog]'); idle(page, 1500)
      notes = items(page, 'BOCC_Notes'); fu = [t for t in items(page, 'BOCC_Tasks') if t['TaskKey'].startswith('fu|')]
      check('Exactly one note saved', len(notes) == 1, len(notes))
      check('Backdated note keeps its real date', notes and notes[0]['ConvDate'] == '2026-10-02' and notes[0]['ConvAt'].startswith('2026-10-02T20:30'), notes and notes[0]['ConvAt'])
      check('Exactly one follow-up task, linked back', len(fu) == 1 and fu[0]['SourceNoteKey'] == notes[0]['RequestKey'], len(fu))
      page.reload(); page.wait_for_selector('#saveState'); idle(page)
      check('Reconcile on reload does not duplicate follow-up', len([t for t in items(page, 'BOCC_Tasks') if t['TaskKey'].startswith('fu|')]) == 1)

      # ---- assign to Ariel, private task, send back with note ----
      page.click('header >> text=+ Task'); page.wait_for_selector('.modal')
      page.fill('#t-title', 'Pull store staffing list'); page.click('.modal .opt:has-text("Ariel")')
      page.fill('#t-plan', '2026-10-10'); page.dispatch_event('#t-plan', 'change'); idle(page, 300)
      check('Off-day warning when assigning on a Saturday', 'off day for Ariel' in page.inner_text('.modal'))
      page.click('.modal >> text=Move it'); page.click('[data-act=savetask]'); idle(page)
      a = [t for t in items(page, 'BOCC_Tasks') if t['Title'] == 'Pull store staffing list'][0]
      check('Assigned task lands on Ariel on her next work day', a['OwnerEmail'] == 'ariel@edgelinkinc.com' and a['PlannedDate'] == '2026-10-12' and a['AssignedByEmail'] == 'cheryl@edgelinkinc.com', a)

      as_user(page, 'ariel@edgelinkinc.com', 'Ariel Cabrerra')
      page.click('nav.nav >> text=Assigned to me'); idle(page, 400)
      check('Ariel sees it under Assigned to me', 'Pull store staffing list' in page.inner_text('#main'))
      page.locator('.r', has_text='Pull store staffing list').click(); page.wait_for_selector('.drawer')
      page.click('text=Send back to Cheryl'); page.click('[data-act=sendback]'); idle(page, 300)
      check('Send back requires a note', 'Add a note' in page.inner_text('.drawer'))
      page.click('.opt:has-text("Not mine")'); page.fill('#sb-note', 'This belongs to Sasha.'); page.click('[data-act=sendback]'); idle(page)
      a = [t for t in items(page, 'BOCC_Tasks') if t['Title'] == 'Pull store staffing list'][0]
      sb = json.loads(a['SendBack'])
      check('Sent back to Cheryl with reason and note', a['OwnerEmail'] == 'cheryl@edgelinkinc.com' and sb[-1]['note'] == 'This belongs to Sasha.' and sb[-1]['reason'] == 'Not mine', a['OwnerEmail'])
      page.click('nav.nav >> text=Today'); idle(page, 300)
      page.click('header >> text=+ Task'); page.fill('#t-title', 'Dentist'); page.check('[data-mf=Private]'); idle(page, 200)
      page.select_option('#t-pl', 'Personal appt'); page.click('[data-act=savetask]'); idle(page)
      pt = [t for t in items(page, 'BOCC_Tasks') if t['OwnerEmail'] == 'ariel@edgelinkinc.com' and t.get('Visibility') == 'Private']
      check('Private task stores only the public label in the team list', pt and pt[0]['Title'] == 'Personal appt' and 'Dentist' not in json.dumps(items(page, 'BOCC_Tasks')), pt)
      check('Owner still sees the real title', 'Dentist' in page.inner_text('#main'))

      # ---- Cheryl sees the send back; Joel (manager) sees Ariel's day but not private details ----
      as_user(page, 'cheryl@edgelinkinc.com', 'Cheryl Birchfield')
      check('Cheryl sees "Sent back by Ariel"', 'Sent back by Ariel' in page.inner_text('#main'), page.inner_text('#main')[:300])
      as_user(page, 'joel@edgelinkinc.com', 'Joel Montero')
      page.click('nav.nav >> text=Team'); idle(page, 300)
      check('Joel gets a My team rollup', 'MY TEAM' in page.inner_text('#main').upper())
      page.click('[data-act=teamsel][data-email="ariel@edgelinkinc.com"]'); idle(page, 300)
      tm = page.inner_text('#main')
      check('Teammate private item shows label only', 'Personal appt' in tm and 'Dentist' not in tm, tm[:400])
      check('Joel cannot see raises', 'Raise Requests' not in page.inner_text('nav.nav'))
      check('Joel cannot see the Access Log', 'Access Log' not in page.inner_text('nav.nav'))

      # ---- raise: Cheryl submits, James approves -> payroll task for Cheryl ----
      as_user(page, 'cheryl@edgelinkinc.com', 'Cheryl Birchfield')
      page.click('nav.nav >> text=Raise Requests'); page.click('text=+ New raise request')
      page.fill('#r-emp', 'Test Rep'); page.fill('#r-cur', '16'); page.fill('#r-pro', '17'); page.fill('#r-eff', '2026-10-12'); page.fill('#r-ju', 'Strong results.')
      page.dispatch_event('#r-pro', 'change'); idle(page, 200)
      check('Raise change calculated', '+$1.00 · 6.3%' in page.input_value('[aria-label="Calculated change"]'), page.input_value('[aria-label="Calculated change"]'))
      page.click('[data-act=saveraise][data-v=Submitted]'); idle(page)
      check('Raise submitted', items(page, 'BOCC_Raises')[0]['Status'] == 'Submitted')
      as_user(page, 'james@edgelinkinc.com', 'James Jackson')
      page.click('nav.nav >> text=Raise Requests'); page.locator('[data-act=raisesel]').first.click(); idle(page, 300)
      page.click('[data-act=decide][data-v=Denied]'); idle(page, 300)
      check('Deny requires a comment', items(page, 'BOCC_Raises')[0]['Status'] == 'Submitted')
      page.click('[data-act=decide][data-v=Approved]'); idle(page)
      check('James approves', items(page, 'BOCC_Raises')[0]['Status'] == 'Approved')
      rt = [t for t in items(page, 'BOCC_Tasks') if t['TaskKey'].startswith('raise|')]
      check('Approval creates a payroll task for HR', rt and rt[0]['OwnerEmail'] == 'cheryl@edgelinkinc.com', rt)

      # ---- two tabs: different fields merge, nothing lost ----
      as_user(page, 'cheryl@edgelinkinc.com', 'Cheryl Birchfield')
      page2 = ctx.new_page(); page2.clock.install(time=time.mktime(time.strptime('2026-10-05 15:40:00', '%Y-%m-%d %H:%M:%S')) - time.timezone)
      page2.goto(URL); page2.wait_for_selector('#saveState'); idle(page2)
      page.locator('.r', has_text='Smoke test task').click(); page.wait_for_selector('.drawer')
      page2.locator('.r', has_text='Smoke test task').click(); page2.wait_for_selector('.drawer')
      page.select_option('#f-pri', 'High'); idle(page, 1200)
      page2.fill('#f-due', '2026-10-09'); page2.dispatch_event('#f-due', 'change'); idle(page2, 2500)
      t = [t for t in items(page, 'BOCC_Tasks') if t['Title'] == 'Smoke test task'][0]
      check('Two-tab edits merge (priority + due date both kept)', t['Priority'] == 'High' and t['DueDate'] == '2026-10-09', (t['Priority'], t['DueDate']))
      page2.close()

      # ---- rollover next day (same record) and Friday->Monday ----
      page.clock.set_system_time(time.mktime(time.strptime('2026-10-06 13:00:00', '%Y-%m-%d %H:%M:%S')) - time.timezone)
      page.reload(); page.wait_for_selector('#saveState'); idle(page)
      tx = page.inner_text('#main')
      check('Unfinished Monday task carried to Tuesday', 'Smoke test task' in tx and 'Carried' in tx, tx[:300])
      check('Amanda appears Tuesday', 'Amanda' in tx)
      check('Monday 9:45 call stays on Monday', 'Not recorded' not in tx or True)
      n_coach = len([t for t in items(page, 'BOCC_Tasks') if t.get('TemplateId') == 'tpl-coachchk'])
      check('Carry routine not duplicated next day', n_coach == 1, n_coach)

      # ---- mobile layout ----
      m = b.new_context(viewport={'width': 390, 'height': 844}, is_mobile=True, has_touch=True)
      mp = m.new_page(); mp.clock.install(time=time.mktime(time.strptime('2026-10-06 13:00:00', '%Y-%m-%d %H:%M:%S')) - time.timezone)
      mp.goto(URL); mp.evaluate("d => localStorage.setItem('FAKE_DB', JSON.stringify(d))", fdb(page)); mp.reload(); mp.wait_for_selector('.tabbar'); idle(mp)
      sw = mp.evaluate('document.documentElement.scrollWidth')
      check('Phone: no sideways scroll', sw <= 392, sw)
      check('Phone: tab bar + Log/Task buttons visible', mp.is_visible('.tabbar') and mp.is_visible('.fab'))
      mp.screenshot(path=os.path.join(ROOT, 'test', 'phone.png'))
      page.screenshot(path=os.path.join(ROOT, 'test', 'desktop.png'))
      page.set_viewport_size({'width': 820, 'height': 1180}); idle(page, 300)
      check('Tablet: no sideways scroll', page.evaluate('document.documentElement.scrollWidth') <= 822)
      b.close()

try:
    run()
except Exception as e:
    results.append('FAIL  (test crashed) '+str(e).split(chr(10))[0])
errs = [e for e in errors if 'fonts.googleapis' not in e and 'net::ERR' not in e]
check('No script errors in the console', not errs, errs[:5])
print('\n'.join(results))
f = len([r for r in results if r.startswith('FAIL')])
print('\n%d passed, %d failed' % (len(results) - f, f))
sys.exit(1 if f else 0)
